
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(MakinomEditorAsset))]
public class MakinomEditorAssetInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.Show((MakinomEditorAsset)target);
	}
	
	private void Show(MakinomEditorAsset target)
	{
		EditorGUILayout.HelpBox("This asset contains Makinom editor data, e.g. last opened project and section.\n" +
			"It doesn't contain any gameplay related data and can be deleted without causing problems.", 
			MessageType.Info, true);
		
		if(target.LastProject != null)
		{
			EditorGUILayout.LabelField("Last Project", AssetDatabase.GetAssetPath(target.LastProject));
			
			if(GUILayout.Button("Open Last Project"))
			{
				MakinomEditorWindow.ShowMakinomEditor(target.LastProject);
			}
		}
		if(GUILayout.Button("Clear Foldout States"))
		{
			target.ResetFoldoutStates();
			target.FoldoutLimit = "";
			EditorUtility.SetDirty(target);
		}
		if(GUILayout.Button("Clear Popup Favorites"))
		{
			target.ClearPopupFavorites();
			EditorUtility.SetDirty(target);
		}
	}
}
