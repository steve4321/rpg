﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom.Schematics;

namespace GamingIsLove.Makinom.Editor
{
	[EditorSettingInfo("Separator", "Dialogues and their content (title, text, choices) will be recognized by defined separator texts.")]
	public class SeparatorDialogueImportFormat : BaseDialogueImportFormat
	{
		// dialogue separator
		[EditorHelp("Dialogue Separator", "Separator used to split the text into multiple dialogues.\n" +
			"E.g. use 3 new lines between dialogues to split them into multiple dialogues.")]
		[EditorFoldout("Separator Format Settings", "Define the settings used to import the processing text.", "",
			"Dialogue Separator", "Separator used to split the text into multiple dialogues.\n" +
			"E.g. use 3 new lines between dialogues to split them into multiple dialogues.", "")]
		[EditorEndFoldout]
		[EditorInfo(isStandardTextArea = true)]
		[EditorWidth(true)]
		[EditorLabel("Separator used to split the text into multiple dialogues.\n" +
			"E.g. use 3 new lines between dialogues to split them into multiple dialogues.")]
		public string dialogueSeparator = "\n\n\n";

		// title separator
		[EditorHelp("Title Separator (Optional)", "Separator used to split a dialogue's title and text.\n" +
			"E.g. use ':' and start the dialogue's text in a new line after the title.\n" +
			"Leave empty to not use titles.")]
		[EditorFoldout("Title Separator (Optional)", "Separator used to split a dialogue's title and text.\n" +
			"E.g. use ':' and start the dialogue's text in a new line after the title.\n" +
			"Leave empty to not use titles.")]
		[EditorEndFoldout]
		[EditorInfo(isStandardTextArea = true)]
		[EditorWidth(true)]
		[EditorLabel("Separator used to split a dialogue's title and text.\n" +
			"E.g. use ':' and start the dialogue's text in a new line after the title.\n" +
			"Leave empty to not use titles.")]
		public string titleSeparator = ":\n";

		// choice separator
		[EditorHelp("Choice Separator (Optional)", "Separator used to split a dialogue's text and choices.\n" +
			"E.g. use '>:' at the start of each choice text (in a new line).\n" +
			"Leave empty to not use titles.")]
		[EditorFoldout("Choice Separator (Optional)", "Separator used to split a dialogue's text and choices.\n" +
			"E.g. use '>:' at the start of each choice text (in a new line).\n" +
			"Leave empty to not use titles.")]
		[EditorInfo(isStandardTextArea = true)]
		[EditorWidth(true)]
		[EditorLabel("Separator used to split a dialogue's text and choices.\n" +
			"E.g. use '>:' at the start of each choice text (in a new line).\n" +
			"Leave empty to not use titles.")]
		public string choiceSeparator = "\n>:";

		[EditorHelp("Auto Next Dialogue", "Choices of a dialogue will automatically set their next dialogue to the next dialogues that are processed after the choices.\n" +
			"The dialogue's own 'Next Dialogue' will not be set.")]
		[EditorEndFoldout(2)]
		public bool choiceAutoNextDialogue = false;


		// dialogue text
		[EditorHelp("Trim Spaces", "Remove spaces at the start and end of all lines.")]
		[EditorFoldout("Processing Text", "The text that will be processed to create dialogues.")]
		public bool trimSpaces = true;

		[EditorHelp("Trim Tabs", "Remove tabs at the start and end of all lines.")]
		public bool trimTabs = true;

		[EditorHelp("Trim Empty Lines", "Remove empty lines at the start and end of content (title, message, choices).\n" +
			"Only used when processing the next, not during preprocessing.")]
		public bool trimEmptyLines = true;

		[EditorHelp("Unified New Line", "All new line characters will be changed to use '\\n'.\n" +
			"I.e. '\\r\\n' will be updated to '\\n', and afterwards single '\\r' to '\\n'.")]
		public bool unifiedNewLine = true;

		[EditorHelp("Processing Text", "The text that will be processed to create dialogues.")]
		[EditorEndFoldout]
		[EditorInfo(isStandardTextArea = true)]
		[EditorWidth(true)]
		[EditorLabel("The text that will be processed to create dialogues.")]
		[EditorCallback("button:process", EditorCallbackType.Before)]
		[EditorCallback("button:process", EditorCallbackType.After)]
		public string processingText = "";

		public SeparatorDialogueImportFormat()
		{

		}

		public override DataObject GetData()
		{
			DataObject data = base.GetData();
			data.Remove<string>("processingText");
			return data;
		}

		public override bool CanProcess
		{
			get
			{
				return !string.IsNullOrEmpty(this.dialogueSeparator) &&
					!string.IsNullOrEmpty(this.processingText);
			}
		}

		public override bool CanPreprocessText
		{
			get { return !string.IsNullOrEmpty(this.processingText); }
		}

		public override void PreprocessText()
		{
			this.processingText = this.GetPreprocessedText();
		}

		public virtual string GetPreprocessedText()
		{
			string tmpProcessingText = this.processingText;
			if(this.unifiedNewLine)
			{
				tmpProcessingText = tmpProcessingText.Replace("\r\n", "\n").Replace("\r", "\n");
			}
			if(this.trimSpaces)
			{
				char[] trimming = new char[] { ' ' };
				string[] tmp = tmpProcessingText.Split(new string[] { "\n" }, System.StringSplitOptions.None);
				for(int i = 0; i < tmp.Length; i++)
				{
					tmp[i] = tmp[i].Trim(trimming);
				}
				tmpProcessingText = string.Join("\n", tmp);
			}
			if(this.trimTabs)
			{
				char[] trimming = new char[] { '\t' };
				string[] tmp = tmpProcessingText.Split(new string[] { "\n" }, System.StringSplitOptions.None);
				for(int i = 0; i < tmp.Length; i++)
				{
					tmp[i] = tmp[i].Trim(trimming);
				}
				tmpProcessingText = string.Join("\n", tmp);
			}
			return tmpProcessingText;
		}

		public virtual string TrimEmptyLines(string text)
		{
			if(this.trimEmptyLines &&
				!string.IsNullOrEmpty(text))
			{
				List<string> tmp = new List<string>(text.Split(new string[] { "\n" }, System.StringSplitOptions.None));
				int lastContent = -1;
				for(int i = 0; i < tmp.Count; i++)
				{
					if(string.IsNullOrEmpty(tmp[i]))
					{
						if(i == 0)
						{
							tmp.RemoveAt(i--);
						}
					}
					else
					{
						lastContent = i;
					}
				}
				lastContent += 1;
				if(lastContent < tmp.Count)
				{
					tmp.RemoveRange(lastContent, tmp.Count - lastContent);
				}
				if(tmp.Count == 0)
				{
					return "";
				}
				else if(tmp.Count == 1)
				{
					return tmp[0];
				}
				else
				{
					return string.Join("\n", tmp);
				}
			}
			return text;
		}

		public override DialogueImportContent ProcessText()
		{
			if(!string.IsNullOrEmpty(this.processingText))
			{
				try
				{
					string tmpProcessingText = this.GetPreprocessedText();

					string tmpDialogueSeparator = this.dialogueSeparator.Replace("\r\n", "\n").Replace("\r", "\n");
					string tmpTitleSeparator = this.titleSeparator.Replace("\r\n", "\n").Replace("\r", "\n");
					string tmpChoiceSeparator = this.choiceSeparator.Replace("\r\n", "\n").Replace("\r", "\n");

					DialogueImportContent content = new DialogueImportContent();

					List<DialogueImport_Speaker> speakers = new List<DialogueImport_Speaker>();
					List<DialogueImport_Dialogue> dialogues = new List<DialogueImport_Dialogue>();

					// split dialogues
					if(!string.IsNullOrEmpty(tmpDialogueSeparator))
					{
						string[] dialogueData = tmpProcessingText.Split(new string[] { tmpDialogueSeparator }, System.StringSplitOptions.None);

						for(int i = 0; i < dialogueData.Length; i++)
						{
							int speakerID = -1;

							// split title
							if(!string.IsNullOrEmpty(tmpTitleSeparator))
							{
								int index = dialogueData[i].IndexOf(tmpTitleSeparator, System.StringComparison.Ordinal);
								if(index > 0)
								{
									string title = this.TrimEmptyLines(dialogueData[i].Substring(0, index));

									dialogueData[i] = index + tmpTitleSeparator.Length >= dialogueData[i].Length ?
										"" :
										dialogueData[i].Substring(index + tmpTitleSeparator.Length);

									for(int j = 0; j < speakers.Count; j++)
									{
										if(speakers[j].foundTitle == title)
										{
											speakerID = j;
											break;
										}
									}

									if(speakerID < 0)
									{
										DialogueImport_Speaker newSpeaker = new DialogueImport_Speaker(title);
										speakerID = speakers.Count;
										speakers.Add(newSpeaker);
									}
								}
							}

							// choices
							DialogueImport_Choice[] choice = null;
							if(!string.IsNullOrEmpty(tmpChoiceSeparator))
							{
								int index = dialogueData[i].IndexOf(tmpChoiceSeparator, System.StringComparison.Ordinal);
								if(index > 0)
								{
									string choiceText = dialogueData[i].Substring(index + tmpChoiceSeparator.Length);
									dialogueData[i] = dialogueData[i].Substring(0, index);

									string[] choiceData = choiceText.Split(new string[] { tmpChoiceSeparator }, System.StringSplitOptions.None);
									choice = new DialogueImport_Choice[choiceData.Length];
									for(int j = 0; j < choiceData.Length; j++)
									{
										choice[j] = new DialogueImport_Choice(this.TrimEmptyLines(choiceData[j]));
									}
								}
							}

							// text
							DialogueImport_Dialogue newDialogue = new DialogueImport_Dialogue(this.TrimEmptyLines(dialogueData[i]));
							if(speakerID >= 0)
							{
								newDialogue.useSpeaker = true;
								newDialogue.speakerID = speakerID;
							}
							newDialogue.choice = choice;

							dialogues.Add(newDialogue);
						}
					}

					content.speakers = speakers.ToArray();
					content.dialogues = dialogues.ToArray();
					content.SetNextDialogues(this.choiceAutoNextDialogue);
					return content;
				}
				catch(System.Exception ex)
				{
					Debug.LogWarning("An issue occured while processing the dialogue text.\n" +
						ex.Message + ":\n" + ex.StackTrace);
				}
			}
			return null;
		}
	}
}
