﻿
using UnityEngine;
using GamingIsLove.Makinom.UI;
using GamingIsLove.Makinom.Schematics;
using GamingIsLove.Makinom.Schematics.Nodes;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class DialogueImport_Choice : BaseData
	{
		[EditorHelp("Next Dialogue", "Select the dialogue that will be opened after this dialogue.")]
		[EditorInfo(isTabPopup = true, tabPopupID = 2)]
		public int next = 0;

		[EditorHelp("Choice Text", "Define the text of the choice.")]
		public TextContent text;

		public DialogueImport_Choice()
		{
			this.text = new TextContent();
		}

		public DialogueImport_Choice(string content)
		{
			this.text = new TextContent(content);
		}

		public virtual ChoiceOption CreateChoice()
		{
			ChoiceOption choice = new ChoiceOption();
			choice.content.content.mainContent.data.text.SetData(this.text.GetData());
			choice.next = this.next - 1;
			return choice;
		}
	}
}
