﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics.Nodes;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class DialogueImportContent : BaseData
	{
		[EditorArray(foldout = true, foldoutText = new string[] {
			"Speaker", "Define the settings for this speaker.", ""
		})]
		public DialogueImport_Speaker[] speakers;

		[EditorArray(foldout = true, foldoutText = new string[] {
			"Dialogue", "Define the settings for this dialogue.", ""
		})]
		public DialogueImport_Dialogue[] dialogues;

		public DialogueImportContent()
		{

		}

		public virtual void SetNextDialogues(bool choiceAutoNext)
		{
			if(choiceAutoNext)
			{
				int current = 0;
				for(int i = 0; i < this.dialogues.Length - 1 && current < this.dialogues.Length - 1; i++)
				{
					if(this.dialogues[i].choice != null)
					{
						for(int j = 0; j < this.dialogues[i].choice.Length && current < this.dialogues.Length - 1; j++)
						{
							this.dialogues[i].choice[j].next = current + 2;
							current++;
						}
					}
					else
					{
						this.dialogues[i].next = current + 2;
						current++;
					}
				}
			}
			else
			{
				for(int i = 0; i < this.dialogues.Length - 1; i++)
				{
					this.dialogues[i].next = i + 2;
				}
			}
		}

		public virtual List<BaseNode> CreateDialogues()
		{
			List<BaseNode> nodes = new List<BaseNode>();
			for(int i = 0; i < this.dialogues.Length; i++)
			{
				nodes.Add(this.dialogues[i].CreateDialogue(this));
			}
			return nodes;
		}
	}
}
