﻿
using GamingIsLove.Makinom;
using UnityEngine;
using UnityEditor;
using System.IO;

namespace GamingIsLove.Makinom.Editor
{
	public class UISystemSettingsTab : BaseEditorTab
	{
		protected DataObject tmpData;

		protected bool showChangeDialog = true;

		public UISystemSettingsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;
			this.tmpData = Maki.UISystem.GetData();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "UI System"; }
		}

		public override string HelpText
		{
			get { return "Set up the UI system that will be used."; }
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/ui-system/ui-system-overview/"; }
		}

		protected override BaseSettings Settings
		{
			get { return Maki.UISystem; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return Maki.UISystem; }
		}


		/*
		============================================================================
		Settings display
		============================================================================
		*/
		public override void ShowSettings()
		{
			string tmpType = Maki.UISystem.type;
			EditorAutomation.Automate(Maki.UISystem, this);

			if(GUI.changed)
			{
				this.tmpData = Maki.UISystem.GetData();
			}
		}

		public override void AutomationCallback(string info)
		{
			if(info == "toggle:uisystemdialog")
			{
				EditorTool.Field(
					new GUIContent("Show Confirmation Dialog", "Changing the UI system will display a confirmation dialog."), 
					ref this.showChangeDialog, "", null, this);
			}
			else
			{
				base.AutomationCallback(info);
			}
		}

		public override void SettingChanged(IBaseData instance, string fieldName, object newValue)
		{
			if(instance == Maki.UISystem &&
				fieldName == "type")
			{
				if(!this.showChangeDialog ||
					EditorUtility.DisplayDialog("Change UI System",
						"Changing the UI system will replace and change multiple settings in different parts of the framework.\n" +
						"You'll have to revisit multiple settings, like your UI layers and UI boxes.\n\n" +
						"The previous settings will not be restored if you change back to the previous UI system.",
						"Ok", "Cancel"))
				{
					EditorDataHandler.Instance.UISystemChanged();
					EditorTextAreaControl.ResetTextCodes();
					this.tmpData = Maki.UISystem.GetData();
				}
				else
				{
					Maki.UISystem.SetData(this.tmpData);
				}
			}
		}
	}
}
