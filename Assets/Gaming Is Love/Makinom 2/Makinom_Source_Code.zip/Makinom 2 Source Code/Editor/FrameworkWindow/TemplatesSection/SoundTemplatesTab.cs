
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class SoundTemplatesTab : GenericAssetListTab<SoundTemplateAsset, SoundTemplate>
	{
		public SoundTemplatesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Sound Templates"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up reusable templates for sound assignments.\n" +
					"They're used by 'Sound Assignment' components.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/features/audio-and-music/"; }
		}
	}
}

