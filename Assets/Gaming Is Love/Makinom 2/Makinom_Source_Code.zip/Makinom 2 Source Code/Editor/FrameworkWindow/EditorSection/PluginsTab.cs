
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public sealed class PluginsTab : GenericAssetListTab<PluginAsset, PluginSetting>
	{
		public PluginsTab(MakinomEditorWindow parent) : base(parent)
		{
			Maki.Plugins.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			Maki.Plugins.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Plugins"; }
		}

		public override string HelpText
		{
			get { return "Plugins can be used to integrate 3rd party products or extend Makinom's features."; }
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/extensions/plugins/plugins-overview/"; }
		}


		/*
		============================================================================
		Settings display
		============================================================================
		*/
		public override void AutomationCallback(string info)
		{
			if(info == "info:pluginversion")
			{
				if(this.assetList.AssetExists(this.index))
				{
					EditorGUILayout.LabelField("Plugin Version", this.assetList.Assets[this.index].Settings.settings.Version, EditorTool.WIDTH);
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}
	}
}
