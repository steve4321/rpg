
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class CameraPositionsTab : GenericAssetListTab<CameraPositionAsset, CameraPosition>
	{
		public CameraPositionsTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Camera Positions"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up camera positions and use them in schematics.\n" +
					"Camera positions can be set up in global space or in local space of the game object they're used upon.\n" +
					"You can use the scene wizard to create camera positions using game objects in your scene.";
			}
		}

		public override string HelpInfo
		{
			get { return ""; }
		}
	}
}
