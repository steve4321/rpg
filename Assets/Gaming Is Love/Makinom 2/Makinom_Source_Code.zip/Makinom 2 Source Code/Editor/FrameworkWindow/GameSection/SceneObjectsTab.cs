
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class SceneObjectsTab : GenericAssetListTab<SceneObjectAsset, SceneObject>
	{
		public SceneObjectsTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Scene Objects"; }
		}

		public override string HelpText
		{
			get
			{
				return "Use scene objects to add content information to game objects in your scenes.\n" +
					"The information can be displayed by HUDs or used in dialogues.\n" +
					"You can also change the cursor when it's above a game object of a scene object.\n" +
					"Add a scene object to a game object in your scene using the 'Scene Object' component.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/features/scene-objects/"; }
		}

		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<SceneObjectTypeAsset, SceneObjectType>(
							new string[] { "Scene Object Type", "Filter the scene object list by scene object type.", "" }));
				}
				return this.filter;
			}
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override bool CheckFilterCondition(int index)
		{
			return this.Filter.assetFilterSelection[0].Check(
				this.assetList.Assets[index].Settings.sceneObjectType.Source.EditorAsset);
		}
	}
}
