﻿
using UnityEngine;
using UnityEngine.Audio;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class SoundChannelSetting : BaseData
	{
		[EditorHelp("Sound Channel", "Define the sound channel that will be set up.\n" +
			"The default channel is 0.", "")]
		[EditorLimit(0, false)]
		public int channel = 0;

		[EditorHelp("Start Volume (0-1)", "Define the sound volume (between 0 and 1) that will be used when Makinom is initialized.", "")]
		[EditorLimit(0.0f, 1.0f, isSlider=true)]
		public float startVolume = 1;

		[EditorHelp("Audio Mixer Group Asset", "Select the audio mixer group asset that will be used as output of the sound channel.", "")]
		public AssetSource<AudioMixerGroup> mixerGroup = new AssetSource<AudioMixerGroup>();

		public SoundChannelSetting()
		{

		}

		public void Initialize()
		{
			SoundChannel tmpChannel = Maki.Audio.GetSoundChannel(this.channel);
			tmpChannel.Volume = this.startVolume;
			tmpChannel.SetOutput(this.mixerGroup);
		}
	}
}
