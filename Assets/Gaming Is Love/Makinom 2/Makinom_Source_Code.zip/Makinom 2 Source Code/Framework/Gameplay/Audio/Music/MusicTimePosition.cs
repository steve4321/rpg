﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class MusicTimePosition
	{
		public float time = 0;

		public int currentLoop = 0;

		public MusicTimePosition()
		{

		}

		public MusicTimePosition(float time, int currentLoop)
		{
			this.time = time;
			this.currentLoop = currentLoop;
		}
	}
}
