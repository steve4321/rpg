
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class Sound : BaseData, IFoldoutInfo
	{
		[EditorHelp("Sound Type", "Select the sound type of this sound.", "")]
		public AssetSelection<SoundTypeAsset> soundType = new AssetSelection<SoundTypeAsset>();

		[EditorHelp("Audio Clip", "Select the audio clip that will be used.\n" +
			"One of the added audio clips is used randomly.", "")]
		[EditorArray("Add Audio Clip", "Adds an audio clip that will be used.\n" +
			"One of the added audio clips is used randomly.", "",
			"Remove", "Removes this audio clip.", "", noRemoveCount = 1,
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Audio Clip", "Select the audio clip that will be used.\n" +
				"One of the added audio clips is used randomly.", ""
			})]
		public AssetSource<AudioClip>[] audioClip = new AssetSource<AudioClip>[] { new AssetSource<AudioClip>() };

		public Sound()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<DataObject>("audioClip"))
			{
				this.audioClip[0].SetData(data.GetFile("audioClip"));
			}
		}

		public virtual string GetFoldoutInfo()
		{
			return this.soundType.ToString();
		}

		public virtual AudioClip GetSound()
		{
			if(this.audioClip.Length == 1)
			{
				return this.audioClip[0].StoredAsset;
			}
			else if(this.audioClip.Length > 1)
			{
				return this.audioClip[Random.Range(0, this.audioClip.Length)].StoredAsset;
			}
			return null;
		}
	}
}
