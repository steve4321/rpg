
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class MusicClipStored
	{
		private MusicClip clip;

		private float time = 0;

		private int currentLoop = 0;

		public MusicClipStored(MusicClip clip, float time)
		{
			this.clip = clip;
			this.time = time;

			if(this.clip != null)
			{
				this.currentLoop = this.clip.CurrentLoop;
			}
		}


		/*
		============================================================================
		Play functions
		============================================================================
		*/
		public void Play(MusicChannel channel)
		{
			if(this.clip != null)
			{
				this.clip.CurrentLoop = this.currentLoop;
				channel.Play(this.clip);
				channel.SetTime(this.time);
			}
			else
			{
				channel.Stop();
			}
		}

		public void FadeIn(MusicChannel channel, float t, Interpolation interpolation)
		{
			if(this.clip != null)
			{
				channel.FadeIn(this.clip, t, interpolation);
				channel.SetTime(this.time);
			}
			else
			{
				channel.FadeOut(t, interpolation);
			}
		}

		public void FadeTo(MusicChannel channel, float t, Interpolation interpolation)
		{
			if(this.clip != null)
			{
				channel.FadeTo(this.clip, t, interpolation);
				channel.SetTime(this.time);
			}
			else
			{
				channel.FadeOut(t, interpolation);
			}
		}

		public void FadeOutPlay(MusicChannel channel, float t, Interpolation interpolation)
		{
			if(this.clip != null)
			{
				channel.FadeOutPlay(this.clip, t, interpolation, this.time);
			}
			else
			{
				channel.FadeOut(t, interpolation);
			}
		}
	}
}
