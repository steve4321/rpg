﻿
using UnityEngine;
using GamingIsLove.Makinom.Reflection;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class PlayerComponentSetting : BaseData, IFoldoutInfo
	{
		[EditorHelp("Add Component", "Adds the component to the player if it wasn't already added.")]
		public bool addComponent = true;

		[EditorHelp("Remove Component", "Removes the component from the old player when changing to a different player.")]
		public bool removeComponent = true;


		// component
		public ChangeFields<GameObjectSelection> component = new ChangeFields<GameObjectSelection>();

		public PlayerComponentSetting()
		{

		}

		public virtual string GetFoldoutInfo()
		{
			return this.component.className;
		}

		public virtual void Add(GameObject player)
		{
			// add/get component
			System.Type type = Maki.ReflectionHandler.GetType(this.component.className, typeof(Component));
			Component comp = player.GetComponent(type);
			if(comp == null &&
				this.addComponent)
			{
				player.AddComponent(type);
			}

			// set fields
			if(comp != null)
			{
				this.component.Change(comp, type, new DataCall(), false);
			}
		}

		public virtual void Remove(GameObject player)
		{
			// remove component
			if(this.removeComponent)
			{
				System.Type type = Maki.ReflectionHandler.GetType(this.component.className, typeof(Component));
				Component comp = player.GetComponent(type);
				if(comp != null)
				{
					GameObject.Destroy(comp);
				}
			}
		}
	}
}
