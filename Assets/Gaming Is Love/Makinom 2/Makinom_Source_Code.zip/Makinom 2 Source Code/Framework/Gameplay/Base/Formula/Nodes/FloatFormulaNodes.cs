
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Formulas.Nodes
{
	[EditorHelp("Float Atan2", "Uses the angle in radians whose Tan is y/x to " +
		"change the current formula value or stores it into a float variable.", "")]
	[NodeInfo("Float")]
	public class FloatAtan2Node : BaseFormulaNode
	{
		[EditorHelp("Store in Variable", "Store the result into a float variable.\n" +
			"If disabled, the result will be used to change the current value of the formula.", "")]
		public bool storeVariable = false;

		// variable settings
		[EditorTitleLabel("Variable Settings")]
		[EditorSeparator]
		[EditorCondition("storeVariable", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public VariableSet<FormulaObjectSelection> variable;

		[EditorSeparator]
		public FloatOperator floatOperator = new FloatOperator();


		// values
		[EditorHelp("Y Value", "The y value.", "")]
		[EditorTitleLabel("Y Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> valueY = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("X Value", "The x value.", "")]
		[EditorTitleLabel("X Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> valueX = new FloatValue<FormulaObjectSelection>();

		public FloatAtan2Node()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.floatOperator.OldDataUpgrade(data, "floatOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			float tmpValue = Mathf.Atan2(
				this.valueY.GetValue(call),
				this.valueX.GetValue(call));

			if(this.storeVariable)
			{
				string tmpKey = this.variable.key.GetValue(call);
				List<VariableHandler> handlers = this.variable.GetHandlers(call);
				for(int i = 0; i < handlers.Count; i++)
				{
					this.variable.ChangeFloat(call, handlers[i], tmpKey,
						tmpValue, this.floatOperator);
				}
				Maki.Pooling.VariableHandlerLists.Add(handlers);
			}
			else
			{
				this.floatOperator.Use(ref call.result, tmpValue);
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.storeVariable ? this.variable.ToString() + " " : "") +
				this.floatOperator.ToString() + " " +
				this.valueY.ToString() + " / " + this.valueX.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Float Clamp", "Clamps a float value between a minimum and maximum and " +
		"stores it into a float variable.", "")]
	[NodeInfo("Float")]
	public class FloatClampNode : BaseFormulaNode
	{
		[EditorHelp("Store in Variable", "Store the result into a float variable.\n" +
			"If disabled, the result will be used to change the current value of the formula.", "")]
		public bool storeVariable = false;

		// variable settings
		[EditorTitleLabel("Variable Settings")]
		[EditorSeparator]
		[EditorCondition("storeVariable", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public VariableSet<FormulaObjectSelection> variable;

		[EditorSeparator]
		public FloatOperator floatOperator = new FloatOperator();


		// values
		[EditorHelp("Value", "The value that will be clamped.", "")]
		[EditorTitleLabel("Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> value = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("Minimum Value", "The minimum value (lower limit) the value can have.", "")]
		[EditorTitleLabel("Minimum Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> minimum = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("Maximum Value", "The maximum value (upper limit) the value can have.", "")]
		[EditorTitleLabel("Maximum Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> maximum = new FloatValue<FormulaObjectSelection>();

		public FloatClampNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.floatOperator.OldDataUpgrade(data, "floatOperator");
		}

		public override int Calculate(FormulaCall call)
		{

			float tmpValue = Mathf.Clamp(
				this.value.GetValue(call),
				this.minimum.GetValue(call),
				this.maximum.GetValue(call));

			if(this.storeVariable)
			{
				string tmpKey = this.variable.key.GetValue(call);
				List<VariableHandler> handlers = this.variable.GetHandlers(call);
				for(int i = 0; i < handlers.Count; i++)
				{
					this.variable.ChangeFloat(call, handlers[i], tmpKey,
						tmpValue, this.floatOperator);
				}
				Maki.Pooling.VariableHandlerLists.Add(handlers);
			}
			else
			{
				this.floatOperator.Use(ref call.result, tmpValue);
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.storeVariable ? this.variable.ToString() + " " : "") +
				this.floatOperator.ToString() + " " +
				this.value.ToString() + " (" +
				this.minimum.ToString() + " - " +
				this.maximum.ToString() + ")";
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Float Delta Angle", "Calculates the shortest difference between two angles and " +
		"stores it into a float variable.", "")]
	[NodeInfo("Float")]
	public class FloatDeltaAngleNode : BaseFormulaNode
	{
		[EditorHelp("Store in Variable", "Store the result into a float variable.\n" +
			"If disabled, the result will be used to change the current value of the formula.", "")]
		public bool storeVariable = false;

		// variable settings
		[EditorTitleLabel("Variable Settings")]
		[EditorSeparator]
		[EditorCondition("storeVariable", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public VariableSet<FormulaObjectSelection> variable;

		[EditorSeparator]
		public FloatOperator floatOperator = new FloatOperator();


		// values
		[EditorHelp("Current Angle", "The current angle value.", "")]
		[EditorTitleLabel("Current Angle")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> current = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("Target Angle", "The target angle value.", "")]
		[EditorTitleLabel("Target Angle")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> target = new FloatValue<FormulaObjectSelection>();

		public FloatDeltaAngleNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.floatOperator.OldDataUpgrade(data, "floatOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			float tmpValue = Mathf.DeltaAngle(
				this.current.GetValue(call),
				this.target.GetValue(call));

			if(this.storeVariable)
			{
				string tmpKey = this.variable.key.GetValue(call);
				List<VariableHandler> handlers = this.variable.GetHandlers(call);
				for(int i = 0; i < handlers.Count; i++)
				{
					this.variable.ChangeFloat(call, handlers[i], tmpKey,
						tmpValue, this.floatOperator);
				}
				Maki.Pooling.VariableHandlerLists.Add(handlers);
			}
			else
			{
				this.floatOperator.Use(ref call.result, tmpValue);
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.storeVariable ? this.variable.ToString() + " " : "") +
				this.floatOperator.ToString() + " " +
				this.current.ToString() + " - " +
				this.target.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Float Inverse Lerp", "Calculates the Lerp parameter between two values and " +
		"stores it into a float variable.", "")]
	[NodeInfo("Float")]
	public class FloatInverseLerpNode : BaseFormulaNode
	{
		[EditorHelp("Store in Variable", "Store the result into a float variable.\n" +
			"If disabled, the result will be used to change the current value of the formula.", "")]
		public bool storeVariable = false;

		// variable settings
		[EditorTitleLabel("Variable Settings")]
		[EditorSeparator]
		[EditorCondition("storeVariable", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public VariableSet<FormulaObjectSelection> variable;

		[EditorSeparator]
		public FloatOperator floatOperator = new FloatOperator();


		// values
		[EditorHelp("From Value", "The start value.", "")]
		[EditorTitleLabel("From Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> fromValue = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("To Value", "The end value.", "")]
		[EditorTitleLabel("To Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> toValue = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("Value", "The value that is used.", "")]
		[EditorTitleLabel("Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> value = new FloatValue<FormulaObjectSelection>();

		public FloatInverseLerpNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.floatOperator.OldDataUpgrade(data, "floatOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			float tmpValue = Mathf.InverseLerp(
				this.fromValue.GetValue(call),
				this.toValue.GetValue(call),
				this.value.GetValue(call));

			if(this.storeVariable)
			{
				string tmpKey = this.variable.key.GetValue(call);
				List<VariableHandler> handlers = this.variable.GetHandlers(call);
				for(int i = 0; i < handlers.Count; i++)
				{
					this.variable.ChangeFloat(call, handlers[i], tmpKey,
						tmpValue, this.floatOperator);
				}
				Maki.Pooling.VariableHandlerLists.Add(handlers);
			}
			else
			{
				this.floatOperator.Use(ref call.result, tmpValue);
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.storeVariable ? this.variable.ToString() + " " : "") +
				this.floatOperator.ToString() + " " +
				this.fromValue.ToString() + ", " +
				this.toValue.ToString() + ", " +
				this.value.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Float Lerp", "Interpolates between two values and stores it into a float variable.", "")]
	[NodeInfo("Float")]
	public class FloatLerpNode : BaseFormulaNode
	{
		[EditorHelp("Use Angle", "Use LerpAngle instead of Lerp.\n" +
			"Makes sure the values interpolate correctly when they wrap around 360 degrees", "")]
		public bool useAngle = false;

		[EditorHelp("Store in Variable", "Store the result into a float variable.\n" +
			"If disabled, the result will be used to change the current value of the formula.", "")]
		public bool storeVariable = false;

		// variable settings
		[EditorTitleLabel("Variable Settings")]
		[EditorSeparator]
		[EditorCondition("storeVariable", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public VariableSet<FormulaObjectSelection> variable;

		[EditorSeparator]
		public FloatOperator floatOperator = new FloatOperator();


		// values
		[EditorHelp("From Value", "The start value.", "")]
		[EditorTitleLabel("From Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> fromValue = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("To Value", "The end value.", "")]
		[EditorTitleLabel("To Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> toValue = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("Time", "The interpolation time, clamped between 0 and 1.", "")]
		[EditorTitleLabel("Time")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> time = new FloatValue<FormulaObjectSelection>();

		public FloatLerpNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.floatOperator.OldDataUpgrade(data, "floatOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			float tmpValue = this.useAngle ?
				Mathf.LerpAngle(
					this.fromValue.GetValue(call),
					this.toValue.GetValue(call),
					this.time.GetValue(call)) :
				Mathf.Lerp(
					this.fromValue.GetValue(call),
					this.toValue.GetValue(call),
					this.time.GetValue(call));

			if(this.storeVariable)
			{
				string tmpKey = this.variable.key.GetValue(call);
				List<VariableHandler> handlers = this.variable.GetHandlers(call);
				for(int i = 0; i < handlers.Count; i++)
				{
					this.variable.ChangeFloat(call, handlers[i], tmpKey,
						tmpValue, this.floatOperator);
				}
				Maki.Pooling.VariableHandlerLists.Add(handlers);
			}
			else
			{
				this.floatOperator.Use(ref call.result, tmpValue);
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.storeVariable ? this.variable.ToString() + " " : "") +
				this.floatOperator.ToString() + " " +
				this.fromValue.ToString() + ", " +
				this.toValue.ToString() + ", " +
				this.time.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Float Move Towards", "Moves a value current toward target and stores it into a float variable.", "")]
	[NodeInfo("Float")]
	public class FloatMoveTowardsNode : BaseFormulaNode
	{
		[EditorHelp("Use Angle", "Use MoveTowardsAngle instead of MoveTowards.\n" +
			"Makes sure the values interpolate correctly when they wrap around 360 degrees", "")]
		public bool useAngle = false;

		[EditorHelp("Store in Variable", "Store the result into a float variable.\n" +
			"If disabled, the result will be used to change the current value of the formula.", "")]
		public bool storeVariable = false;

		// variable settings
		[EditorTitleLabel("Variable Settings")]
		[EditorSeparator]
		[EditorCondition("storeVariable", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public VariableSet<FormulaObjectSelection> variable;

		[EditorSeparator]
		public FloatOperator floatOperator = new FloatOperator();


		// values
		[EditorHelp("Current Value", "The current value.", "")]
		[EditorTitleLabel("Current Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> current = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("Target Value", "The target value.", "")]
		[EditorTitleLabel("Target Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> target = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("Maximum Delta", "The maximum change possible.", "")]
		[EditorTitleLabel("Maximum Delta")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> maxDelta = new FloatValue<FormulaObjectSelection>();

		public FloatMoveTowardsNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.floatOperator.OldDataUpgrade(data, "floatOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			float tmpValue = this.useAngle ?
				Mathf.MoveTowardsAngle(
					this.current.GetValue(call),
					this.target.GetValue(call),
					this.maxDelta.GetValue(call)) :
				Mathf.MoveTowards(
					this.current.GetValue(call),
					this.target.GetValue(call),
					this.maxDelta.GetValue(call));

			if(this.storeVariable)
			{
				string tmpKey = this.variable.key.GetValue(call);
				List<VariableHandler> handlers = this.variable.GetHandlers(call);
				for(int i = 0; i < handlers.Count; i++)
				{
					this.variable.ChangeFloat(call, handlers[i], tmpKey,
						tmpValue, this.floatOperator);
				}
				Maki.Pooling.VariableHandlerLists.Add(handlers);
			}
			else
			{
				this.floatOperator.Use(ref call.result, tmpValue);
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.storeVariable ? this.variable.ToString() + " " : "") +
				this.floatOperator.ToString() + " " +
				this.current.ToString() + ", " +
				this.target.ToString() + ", " +
				this.maxDelta.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Float Perlin Noise", "Generates 2D perlin noise and stores it into a float variable.", "")]
	[NodeInfo("Float")]
	public class FloatPerlinNoiseNode : BaseFormulaNode
	{
		[EditorHelp("Store in Variable", "Store the result into a float variable.\n" +
			"If disabled, the result will be used to change the current value of the formula.", "")]
		public bool storeVariable = false;

		// variable settings
		[EditorTitleLabel("Variable Settings")]
		[EditorSeparator]
		[EditorCondition("storeVariable", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public VariableSet<FormulaObjectSelection> variable;

		[EditorSeparator]
		public FloatOperator floatOperator = new FloatOperator();


		// values
		[EditorHelp("X Value", "The used x value.", "")]
		[EditorTitleLabel("X Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> valueX = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("Y Value", "The used y value.", "")]
		[EditorTitleLabel("Y Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> valueY = new FloatValue<FormulaObjectSelection>();

		public FloatPerlinNoiseNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.floatOperator.OldDataUpgrade(data, "floatOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			float tmpValue = Mathf.PerlinNoise(
				this.valueX.GetValue(call),
				this.valueY.GetValue(call));

			if(this.storeVariable)
			{
				string tmpKey = this.variable.key.GetValue(call);
				List<VariableHandler> handlers = this.variable.GetHandlers(call);
				for(int i = 0; i < handlers.Count; i++)
				{
					this.variable.ChangeFloat(call, handlers[i], tmpKey,
						tmpValue, this.floatOperator);
				}
				Maki.Pooling.VariableHandlerLists.Add(handlers);
			}
			else
			{
				this.floatOperator.Use(ref call.result, tmpValue);
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.storeVariable ? this.variable.ToString() + " " : "") +
				this.floatOperator.ToString() + " " +
				this.valueX.ToString() + ", " +
				this.valueY.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Float Ping Pong", "PingPongs or loops (repeats) a value, so that it is never larger than length and " +
		"never smaller than 0, and stores it into a float variable.", "")]
	[NodeInfo("Float")]
	public class FloatPingPongNode : BaseFormulaNode
	{
		[EditorHelp("Use Repeat", "Use Mathf.Repeat instead of Mathf.PingPong.", "")]
		public bool useRepeat = false;

		[EditorHelp("Store in Variable", "Store the result into a float variable.\n" +
			"If disabled, the result will be used to change the current value of the formula.", "")]
		public bool storeVariable = false;

		// variable settings
		[EditorTitleLabel("Variable Settings")]
		[EditorSeparator]
		[EditorCondition("storeVariable", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public VariableSet<FormulaObjectSelection> variable;

		[EditorSeparator]
		public FloatOperator floatOperator = new FloatOperator();


		// values
		[EditorHelp("Value", "The used value.", "")]
		[EditorTitleLabel("Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> value = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("Length", "The used length.", "")]
		[EditorTitleLabel("Length")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> length = new FloatValue<FormulaObjectSelection>();

		public FloatPingPongNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.floatOperator.OldDataUpgrade(data, "floatOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			float tmpValue = this.useRepeat ?
				Mathf.Repeat(
					this.value.GetValue(call),
					this.length.GetValue(call)) :
				Mathf.PingPong(
					this.value.GetValue(call),
					this.length.GetValue(call));

			if(this.storeVariable)
			{
				string tmpKey = this.variable.key.GetValue(call);
				List<VariableHandler> handlers = this.variable.GetHandlers(call);
				for(int i = 0; i < handlers.Count; i++)
				{
					this.variable.ChangeFloat(call, handlers[i], tmpKey,
						tmpValue, this.floatOperator);
				}
				Maki.Pooling.VariableHandlerLists.Add(handlers);
			}
			else
			{
				this.floatOperator.Use(ref call.result, tmpValue);
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.storeVariable ? this.variable.ToString() + " " : "") +
				this.floatOperator.ToString() + " " +
				this.value.ToString() + ", " +
				this.length.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Float Smooth Step", "Interpolates between two values with smoothing at the limits " +
		"and stores it into a float variable.", "")]
	[NodeInfo("Float")]
	public class FloatSmoothStepNode : BaseFormulaNode
	{
		[EditorHelp("Store in Variable", "Store the result into a float variable.\n" +
			"If disabled, the result will be used to change the current value of the formula.", "")]
		public bool storeVariable = false;

		// variable settings
		[EditorTitleLabel("Variable Settings")]
		[EditorSeparator]
		[EditorCondition("storeVariable", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public VariableSet<FormulaObjectSelection> variable;

		[EditorSeparator]
		public FloatOperator floatOperator = new FloatOperator();


		// values
		[EditorHelp("From Value", "The start value.", "")]
		[EditorTitleLabel("From Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> fromValue = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("To Value", "The end value.", "")]
		[EditorTitleLabel("To Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> toValue = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("Time", "The interpolation time, clamped between 0 and 1.", "")]
		[EditorTitleLabel("Time")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> time = new FloatValue<FormulaObjectSelection>();

		public FloatSmoothStepNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.floatOperator.OldDataUpgrade(data, "floatOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			float tmpValue = Mathf.SmoothStep(
				this.fromValue.GetValue(call),
				this.toValue.GetValue(call),
				this.time.GetValue(call));

			if(this.storeVariable)
			{
				string tmpKey = this.variable.key.GetValue(call);
				List<VariableHandler> handlers = this.variable.GetHandlers(call);
				for(int i = 0; i < handlers.Count; i++)
				{
					this.variable.ChangeFloat(call, handlers[i], tmpKey,
						tmpValue, this.floatOperator);
				}
				Maki.Pooling.VariableHandlerLists.Add(handlers);
			}
			else
			{
				this.floatOperator.Use(ref call.result, tmpValue);
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.storeVariable ? this.variable.ToString() + " " : "") +
				this.floatOperator.ToString() + " " +
				this.fromValue.ToString() + ", " +
				this.toValue.ToString() + ", " +
				this.time.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Float To Angle", "Changes a float value into an angle (i.e. between 0 and 360) " +
		"and stores it into a float variable.\n" +
		"E.g. -90 will become 270, 480 will become 120.", "")]
	[NodeInfo("Float")]
	public class FloatToAngleNode : BaseFormulaNode
	{
		[EditorHelp("Store in Variable", "Store the result into a float variable.\n" +
			"If disabled, the result will be used to change the current value of the formula.", "")]
		public bool storeVariable = false;

		// variable settings
		[EditorTitleLabel("Variable Settings")]
		[EditorSeparator]
		[EditorCondition("storeVariable", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public VariableSet<FormulaObjectSelection> variable;

		[EditorSeparator]
		public FloatOperator floatOperator = new FloatOperator();


		// values
		[EditorHelp("Value", "The value that will be used.", "")]
		[EditorTitleLabel("Value")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> value = new FloatValue<FormulaObjectSelection>();

		public FloatToAngleNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.floatOperator.OldDataUpgrade(data, "floatOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			float tmpValue = this.value.GetValue(call);
			ValueHelper.ToAngle(ref tmpValue);

			if(this.storeVariable)
			{
				string tmpKey = this.variable.key.GetValue(call);
				List<VariableHandler> handlers = this.variable.GetHandlers(call);
				for(int i = 0; i < handlers.Count; i++)
				{
					this.variable.ChangeFloat(call, handlers[i], tmpKey,
						tmpValue, this.floatOperator);
				}
				Maki.Pooling.VariableHandlerLists.Add(handlers);
			}
			else
			{
				this.floatOperator.Use(ref call.result, tmpValue);
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.storeVariable ? this.variable.ToString() + " " : "") +
				this.floatOperator.ToString() + " " +
				this.value.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Float is Power of 2", "Checks if an int value is power of two.\n" +
		"If check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Float")]
	public class FloatIsPowerOf2Node : BaseFormulaCheckNode
	{
		[EditorHelp("Check Value", "The value used for the check.\n" +
			"The value will be used as an integer, e.g. 4.1 will become 4.", "")]
		public FloatValue<FormulaObjectSelection> value = new FloatValue<FormulaObjectSelection>();

		public FloatIsPowerOf2Node()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(Mathf.IsPowerOfTwo((int)this.value.GetValue(call)))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.value.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}
}
