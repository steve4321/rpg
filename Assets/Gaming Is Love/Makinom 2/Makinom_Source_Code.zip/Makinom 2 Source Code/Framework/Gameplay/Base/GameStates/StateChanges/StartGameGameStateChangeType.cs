﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Start Game", "When the game is started ('Start Game' node).")]
	public class StartGameGameStateChangeType : BaseGameStateChangeType
	{
		public StartGameGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			Maki.Game.StartGameCalled += notify;
		}
	}
}
