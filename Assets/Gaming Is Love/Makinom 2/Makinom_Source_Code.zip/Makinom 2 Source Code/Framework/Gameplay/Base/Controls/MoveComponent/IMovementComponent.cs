﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public interface IMovementComponent
	{
		void Move(Vector3 change);

		bool MoveTo(ref Vector3 position, float speed);

		void SetPosition(Vector3 position);

		void Stop();
	}
}
