﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Sphere 3D", "Checks if colliders are within a sphere shape (uses 'Collider').")]
	public class Sphere3DShapecheckType<T> : BaseShapecheckType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Origin")]
		[EditorLabel("The center of the sphere.")]
		public Vector3Value<T> origin = new Vector3Value<T>();

		[EditorHelp("Radius", "The radius of the sphere.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Radius")]
		public FloatValue<T> radius = new FloatValue<T>();

		public Sphere3DShapecheckType()
		{

		}

		public override string ToString()
		{
			return "Sphere 3D";
		}

		public override bool Check(IDataCall call, int layerMask)
		{
			return Physics.CheckSphere(this.origin.GetValue(call),
				this.radius.GetValue(call), layerMask);
		}

		public override Collider Overlap(IDataCall call, int layerMask)
		{
			Collider[] collider = Physics.OverlapSphere(this.origin.GetValue(call),
				this.radius.GetValue(call), layerMask);

			return collider != null && collider.Length > 0 ? collider[0] : null;
		}

		public override Collider[] OverlapAll(IDataCall call, int layerMask)
		{
			return Physics.OverlapSphere(this.origin.GetValue(call),
				this.radius.GetValue(call), layerMask);
		}

		public override Collider2D Overlap2D(IDataCall call, int layerMask)
		{
			return null;
		}

		public override Collider2D[] OverlapAll2D(IDataCall call, int layerMask)
		{
			return null;
		}
	}
}
