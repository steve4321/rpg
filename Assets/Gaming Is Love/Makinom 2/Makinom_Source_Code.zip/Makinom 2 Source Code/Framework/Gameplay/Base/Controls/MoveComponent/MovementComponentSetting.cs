﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class MovementComponentSetting : BaseData
	{
		[EditorHelp("Component Type", "Select the component used to move the game object (e.g. the player):", "")]
		[EditorLabel("You can create custom movement component integrations by extending from the 'BaseMovementComponentSetting' class.")]
		[EditorInfo(settingBaseType=typeof(BaseMovementComponentSetting), settingAutoSetup="settings")]
		public string type = typeof(SimpleMovementComponentSetting).ToString();


		// settings
		public BaseMovementComponentSetting settings = new SimpleMovementComponentSetting();

		public MovementComponentSetting()
		{

		}

		public override void EditorAutoSetup(string fieldName)
		{
			if(!this.settings.IsType(this.type))
			{
				DataObject data = this.settings.GetData();
				object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
					this.type, typeof(BaseMovementComponentSetting));
				if(tmpSettings is BaseMovementComponentSetting)
				{
					this.settings = (BaseMovementComponentSetting)tmpSettings;
					this.settings.SetData(data);
				}
				else
				{
					this.settings = new SimpleMovementComponentSetting();
					this.settings.SetData(data);
					this.type = this.settings.GetType().ToString();
				}
			}
		}

		public IMovementComponent Init(GameObject gameObject)
		{
			return this.settings.Init(gameObject);
		}
	}
}
