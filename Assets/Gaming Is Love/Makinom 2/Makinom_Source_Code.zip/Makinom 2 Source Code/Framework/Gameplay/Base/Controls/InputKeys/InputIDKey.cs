
using UnityEngine;
using GamingIsLove.Makinom.Reflection;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class InputIDKey : BaseData
	{
		[EditorHelp("Input ID", "Define the input ID these settings will be assigned to.\n" +
			"The global input ID is 0 when starting a game, " +
			"machines can either use the default ID or override the ID, " +
			"i.e. this can be used to have machines with the same schematic react to different input.\n" +
			"The global input ID can also be changed in-game, " +
			"i.e. this can be used for creating different control styles.\n" +
			"The minimum input ID is 0 - an input ID of -1 can be used to check " +
			"for any inputs of an input key (ignoring input ID).", "")]
		[EditorLimit(0, false)]
		public int inputID = 0;

		[EditorHelp("Input Origin", "Select where the input of the key will come from:", "")]
		[EditorInfo(settingBaseType = typeof(BaseInputIDKeySetting), settingAutoSetup = "settings")]
		public string type = "";

		[EditorHelp("UI Blocks Input", "Input is blocked when the cursor is over a UI box (e.g. a HUD).", "")]
		public bool uiBlocksInput = false;


		// axis settings
		[EditorHelp("Invert Axis", "The input axis will be inverted, " +
			"i.e. 1 will become -1, -1 will become 1.", "")]
		[EditorSeparator]
		public bool invertAxis = false;

		[EditorHelp("Axis Factor", "The input axis value will be multiplied by this value.", "")]
		public float axisFactor = 1;

		[EditorHelp("Limit Axis", "Limits the axis value to be between 2 defined values (included).", "")]
		public bool limitAxis = false;

		[EditorHelp("Minimum Axis", "The minimum value the axis can have (lower limit).", "")]
		[EditorCondition("limitAxis", true)]
		public float minAxis = -1;

		[EditorHelp("Maximum Axis", "The maximum value the axis can have (upper limit).", "")]
		[EditorEndCondition]
		public float maxAxis = 1;


		// settings
		[EditorSeparator]
		public BaseInputIDKeySetting settings = new NoneInputIDKeySetting();


		// ingame
		protected bool inputReceived = false;

		protected float updateAxis = 0;

		protected float hudAxis = 0;

		protected float codeAxis = 0;

		protected float timeout = Mathf.NegativeInfinity;

		protected float holdTimeout = Mathf.NegativeInfinity;

		protected float maxHoldTimeout = Mathf.Infinity;


		// schematic axis set
		protected float schematicAxis = 0;

		protected bool resetSchematicAxis = false;

		protected float schematicAxisTimeout = 0;


		// fixed update
		protected bool fixedUpdateInputReceived = false;

		protected float fixedUpdateAxis = 0;

		public InputIDKey()
		{
			this.type = this.settings.GetGenericTypeName();
		}

		public InputIDKey(KeyCode positiveKey, KeyCode negativeKey, InputHandling handling)
		{
			this.settings = new KeyCodeInputIDKeySetting(positiveKey, negativeKey, handling);
			this.type = this.settings.GetGenericTypeName();
		}

		public override void EditorAutoSetup(string fieldName)
		{
			if(!this.settings.IsType(this.type))
			{
				DataObject data = this.settings.GetData();
				object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
					this.type, typeof(BaseInputIDKeySetting));
				if(tmpSettings is BaseInputIDKeySetting)
				{
					this.settings = (BaseInputIDKeySetting)tmpSettings;
					this.settings.SetData(data);
				}
				else
				{
					this.settings = new NoneInputIDKeySetting();
					this.settings.SetData(data);
					this.type = this.settings.GetGenericTypeName();
				}
			}
		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public virtual bool InputReceived
		{
			get { return this.inputReceived; }
			set { this.inputReceived = value; }
		}

		public virtual float HoldTimeout
		{
			get { return this.holdTimeout; }
			set { this.holdTimeout = value; }
		}

		public virtual float MaxHoldTimeout
		{
			get { return this.maxHoldTimeout; }
			set { this.maxHoldTimeout = value; }
		}

		public virtual float Timeout
		{
			get { return this.timeout; }
			set { this.timeout = value; }
		}

		public virtual float UpdateAxis
		{
			get { return this.updateAxis; }
			set { this.updateAxis = this.ManipulateAxisValue(value); }
		}

		public virtual void SetUpdateAxisUnmanipulated(float value)
		{
			this.updateAxis = value;
		}

		public virtual float ManipulateAxisValue(float value)
		{
			value = this.axisFactor * (this.invertAxis ? -value : value);
			if(this.limitAxis)
			{
				if(value < this.minAxis)
				{
					value = this.minAxis;
				}
				else if(value > this.maxAxis)
				{
					value = this.maxAxis;
				}
			}
			return value;
		}

		public virtual void Tick(int inputKeyID)
		{
			this.inputReceived = false;
			this.updateAxis = 0;

			if(this.resetSchematicAxis &&
				this.schematicAxisTimeout < Time.realtimeSinceStartup)
			{
				this.schematicAxis = 0;
				this.resetSchematicAxis = false;
			}

			// blocked input
			if((this.uiBlocksInput && Maki.UI.IsCursorOver) ||
				this.timeout > Time.realtimeSinceStartup ||
				this.holdTimeout > Time.realtimeSinceStartup ||
				this.maxHoldTimeout < Time.realtimeSinceStartup)
			{
				this.settings.TickBlocked(this, inputKeyID);
				return;
			}
			else
			{
				this.settings.Tick(this, inputKeyID);
			}

			// HUD or code
			if(!this.inputReceived &&
				(this.hudAxis != 0 ||
					this.codeAxis != 0 ||
					this.schematicAxis != 0))
			{
				this.timeout = Time.realtimeSinceStartup + this.settings.InputTimeout;
				this.inputReceived = true;
				return;
			}
		}

		public virtual void TickCollection(int inputKeyID)
		{
			this.settings.TickCollection(this, inputKeyID);
		}

		public virtual bool GetButton()
		{
			return this.inputReceived;
		}

		public virtual float GetAxis(int inputKeyID)
		{
			if(this.uiBlocksInput && Maki.UI.IsCursorOver)
			{
				return 0;
			}
			else if(this.hudAxis != 0)
			{
				if(this.timeout > Time.realtimeSinceStartup ||
					this.holdTimeout > Time.realtimeSinceStartup ||
					this.maxHoldTimeout < Time.realtimeSinceStartup)
				{
					return 0;
				}
				else
				{
					this.timeout = Time.realtimeSinceStartup + this.settings.InputTimeout;
					return this.hudAxis;
				}
			}
			else if(this.codeAxis != 0)
			{
				if(this.timeout > Time.realtimeSinceStartup ||
					this.holdTimeout > Time.realtimeSinceStartup ||
					this.maxHoldTimeout < Time.realtimeSinceStartup)
				{
					return 0;
				}
				else
				{
					this.timeout = Time.realtimeSinceStartup + this.settings.InputTimeout;
					return this.codeAxis;
				}
			}
			else if(this.schematicAxis != 0)
			{
				if(this.timeout > Time.realtimeSinceStartup ||
					this.holdTimeout > Time.realtimeSinceStartup ||
					this.maxHoldTimeout < Time.realtimeSinceStartup)
				{
					return 0;
				}
				else
				{
					this.timeout = Time.realtimeSinceStartup + this.settings.InputTimeout;
					return this.schematicAxis;
				}
			}
			else
			{
				return this.settings.GetAxis(this, inputKeyID);
			}
		}

		public virtual void SetDownTime()
		{
			this.holdTimeout = this.settings.InputHoldTime > 0 ?
				Time.realtimeSinceStartup + this.settings.InputHoldTime :
				Mathf.NegativeInfinity;
			this.maxHoldTimeout = this.settings.InputMaxHoldTime > 0 ?
				Time.realtimeSinceStartup + this.settings.InputMaxHoldTime : 
				Mathf.Infinity;
		}

		public virtual void ReleaseDownTime()
		{
			this.holdTimeout = Mathf.NegativeInfinity;
			this.maxHoldTimeout = Mathf.Infinity;
		}

		public virtual float CodeAxis
		{
			get { return this.codeAxis; }
			set
			{
				value = this.ManipulateAxisValue(value);
				if(this.codeAxis != value)
				{
					this.codeAxis = value;
					if(this.codeAxis == 0)
					{
						this.Reset();
					}
					else
					{
						this.SetInputReceived(this.codeAxis);
					}
				}
			}
		}

		public virtual float HUDAxis
		{
			get { return this.hudAxis; }
			set
			{
				value = this.ManipulateAxisValue(value);
				if(this.hudAxis != value)
				{
					this.hudAxis = value;
					if(this.hudAxis == 0)
					{
						this.Reset();
					}
					else
					{
						this.SetInputReceived(this.hudAxis);
					}
				}
			}
		}

		public virtual float SchematicAxis
		{
			get { return this.schematicAxis; }
		}

		public virtual void SetAxisSchematic(float value, float time)
		{
			value = this.ManipulateAxisValue(value);
			if(this.schematicAxis != value)
			{
				this.schematicAxis = value;
				if(this.schematicAxis == 0)
				{
					this.Reset();
				}
				else
				{
					this.SetInputReceived(this.schematicAxis);
				}
			}

			this.resetSchematicAxis = time >= 0;
			this.schematicAxisTimeout = Time.realtimeSinceStartup + time;
		}

		public virtual void Reset()
		{
			this.inputReceived = false;
			this.hudAxis = 0;
			this.codeAxis = 0;
			this.schematicAxis = 0;
			this.ReleaseDownTime();

			this.fixedUpdateInputReceived = false;
			this.fixedUpdateAxis = 0;
		}

		public virtual void Clear()
		{
			this.inputReceived = false;
			this.updateAxis = 0;
			this.hudAxis = 0;
			this.codeAxis = 0;
			this.timeout = Mathf.NegativeInfinity;
			this.ReleaseDownTime();

			// schematic axis set
			this.schematicAxis = 0;
			this.resetSchematicAxis = false;
			this.schematicAxisTimeout = 0;

			// fixed update
			this.fixedUpdateInputReceived = false;
			this.fixedUpdateAxis = 0;

			this.settings.Clear();
		}

		public virtual void SetInputReceived(float axis)
		{
			this.timeout = Time.realtimeSinceStartup + this.settings.InputTimeout;
			this.inputReceived = true;
			this.fixedUpdateInputReceived = true;
			if(!Mathf.Approximately(0, axis))
			{
				this.fixedUpdateAxis = axis;
			}
		}


		/*
		============================================================================
		Fixed update functions
		============================================================================
		*/
		public virtual void StoreForFixedUpdate(int inputKeyID)
		{
			if(this.inputReceived)
			{
				this.fixedUpdateInputReceived = this.inputReceived;
			}
			float tmpAxis = this.GetAxis(inputKeyID);
			if(!Mathf.Approximately(0, tmpAxis))
			{
				this.fixedUpdateAxis = tmpAxis;
			}
		}

		public virtual void FixedTick()
		{
			bool tmp = this.inputReceived;
			this.inputReceived = this.fixedUpdateInputReceived;
			this.fixedUpdateInputReceived = tmp;

			float tmpAxis = this.updateAxis;
			this.updateAxis = this.fixedUpdateAxis;
			this.fixedUpdateAxis = tmpAxis;
		}

		public virtual void LateFixedTick()
		{
			this.inputReceived = this.fixedUpdateInputReceived;
			this.fixedUpdateInputReceived = false;

			this.updateAxis = this.fixedUpdateAxis;
			this.fixedUpdateAxis = 0;
		}
	}
}
