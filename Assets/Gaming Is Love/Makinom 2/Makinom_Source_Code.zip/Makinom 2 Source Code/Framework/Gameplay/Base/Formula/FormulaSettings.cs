﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Formulas.Nodes
{
	public class FormulaSettings : BaseNode
	{
		[EditorHelp("Name", "The name of the formula.", "")]
		[EditorFoldout("Formula Settings", "Set the name and base settings of the formula.", "")]
		[EditorWidth(true)]
		public string name = "";

		[EditorHelp("Type", "The type of the formula.\n" +
			"Formula types are only used to filter the formula list.", "")]
		public AssetSelection<FormulaTypeAsset> formulaType = new AssetSelection<FormulaTypeAsset>();


		// min/max values
		[EditorHelp("Use Mininum Value", "The formula result will have a minimum value.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Min/Max Value")]
		public bool useMinValue = false;

		[EditorHelp("Minimum Value", "If the formula result is below this value, it will be set to this value.", "")]
		[EditorCondition("useMinValue", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<FormulaObjectSelection> minValue;

		[EditorHelp("Use Maximum Value", "The formula result will have a maximum value.", "")]
		[EditorSeparator]
		public bool useMaxValue = false;

		[EditorHelp("Maximum Value", "If the formula result is above this value, it will be set to this value.", "")]
		[EditorCondition("useMaxValue", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		[EditorLimit("minValue", false)]
		public FloatValue<FormulaObjectSelection> maxValue;


		// start value
		[EditorHelp("Start Value", "The start value of the formula.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Start Value")]
		public FloatValue<FormulaObjectSelection> startValue = new FloatValue<FormulaObjectSelection>();

		[EditorEndFoldout]
		public FloatOperator formulaOperator = new FloatOperator();


		// formula nodes
		[EditorHide]
		public BaseFormulaNode[] node = new BaseFormulaNode[0];

		[EditorHide]
		public NodeGroup[] group = new NodeGroup[0];

		[EditorHide]
		public int startIndex = -1;

		[EditorHide]
		public string[] layer = new string[] { "Base Layer" };

		public FormulaSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.formulaOperator.OldDataUpgrade(data, "formulaOperator");
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeName()
		{
			return "Formula Settings";
		}

		public override string GetNodeDetails()
		{
			return (this.useMinValue ? this.minValue.ToString() : "X") +
				" - " + (this.useMaxValue ? this.maxValue.ToString() : "X");
		}

		public override string GetNextName(int index)
		{
			return "Start";
		}

		public override bool IsRemovable()
		{
			return false;
		}

		public override bool IsConnectable(int layer)
		{
			return false;
		}


		/*
		============================================================================
		Next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 1;
		}

		public override int GetNext(int index)
		{
			return this.startIndex;
		}

		public override void SetNext(int index, int next)
		{
			this.startIndex = next;
		}
	}
}
