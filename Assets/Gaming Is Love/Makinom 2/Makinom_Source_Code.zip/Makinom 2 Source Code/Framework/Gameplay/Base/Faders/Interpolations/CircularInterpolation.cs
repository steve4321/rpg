﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Circular/Circular In", "Circular easing in, accelerating from zero velocity.",
		sortIndex=7)]
	public class CircularInInterpolation : BaseInterpolation
	{
		public CircularInInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			elapsedTime = (elapsedTime > duration) ? 1.0f : elapsedTime / duration;
			return -distance * (Mathf.Sqrt(1 - elapsedTime * elapsedTime) - 1) + start;
		}
	}

	[EditorSettingInfo("Circular/Circular Out", "Circular easing out, decelerating to zero velocity.",
		sortIndex=7)]
	public class CircularOutInterpolation : BaseInterpolation
	{
		public CircularOutInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			elapsedTime = (elapsedTime > duration) ? 1.0f : elapsedTime / duration;
			elapsedTime--;
			return distance * Mathf.Sqrt(1 - elapsedTime * elapsedTime) + start;
		}
	}

	[EditorSettingInfo("Circular/Circular In + Out", "Circular easing in/out, acceleration until halfway, then deceleration.",
		sortIndex=7)]
	public class CircularInOutInterpolation : BaseInterpolation
	{
		public CircularInOutInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			elapsedTime = (elapsedTime > duration) ? 2.0f : elapsedTime / (duration / 2);
			if(elapsedTime < 1)
			{
				return -distance / 2 * (Mathf.Sqrt(1 - elapsedTime * elapsedTime) - 1) + start;
			}
			elapsedTime -= 2;
			return distance / 2 * (Mathf.Sqrt(1 - elapsedTime * elapsedTime) + 1) + start;
		}
	}
}
