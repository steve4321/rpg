﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Unpause Game", "When the game is unpaused/resumed.")]
	public class UnpauseGameStateChangeType : BaseGameStateChangeType
	{
		public UnpauseGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			Maki.Game.GameUnpaused += notify;
		}
	}
}
