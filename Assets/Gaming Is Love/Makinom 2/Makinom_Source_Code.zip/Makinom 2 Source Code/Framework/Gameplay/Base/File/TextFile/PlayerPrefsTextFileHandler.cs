﻿
using UnityEngine;
using GamingIsLove.Makinom.IO;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("PlayerPrefs", "The file is stored in Unity's PlayerPrefs as a string value.")]
	public class PlayerPrefsTextFileHandler : BaseTextFileHandler
	{
		public PlayerPrefsTextFileHandler()
		{

		}

		public override string ToString()
		{
			return "PlayerPrefs";
		}

		public override void SaveFile(string fileName, string data)
		{
			PlayerPrefs.SetString(fileName, data);
			PlayerPrefs.Save();
		}

		public override string LoadFile(string fileName)
		{
			return PlayerPrefs.GetString(fileName);
		}

		public override void DeleteFile(string fileName)
		{
			PlayerPrefs.DeleteKey(fileName);
		}

		public override bool FileExists(string fileName)
		{
			return PlayerPrefs.HasKey(fileName);
		}
	}
}
