﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseInputIDKeySetting : BaseTypeData
	{
		/*
		============================================================================
		Input functions
		============================================================================
		*/
		/// <summary>
		/// The time in seconds between recognizing two inputs.
		/// Returns 0 for most input origins, unless they use input handling.
		/// This is used to set the timeout when setting input from code/HUDs.
		/// </summary>
		public virtual float InputTimeout
		{
			get { return 0; }
		}

		/// <summary>
		/// The time in seconds the input has to be held to recognizing the input.
		/// Returns 0 for most input origins, unless they use input handling.
		/// This is used to set the hold time when manually setting a key down time (e.g. Control HUD input).
		/// </summary>
		public virtual float InputHoldTime
		{
			get { return 0; }
		}

		/// <summary>
		/// The maximum time in seconds the input can be held to recognizing the input.
		/// Returns 0 for most input origins, unless they use input handling.
		/// This is used to set the max hold time when manually setting a key down time (e.g. Control HUD input).
		/// </summary>
		public virtual float InputMaxHoldTime
		{
			get { return 0; }
		}

		/// <summary>
		/// Defines on which action the input is recognized: Down, Hold, Up or Any.
		/// Returns Any for most input origins, unless they use input handling.
		/// This is used by Control HUDs to determine when mouse/touch input is recognized.
		/// </summary>
		public virtual InputHandling Handling
		{
			get { return InputHandling.Any; }
		}

		/// <summary>
		/// Returns true if consisting of multiple other input keys.
		/// </summary>
		public virtual bool IsCollection
		{
			get { return false; }
		}

		/// <summary>
		/// Update per frame when the input key is blocked (e.g. by timeouts).
		/// </summary>
		/// <param name="inputKey">The input ID key this setting is part of.</param>
		/// <param name="inputKeyID">The ID of the parent input key.</param>
		public virtual void TickBlocked(InputIDKey inputKey, int inputKeyID)
		{

		}

		/// <summary>
		/// Update per frame when the input is not blocked.
		/// </summary>
		/// <param name="inputKey">The input ID key this setting is part of.</param>
		/// <param name="inputKeyID">The ID of the parent input key.</param>
		public virtual void Tick(InputIDKey inputKey, int inputKeyID)
		{

		}

		/// <summary>
		/// Update per frame after updating all input keys (i.e. 'TickBlocked' or 'Tick' has already been called on all input keys).
		/// This is used by the 'Input Key' input origin.
		/// </summary>
		/// <param name="inputKey">The input ID key this setting is part of.</param>
		/// <param name="inputKeyID">The ID of the parent input key.</param>
		public virtual void TickCollection(InputIDKey inputKey, int inputKeyID)
		{

		}

		/// <summary>
		/// Returns the axis value of the input.
		/// By default returns the update axis that was recognized during the 'Tick' call.
		/// Only needs to be overridden when getting the axis requires special treatment.
		/// </summary>
		/// <param name="inputKey">The input ID key this setting is part of.</param>
		/// <param name="inputKeyID">The ID of the parent input key.</param>
		/// <returns>The axis value.</returns>
		public virtual float GetAxis(InputIDKey inputKey, int inputKeyID)
		{
			return inputKey.UpdateAxis;
		}

		/// <summary>
		/// Called when Makinom is reinitialized (e.g. when not using domain reload in Unity).
		/// </summary>
		public virtual void Clear()
		{

		}

		public virtual InputIDKey GetHeldKey()
		{
			return null;
		}
	}
}
