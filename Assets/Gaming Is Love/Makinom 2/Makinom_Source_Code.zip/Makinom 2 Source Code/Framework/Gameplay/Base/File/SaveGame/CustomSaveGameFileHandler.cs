﻿
using UnityEngine;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Custom", "Uses a custom save game solution using static functions to save, load and delete save games.")]
	public class CustomSaveGameFileHandler : BaseSaveGameFileHandler
	{
		[EditorHelp("Class Name", "The name of the class that contains the static functions.", "")]
		[EditorWidth(true)]
		public string className = "";

		[EditorHelp("Save Function Name", "The name of the static save function that will be called.\n" +
			"The function must have an int parameter for the file index and a string parameter for the save data, e.g.:\n" +
			"public static void Save(int index, string data)", "")]
		[EditorWidth(true)]
		public string saveFunctionName = "";

		[EditorHelp("Load Function Name", "The name of the static load function that will be called.\n" +
			"The function must have an int parameter for the file index and return a string containing the save data, e.g.:\n" +
			"public static string Load(int index)", "")]
		[EditorWidth(true)]
		public string loadFunctionName = "";

		[EditorHelp("Exists Function Name", "The name of the static exists function that will be called.\n" +
			"The function must have an int parameter for the file index and return a bool indicating if the file exists (true) or not (false), e.g.:\n" +
			"public static bool Exists(int index)", "")]
		[EditorWidth(true)]
		public string existsFunctionName = "";

		[EditorHelp("Delete Function Name", "The name of the static delete function that will be called.\n" +
			"The function must have an int parameter for the file index, e.g.:\n" +
			"public static void Delete(int index)", "")]
		[EditorWidth(true)]
		public string deleteFunctionName = "";


		// in-game
		private MethodInfo customSave;

		private MethodInfo customLoad;

		private MethodInfo customExists;

		private MethodInfo customDelete;

		public CustomSaveGameFileHandler()
		{

		}

		private void LoadCustomFunctions()
		{
			Type type = Maki.ReflectionHandler.GetType(this.className);
			if(type != null)
			{
				object instance = null;
				Type instanceType = type;

				this.customSave = Maki.ReflectionHandler.GetMethod(
					this.saveFunctionName,
					new Type[] { typeof(int), typeof(string) },
					ref instance, ref instanceType);

				instanceType = type;
				this.customLoad = Maki.ReflectionHandler.GetMethod(
					this.loadFunctionName,
					new Type[] { typeof(int) },
					ref instance, ref instanceType);

				instanceType = type;
				this.customDelete = Maki.ReflectionHandler.GetMethod(
					this.deleteFunctionName,
					new Type[] { typeof(int) },
					ref instance, ref instanceType);

				instanceType = type;
				this.customExists = Maki.ReflectionHandler.GetMethod(
					this.existsFunctionName,
					new Type[] { typeof(int) },
					ref instance, ref instanceType);
			}
		}

		public override void SaveFile(int index, string data)
		{
			try
			{
				if(this.customSave == null)
				{
					this.LoadCustomFunctions();
				}
				if(this.customSave != null)
				{
					this.customSave.Invoke(null,
						new object[] { index,
							Maki.SaveGameSettings.encryptData ?
								Maki.SecurityHandler.SaveGame(data) :
								data });
				}
			}
			catch(Exception ex)
			{
				Debug.LogWarning("Error occured calling custom save function: " + ex.Message);
			}
		}

		public override string LoadFile(int index)
		{
			try
			{
				if(this.customLoad == null)
				{
					this.LoadCustomFunctions();
				}
				if(this.customLoad != null)
				{
					object tmp = this.customLoad.Invoke(null, new object[] { index });
					if(tmp is string)
					{
						string data = Maki.SecurityHandler.LoadGame((string)tmp);
						if(Maki.SaveGame.CompressionHandler != null)
						{
							data = Maki.SaveGame.CompressionHandler.DecompressString(data);
						}
						return data;
					}
				}
			}
			catch(Exception ex)
			{
				Debug.LogWarning("Error occured while calling custom load function: " + ex.Message);
			}
			return "";
		}

		public override void DeleteFile(int index)
		{
			try
			{
				if(this.customDelete == null)
				{
					this.LoadCustomFunctions();
				}
				if(this.customDelete != null)
				{
					this.customDelete.Invoke(null, new object[] { index });
				}
			}
			catch(Exception ex)
			{
				Debug.LogWarning("Error occured while calling custom delete function: " + ex.Message);
			}
		}

		public override bool FileExists(int index)
		{
			try
			{
				if(this.customExists == null)
				{
					this.LoadCustomFunctions();
				}
				if(this.customExists != null)
				{
					object tmp = this.customExists.Invoke(null, new object[] { index });
					if(tmp is bool)
					{
						return (bool)tmp;
					}
				}
			}
			catch(Exception ex)
			{
				Debug.LogWarning("Error occured while calling custom file exists function: " + ex.Message);
			}
			return false;
		}
	}
}
