
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public enum GameStateConditionType { GameState, Conditions, Template }

	public class GameStateConditionCheck : BaseData, IFoldoutInfo
	{
		[EditorHelp("Condition Type", "Select what will be checked:\n" +
			"- Game State: A single game state will be checked.\n" +
			"- Conditions: Defined game state conditions will be checked, allows more complex conditions.\n" +
			"- Template: A game state condition template will be used.", "")]
		public GameStateConditionType conditionType = GameStateConditionType.GameState;


		// game state
		[EditorSeparator]
		[EditorCondition("conditionType", GameStateConditionType.GameState)]
		[EditorEndCondition]
		[EditorAutoInit]
		public GameStateCheck gameState = new GameStateCheck();


		// conditions
		[EditorCondition("conditionType", GameStateConditionType.Conditions)]
		[EditorEndCondition]
		[EditorAutoInit]
		public SimpleGameStateCondition condition;


		// template
		[EditorHelp("Template", "Select the game state condition template that will be used.", "")]
		[EditorCondition("conditionType", GameStateConditionType.Template)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSelection<GameStateConditionTemplateAsset> template;

		public GameStateConditionCheck()
		{

		}

		public virtual string GetFoldoutInfo()
		{
			return this.ToString();
		}

		public bool Check()
		{
			if(GameStateConditionType.GameState == this.conditionType)
			{
				return this.gameState.Check();
			}
			else if(GameStateConditionType.Conditions == this.conditionType)
			{
				return this.condition.Check();
			}
			else if(GameStateConditionType.Template == this.conditionType)
			{
				return this.template != null &&
					this.template.StoredAsset != null &&
					this.template.StoredAsset.Settings.Check();
			}
			return false;
		}

		public override string ToString()
		{
			if(GameStateConditionType.GameState == this.conditionType)
			{
				return this.gameState.ToString();
			}
			else if(GameStateConditionType.Conditions == this.conditionType)
			{
				return "Conditions";
			}
			else if(GameStateConditionType.Template == this.conditionType)
			{
				return this.template != null ?
					this.template.ToString() : "";
			}
			return "";
		}
	}
}
