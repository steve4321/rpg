﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Quartic/Quartic In", "Quartic easing in, accelerating from zero velocity.",
		sortIndex=3)]
	public class QuarticInInterpolation : BaseInterpolation
	{
		public QuarticInInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			elapsedTime = (elapsedTime > duration) ? 1.0f : elapsedTime / duration;
			return distance * elapsedTime * elapsedTime * elapsedTime * elapsedTime + start;
		}
	}

	[EditorSettingInfo("Quartic/Quartic Out", "Quartic easing out, decelerating to zero velocity.",
		sortIndex=3)]
	public class QuarticOutInterpolation : BaseInterpolation
	{
		public QuarticOutInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			elapsedTime = (elapsedTime > duration) ? 1.0f : elapsedTime / duration;
			elapsedTime--;
			return -distance * (elapsedTime * elapsedTime * elapsedTime * elapsedTime - 1) + start;
		}
	}

	[EditorSettingInfo("Quartic/Quartic In + Out", "Quartic easing in/out, acceleration until halfway, then deceleration.",
		sortIndex=3)]
	public class QuarticInOutInterpolation : BaseInterpolation
	{
		public QuarticInOutInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			elapsedTime = (elapsedTime > duration) ? 2.0f : elapsedTime / (duration / 2);
			if(elapsedTime < 1)
			{
				return distance / 2 * elapsedTime * elapsedTime * elapsedTime * elapsedTime + start;
			}
			elapsedTime -= 2;
			return -distance / 2 * (elapsedTime * elapsedTime * elapsedTime * elapsedTime - 2) + start;
		}
	}
}
