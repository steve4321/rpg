
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseNode : BaseTypeData
	{
		[EditorHide]
		public Vector2 nodePosition = new Vector2(38, 38);

		[EditorHelp("Override Node Name", "Override the name this node displays in the node editor.", "")]
		[EditorInfo(isToggleLeft=true)]
		[EditorHide]
		[EditorWidth(150)]
		public bool overrideNodeName = false;

		[EditorHelp("Node Name", "The name that will be displayed for this node.", "")]
		[EditorHide]
		[EditorWidth(true, hideName=true)]
		[EditorCondition("overrideNodeName", true)]
		[EditorEndCondition]
		public string nodeName = "";

		[EditorHide]
		public int nodeLayer = 0;

		[EditorHide]
		public int nodeGroup = -1;

		public virtual bool IsRemovable()
		{
			return true;
		}

		public virtual bool IsConnectable(int layer)
		{
			return true;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public virtual string GetNodeName()
		{
			return "Node";
		}

		public virtual string GetNodeDetails()
		{
			return "Details";
		}

		public virtual string GetNextName(int index)
		{
			return "Next " + index;
		}


		/*
		============================================================================
		Next functions
		============================================================================
		*/
		public virtual int GetNextCount()
		{
			return 0;
		}

		public virtual int GetNext(int index)
		{
			return -1;
		}

		public virtual void SetNext(int index, int next)
		{

		}

		public int GetFirstFree()
		{
			for(int i = 0; i < this.GetNextCount(); i++)
			{
				if(this.GetNext(i) == -1)
				{
					return i;
				}
			}
			return 0;
		}


		/*
		============================================================================
		Enable functions
		============================================================================
		*/
		public virtual bool IsEnabled
		{
			get { return true; }
			set { }
		}

		public virtual bool ShowEnableToggle
		{
			get { return false; }
		}

		public virtual bool IsBreakpoint
		{
			get { return false; }
			set { }
		}




		/*
		============================================================================
		Position functions
		============================================================================
		*/
		public virtual void SetPosition(int layer, Vector2 position)
		{
			this.nodePosition = position;
		}

		public virtual Vector2 GetPosition(int layer)
		{
			return this.nodePosition;
		}


		/*
		============================================================================
		Node group functions
		============================================================================
		*/
		public virtual void SetNodeGroup(int layer, int index)
		{
			this.nodeGroup = index;
		}

		public virtual int GetNodeGroup(int layer)
		{
			return this.nodeGroup;
		}

		public virtual void GroupRemoved(int index)
		{
			if(index <= this.nodeGroup)
			{
				this.nodeGroup--;
			}
		}


		/*
		============================================================================
		Layer functions
		============================================================================
		*/
		public virtual bool IsOnLayer(int layer)
		{
			return this.nodeLayer == layer;
		}

		public virtual bool RemoveLayer(int layer)
		{
			if(this.nodeLayer > layer)
			{
				this.nodeLayer--;
				return false;
			}
			return this.nodeLayer == layer;
		}


		/*
		============================================================================
		Color functions
		============================================================================
		*/
		public virtual Color EditorColor
		{
			get { return new Color(1, 1, 1, 1); }
		}


		/*
		============================================================================
		Debug
		============================================================================
		*/
		public class DebugInfo
		{
			public int nodeIndex = -1;

			public float maxTime = -1;

			public float time = 0;

			public List<string> info;

			public DebugInfo(int nodeIndex)
			{
				this.nodeIndex = nodeIndex;
			}
		}
	}
}
