﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = false)]
	public class EditorTitleLabelAttribute : System.Attribute
	{
		public string text = "";

		public EditorTitleLabelAttribute(string text)
		{
			this.text = text;
		}
	}

	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = false)]
	public class EditorLabelAttribute : System.Attribute
	{
		public string text = "";

		public EditorLabelAttribute(string text)
		{
			this.text = text;
		}
	}
}
