
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public interface ICompressionHandler
	{
		/*
		============================================================================
		String compression functions
		============================================================================
		*/
		string CompressString(string text);

		string DecompressString(string text);
	}
}
