
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class NameContentSorter<T> : IComparer<T> where T : IContent
	{
		private bool invert = false;

		public NameContentSorter(bool invert)
		{
			this.invert = invert;
		}

		public int Compare(T x, T y)
		{
			if(this.invert)
			{
				return y.GetName().CompareTo(x.GetName());
			}
			else
			{
				return x.GetName().CompareTo(y.GetName());
			}
		}
	}
}
