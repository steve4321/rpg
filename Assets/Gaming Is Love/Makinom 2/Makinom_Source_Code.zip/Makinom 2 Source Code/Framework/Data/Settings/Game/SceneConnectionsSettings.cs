﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public enum SceneConnectionSearch { One, Multi, All };

	public class SceneConnectionsSettings : BaseSettings
	{
		[EditorHelp("Connection Path Search", "Select how many paths are searched:\n" +
			"- One: The first found path will be used.\n" +
			"- Multi: All (unique) paths with the same number of scenes will be used.\n" +
			"- All: All (unique) paths will be used.", "")]
		[EditorFoldout("General Settings", "General scene connection and path settings.", "")]
		[EditorEndFoldout]
		public SceneConnectionSearch connectionSearch = SceneConnectionSearch.One;


		// added data
		[EditorFoldout("Scene Connections", "Add scene connection information manually.\n" +
			"The manually added connection information won't be lost when scanning the scenes.\n" +
			"Scene connection information is used to find the correct way to a marker in navigation HUDs.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Scene Connection", "Adds scene connection information.", "",
			"Remove", "Removes this scene connection.", "",
			foldout=true, foldoutText=new string[] {
				"Scene Connection", "The name and connection data of the scene.", ""
		})]
		public SceneConnection[] connections = new SceneConnection[0];


		// scanned data
		[EditorHide]
		[EditorArray(isRemove=true, removeText=new string[] {
				"Remove", "Removes this scanned scene.", ""
			},
			foldout=true, foldoutText=new string[] {
				"Scanned Scene", "The scene changers found in this scene.", ""
		})]
		public SceneConnection[] scannedConnections;

		public SceneConnectionsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Scene Connections"; }
		}


		/*
		============================================================================
		Navigation functions
		============================================================================
		*/
		public virtual bool Find(string currentScene, string targetScene, NavigationMarker marker)
		{
			bool found = false;
			DataCall call = new DataCall();
			Dictionary<string, List<SceneConnectionSceneChanger>> list = this.CreateSceneList(call);

			if(list.ContainsKey(currentScene))
			{
				List<SceneConnectionSceneChanger> originalChangers = list[currentScene];
				list.Remove(currentScene);

				Dictionary<int, List<string>> tmp = new Dictionary<int, List<string>>();
				Dictionary<int, List<string>> tmp2;

				for(int i = 0; i < originalChangers.Count; i++)
				{
					if(originalChangers[i].condition.Check(call))
					{
						bool found2 = false;
						List<string> scenes = new List<string>();
						if(originalChangers[i].CheckTargets(call, targetScene, ref scenes))
						{
							marker.AddPosition(originalChangers[i].position);

							if(SceneConnectionSearch.One == this.connectionSearch)
							{
								return true;
							}
							else
							{
								found = true;
								found2 = true;
							}
						}
						if(!found2 && scenes.Count > 0)
						{
							tmp.Add(i, scenes);
						}
					}
				}

				while((SceneConnectionSearch.All == this.connectionSearch || !found) &&
					tmp.Count > 0)
				{
					List<string> removeList = new List<string>();
					tmp2 = new Dictionary<int, List<string>>();

					foreach(KeyValuePair<int, List<string>> pair in tmp)
					{
						bool found2 = false;
						List<string> scenes = new List<string>();
						if(this.CheckScene(call, pair.Value, targetScene, ref list, ref scenes))
						{
							marker.AddPosition(originalChangers[pair.Key].position);

							if(SceneConnectionSearch.One == this.connectionSearch)
							{
								return true;
							}
							else
							{
								found = true;
								found2 = true;
							}
						}
						if(!found2 && scenes.Count > 0)
						{
							tmp2.Add(pair.Key, scenes);
						}
						removeList.AddRange(pair.Value);
					}

					for(int i = 0; i < removeList.Count; i++)
					{
						list.Remove(removeList[i]);
					}

					tmp = tmp2;
				}
			}
			return found;
		}

		protected virtual bool CheckScene(DataCall call, List<string> currentScene, string targetScene,
			ref Dictionary<string, List<SceneConnectionSceneChanger>> list, ref List<string> scenes)
		{
			for(int i = 0; i < currentScene.Count; i++)
			{
				if(list.ContainsKey(currentScene[i]))
				{
					List<SceneConnectionSceneChanger> sceneChangers = list[currentScene[i]];

					for(int j = 0; j < sceneChangers.Count; j++)
					{
						if(sceneChangers[j].condition.Check(call) &&
							sceneChangers[j].CheckTargets(call, targetScene, ref scenes))
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		protected virtual Dictionary<string, List<SceneConnectionSceneChanger>> CreateSceneList(DataCall call)
		{
			Dictionary<string, List<SceneConnectionSceneChanger>> list = new Dictionary<string, List<SceneConnectionSceneChanger>>();

			for(int i = 0; i < this.connections.Length; i++)
			{
				if(list.ContainsKey(this.connections[i].sceneName))
				{
					list[this.connections[i].sceneName].AddRange(this.connections[i].sceneChanger);
				}
				else
				{
					list.Add(this.connections[i].sceneName,
						new List<SceneConnectionSceneChanger>(this.connections[i].sceneChanger));
				}
			}
			if(this.scannedConnections != null)
			{
				for(int i = 0; i < this.scannedConnections.Length; i++)
				{
					if(list.ContainsKey(this.scannedConnections[i].sceneName))
					{
						list[this.scannedConnections[i].sceneName].AddRange(this.scannedConnections[i].sceneChanger);
					}
					else
					{
						list.Add(this.scannedConnections[i].sceneName,
							new List<SceneConnectionSceneChanger>(this.scannedConnections[i].sceneChanger));
					}
				}
			}

			return list;
		}
	}
}
