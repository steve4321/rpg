
using System.IO;
using System.Collections.Generic;
using UnityEngine;

namespace GamingIsLove.Makinom
{
	// TODO: auto backups - even if backup disabled in save
	// automatically backup on save when last backup is X old
	// save handler (UI) shows auto save message before saving
	public class BackupSettings : BaseSettings
	{
		[EditorHelp("Number of Backups", "Set how many backups of your project data will be stored.\n" +
			"Set to 0 if you don't want to keep any backups.", "")]
		[EditorFoldout("Backup Settings", "General backup settings.", "")]
		[EditorEndFoldout]
		[EditorLabel("Backups create a unitypackage file including everything in the data folder " + 
			"(usually 'Assets/Gaming Is Love/_Data/'), but without assets referenced by the data assets.\n" + 
			"To keep Unity GUIDs consistant, only restore backups via the Makinom editor instead of importing the package.")]
		public int numberOfBackups = 10;

		public BackupSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Backup Settings"; }
		}
	}
}

