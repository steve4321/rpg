﻿
using UnityEngine;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.Makinom
{
	public class TextCodeSettings : BaseSettings
	{
		[EditorArray("Add Custom Text Code", "Adds a custom text code.", "",
			"Remove", "Removes this custom text code.", "",
			isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Custom Text Code", "Define the text code and its replacement text.", ""
		})]
		public CustomTextCode[] textCode = new CustomTextCode[0];

		public TextCodeSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Text Codes"; }
		}


		/*
		============================================================================
		Text code functions
		============================================================================
		*/
		public string[] GetTextCodes()
		{
			string[] tmp = new string[this.textCode.Length];
			for(int i = 0; i < this.textCode.Length; i++)
			{
				tmp[i] = this.textCode[i].textCode;
			}
			return tmp;
		}

		public void ReplaceCustomTextCodes(UIText text)
		{
			for(int i = 0; i < this.textCode.Length; i++)
			{
				this.textCode[i].Replace(text);
			}
		}

		public void ReplaceCustomTextCodes(ref string text)
		{
			for(int i = 0; i < this.textCode.Length; i++)
			{
				this.textCode[i].Replace(ref text);
			}
		}
	}
}
