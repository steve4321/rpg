
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public enum EditorHelpType { None, Hover, Focus, Button }
	public enum SchematicEditorMenuType { Left, Right, Top, Bottom }
	public enum EditorCopyNameType { None, AppendFront, AppendBack };

	public class EditorSettings : BaseSettings
	{
		[EditorHelp("Copy Name Type", "Select how the name of copied data will be changed:\n" +
			"- None: Keeps the original name.\n" +
			"- Append Front: Adds 'COPY ' at the front of the name.\n" +
			"- Append Back: Adds ' COPY' at the back of the name.")]
		[EditorFoldout("Editor Settings", "General editor settings.", "")]
		public EditorCopyNameType copyNameType = EditorCopyNameType.AppendFront;


		// editor help text display
		[EditorHelp("Editor Help Display", "Select when the editor help will be displayed:\n" +
			"- None: Help texts won't be displayed.\n" +
			"- Hover: When hovering over a setting.\n" +
			"- Focus: When a setting is focused.\n" +
			"- Button: Display a '?' button next to the setting.")]
		[EditorSeparator]
		[EditorCallback("button:editorhelpexport", EditorCallbackType.After)]
		public EditorHelpType editorHelpType = EditorHelpType.Hover;


		// help text color
		[EditorHelp("Set Help Text Color", "Change the color used to display help texts.")]
		[EditorSeparator]
		public bool setHelpTextColor = false;

		[EditorHelp("Help Text Color", "Select the color that is used to display help texts.")]
		[EditorIndent]
		[EditorCondition("setHelpTextColor", true)]
		[EditorEndCondition]
		public Color helpTextColor = Color.black;


		// drag bars
		[EditorHelp("Sub-Section Separators", "Show separators between sub-section button groups.")]
		[EditorSeparator]
		public bool showSubSectionSeparators = true;

		[EditorHelp("Enable drag bars", "Enable the use of drag bars in the editor.\n" +
			"Drag bars are used to change the size of the help text display, sub-sections and data lists.")]
		[EditorCallback("button:resetDrag", EditorCallbackType.After)]
		public bool enableDrag = true;


		// settings copy/paste context menu
		[EditorHelp("Use Context Menu Copy", "Allow using a context menu to copy/paste settings.\n" +
			"The context menu can be opened on settings via a context click.\n" +
			"Disable this setting in case you run into errors related to 'StartContextClick' or 'EndContextClick'.")]
		[EditorSeparator]
		public bool useCopyContextMenu = true;

		[EditorHelp("Copied Setting Highlight", "Define the color that will be used to highlight settings that where copied to the clipboard.\n" +
			"This is used to know which settings have been copied.\n" +
			"You can copy/paste settings by right-clicking on them and selecting the operation in the context menu.")]
		[EditorCondition("useCopyContextMenu", true)]
		[EditorEndCondition]
		public Color copiedSettingHighlightColor = new Color(0.7f, 0.7f, 1);


		// search settings
		[EditorHelp("Search Setting Highlight", "Define the color that will be used to highlight found settings when using the search bar.")]
		[EditorSeparator]
		[EditorTitleLabel("Search Settings")]
		public Color searchSettingHighlightColor = Color.yellow;

		[EditorHelp("Search Jump List Highlight", "Define the color that will be used to higlight foldouts with found settings in the jump list.")]
		public Color searchJumpListHighlightColor = Color.yellow;

		[EditorHelp("Search Auto Scroll", "Automatically scroll to the first highlighted setting when changing the search entry.")]
		public bool searchAutoScroll = true;


		// foldout settings
		[EditorHelp("Pretty Foldouts", "A foldouts title and margin will depend on it's depth.")]
		[EditorSeparator]
		[EditorTitleLabel("Foldout Settings")]
		public bool prettyFoldouts = true;

		[EditorHelp("Extended Information", "Some foldouts display extended information in their title.\n" +
			"E.g. foldouts of array elements showing details on their setup.")]
		public bool foldoutExtendedInformation = true;

		[EditorHelp("Show Foldout Help", "Show the foldout's help text below the foldout header when it's expanded.")]
		public bool showFoldoutHelp = false;

		[EditorHelp("Space after Foldout", "Add some space after closing a foldout.")]
		public bool foldoutSeparator = false;

		[EditorHelp("Remember Last Section", "Remember the last section and sub-section you've had opened in the editor.")]
		public bool rememberLastSection = true;

		[EditorHelp("Remember Foldouts", "Remember the last state of foldouts in the editor.\n" +
			"You need to close (after saving) and re-open the editor in order for this setting to be used.")]
		public bool rememberFoldouts = false;

		[EditorHelp("Use Foldout Colors", "Allow changing colors of foldouts.")]
		public bool useFoldoutColors = true;

		[EditorHelp("Use In Jumplist", "The foldout color will also be used in the jumplist (text color).")]
		[EditorIndent]
		[EditorCondition("useFoldoutColors", true)]
		[EditorEndCondition]
		public bool foldoutColorJumplist = true;

		[EditorHelp("Scroll Index Change", "Keep the scroll position consistent when changing between data list entries.\n" +
			"The scroll position will be kept relative to the closest root foldout settings.")]
		public bool scrollFoldoutIndexChange = true;


		// other
		[EditorHelp("Highlight Value Fields", "Advanced value fields consisting of multiple fields/selections " +
			"will be highlighted to mark which fields belong together.\n" +
			"This is used by string, bool, float and Vector3 value fields that allow using " +
			"different value origins like defined values or variables.")]
		[EditorSeparator]
		public bool highlightValueFields = true;

		[EditorHelp("Show Jump List", "Display the foldout quick jump list.")]
		public bool showJumpList = true;

		[EditorHelp("Max Depth", "The maximum foldout depth that will be displayed in the jumplist.")]
		[EditorIndent]
		[EditorCondition("showJumpList", true)]
		[EditorLimit(1, false)]
		public int maxJumpListDepth = 3;

		[EditorHelp("Highlight Visible List", "Highlight the currently visible foldouts in the quick jump list.")]
		[EditorIndent]
		[EditorEndCondition]
		public bool highlightVisibleJumpList = true;

		[EditorHelp("Allow View Limiting", "You can limit the displayed settings to a single root foldout.\n" +
			"Shows a popup selection in the foldout quick jump list and navigation buttons above and below the settings.")]
		public bool allowViewLimiting = true;

		[EditorHelp("Settings Buttons", "Show view limit buttons on top and below the settings area.")]
		[EditorIndent]
		[EditorCondition("allowViewLimiting", true)]
		public bool viewLimitSettingsButtons = true;

		[EditorHelp("Search Bar Buttons", "Show view limit buttons in the search bar.")]
		[EditorIndent]
		[EditorEndCondition]
		public bool viewLimitSearchBarButtons = true;


		// custom text area
		[EditorHelp("Use Custom Text Area", "Use the editor text area instead of the default Unity text area.")]
		[EditorTitleLabel("Text Area")]
		[EditorSeparator]
		public bool useCustomTextArea = true;

		[EditorHelp("Set Text Area Color", "Set the color used to display text area texts.")]
		public bool setTextAreaColor = false;

		[EditorHelp("Text Area Color", "Select the color that is used to display text area texts.")]
		[EditorIndent]
		[EditorCondition("setTextAreaColor", true)]
		[EditorEndCondition]
		public Color textAreaColor = Color.black;

		[EditorHelp("Text Area Height", "The height of the text area when editing text.")]
		[EditorLimit(100.0f)]
		public float textAreaHeight = 200.0f;

		[EditorHelp("Max Preview Height", "The maximum height of the text preview displayed in settings.\n" +
			"The text preview is displayed if a text isn't edited.")]
		[EditorEndFoldout]
		[EditorLimit(0.0f)]
		[EditorCondition("useCustomTextArea", true)]
		public float textAreaPreviewHeight = 50.0f;


		// hotkeys
		[EditorHelp("Sub-Section", "Use 'ALT + Page Up' and 'ALT + Page Down' to browse through sub-sections.")]
		[EditorFoldout("Hotkey Settings", "Enable editor hotkeys.", "")]
		public bool subHK = true;

		[EditorHelp("Data List Index", "Use 'Page Up' and 'Page Down' to browse through data lists (e.g. Items).")]
		public bool tabHK = true;

		[EditorHelp("Settings Scroll", "Use 'Home' to scroll to the top and 'End' to scroll to the bottom of the settings area.")]
		public bool settingsScrollHK = true;

		[EditorHelp("Save", "Use 'ALT + S' to save.")]
		public bool saveHK = true;

		[EditorHelp("Load", "Use 'ALT + L' to load.")]
		public bool loadHK = true;

		[EditorHelp("Navigation History", "Use 'ALT + Home' to go back and 'ALT + End' to go forward in the navigation history.")]
		[EditorEndFoldout]
		public bool navigationHistoryHK = true;



		// popup settings
		[EditorHelp("Show All Layers", "All layers will be visible in layer mask fields, not only named ones.\n" +
			"Please note that the last layer (31) will not be displayed!")]
		[EditorFoldout("Popup Field Settings", "Settings for popup fields in the editor.", "")]
		public bool showAllLayers = false;

		[EditorHelp("Auto Variable Popup", "Automatically display matching variable keys and other data " +
			"as a popup selection when typing in string value fields.")]
		public bool autoVariablePopup = true;

		[EditorHelp("Auto Reflection Popup", "Automatically display matching reflection data (e.g. class names) " +
			"as a popup selection when typing in reflection string fields.")]
		public bool autoReflectionPopup = true;

		[EditorHelp("Extended Popups", "A popup field's width will be extended (i.e. popup fields will be longer).")]
		public bool popupLonger = false;

		[EditorHelp("Separate Enums", "Enum popup fields will be separated into sub-lists (in some cases).")]
		[EditorCondition("popupSortEnums", true)]
		[EditorEndCondition]
		public bool popupSeparateEnums = true;

		[EditorHelp("Type Separation", "Data selection popup fields will be separated by types (if available).")]
		public bool popupTypeSeparation = false;

		[EditorHelp("Asset Description Tooltip", "Show the description defined in an asset's settings (e.g. input keys) as tooltip in popup selections.")]
		public bool popupAssetTooltip = true;

		[EditorHelp("Selection Tooltip", "Show tooltip for available selections in popup selections.")]
		[EditorEndFoldout]
		public bool popupTooltip = false;


		// editor drag bars
		[EditorHide]
		public float helpDisplayHeight = 220;

		[EditorHide]
		public float subSectionWidth = 250;

		[EditorHide]
		public float tabListWidth = 250;

		[EditorHide]
		public float formulaHeight = 400;

		[EditorHide]
		public float aiHeight = 400;

		[EditorHide]
		public float nodeEditorHeight = 400;


		// node editor
		[EditorHelp("Initial Node Anchor", "Select where the initially selected node (i.e. the settings node) will be displayed.")]
		[EditorFoldout("Node Editor Settings", "Settings for the node editor.", "")]
		public TextAnchor nodeInitialAnchor = TextAnchor.MiddleCenter;

		[EditorHelp("Focus Node Anchor", "Select where the nodes will be displayed when using 'F' to focus on the selected nodes.")]
		public TextAnchor nodeFocusAnchor = TextAnchor.MiddleCenter;

		[EditorHelp("Flexible Lines", "The lines will connect to either the top, bottom, " +
			"left or right side of a node, depending on the position of the two connected nodes.\n" +
			"If disabled, the lines will always connect to the top.")]
		public bool nodesFlexibleLines = true;

		[EditorHelp("Snap to Grid", "The nodes will automatically be " +
			"placed on the grid when releasing them after dragging.\n" +
			"This setting can also be toggled in the node editor.")]
		[EditorSeparator]
		public bool nodesDragGrid = true;

		[EditorHelp("Show Grid", "Display a grid below the nodes.\n" +
			"This setting can also be toggled in the node editor.")]
		public bool showNodesGrid = true;

		[EditorHelp("Show Enable Toggle", "Display an enable/disable toggle on the nodes.\n" +
			"This setting can also be toggled in the node editor.")]
		public bool showNodeEnableToggle = true;

		[EditorHelp("Show Node Folder Info", "Display the folders/sub-folders in which the node can be found in when displaying it's settings.\n" +
			"The folders/sub-folders will be listed at the top of the node's settings.")]
		public bool showNodeFolderInfo = false;

		[EditorHelp("Merge Single Slot", "The 'Next' slot of single-slot nodes will be part of the info area.\n" +
			"This setting can also be toggled in the node editor.")]
		public bool mergeSingleSlot = true;

		[EditorHelp("Max Zoom", "The maximum factor that can be zoomed out.")]
		[EditorLimit(1.5f)]
		public float nodeMaxZoom = 5;

		[EditorHelp("Scroll Trackpad Mode", "Use the trackpad (scroll wheel input) as node area scroll instead of zooming.\n" +
			"You can flip between horizontal/vertical scrolling by holding down the control key ('CTRL').")]
		[EditorSeparator]
		public bool nodeScrollTrackpadMode = false;

		[EditorHelp("Horizontal Scroll", "Scroll horizontally instead of vertically.\n" +
			"You can flip between horizontal/vertical scrolling by holding down the control key ('CTRL').")]
		[EditorIndent]
		[EditorCondition("nodeScrollTrackpadMode", true)]
		public bool nodeScrollTrackpadHorizontal = false;

		[EditorHelp("Scroll Change", "Defines how much is scrolled per trackpad/scroll wheel input.\n" +
			"X is for horizontal scrolling, Y for vertical scrolling.\n" +
			"Use negative values to inverse the scroll direction.")]
		[EditorIndent]
		[EditorEndCondition]
		public Vector2 nodeScrollTackpadChange = new Vector2(10, 10);

		[EditorHelp("Hold Shift Zoom", "Zooming via scroll wheel is only used while holding the 'Shift' key.")]
		public bool nodeScrollZoomShift = false;

		[EditorHelp("Scroll Zoom Change", "The value used to change the zoom factor using the scroll wheel.")]
		[EditorLimit(0.1f)]
		[EditorCondition("nodeScrollZoomShift", true)]
		[EditorCondition("nodeScrollTrackpadMode", false)]
		[EditorEndCondition]
		public float nodeScrollZoomChange = 0.2f;

		// schematics
		[EditorHelp("Schematic Editor Menu", "Select where the schematic editor's settings menu and help texts are displayed.")]
		[EditorSeparator]
		[EditorTitleLabel("Schematic Node Editor")]
		public SchematicEditorMenuType schematicMenuType = SchematicEditorMenuType.Bottom;

		// last opened schematics list
		[EditorHelp("Last Opened Schematics", "The quantity of last opened schematics that will be remembered.")]
		[EditorLimit(1)]
		public int lastOpenedSchematics = 20;

		[EditorHelp("Open Last Schematic", "Open the last opened schematic when opening the editor.")]
		public bool openLastSchematic = false;

		[EditorHelp("Auto Debug Schematics", "Automatically collect debug information for running schematics.\n" +
			"If disabled, debug information is only collected after the Makinom editor is open.\n" +
			"Please note that collecting debug information of running schematics can have an impact on performance. " +
			"This is only used when playing in the editor, not in a built/exported game.")]
		public bool schematicAutoDebug = false;

		[EditorHelp("Auto Start Debugging", "Automatically start debugging a schematic using the first running instance when it's open in the node editor.")]
		public bool schematicAutoStartDebug = false;

		// basic node colors
		[EditorHelp("Start Node", "The color of the start node.")]
		[EditorTitleLabel("Basic Node Colors")]
		[EditorSeparator]
		public Color startNodeColor = new Color(0.6f, 1, 0.6f, 1);

		[EditorHelp("Layer Gate Nodes", "The color of layer gate nodes.")]
		public Color layerGateNodeColor = new Color(1, 1, 0.5f, 1);

		[EditorHelp("Base Nodes", "The color of basic nodes, not assigned to a specific type.")]
		public Color baseNodeColor = new Color(1, 1, 1, 1);

		[EditorHelp("Selected Node", "The color of the selected node.")]
		public Color selectedNodeColor = new Color(0.6f, 0.8f, 1, 1);

		[EditorHelp("Selected Slot", "The color of the selected slot.")]
		public Color selectedSlotColor = new Color(0.45f, 0.65f, 0.85f, 1);

		[EditorHelp("Disabled Nodes", "The color of disabled nodes.")]
		public Color disabledNodeColor = new Color(0.6f, 0.6f, 0.6f, 1);

		[EditorHelp("Unreachable Nodes", "The color of unreachable nodes.")]
		[EditorCallback("button:resetBasicNodeColors", EditorCallbackType.After)]
		public Color unreachableNodeColor = new Color(1, 0.4f, 0.4f, 1);

		// type node colors
		[EditorHelp("Colorize Node Types", "Different types of nodes " +
			"(e.g. handling game objects or variables) will have different colors.")]
		[EditorTitleLabel("Type Node Colors")]
		[EditorSeparator]
		public bool colorizeNodeTypes = true;

		[EditorHelp("Animation Nodes", "The color of animation related nodes (e.g. animation, audio).")]
		public Color animationNodeColor = new Color(1, 0.69f, 0.247f, 1);

		[EditorHelp("Function Nodes", "The color of function related nodes (e.g. call function, check fields).")]
		public Color functionNodeColor = new Color(0.831f, 0.373f, 1, 1);

		[EditorHelp("Game Object Nodes", "The color of game object related nodes (e.g. movement, components).")]
		public Color gameObjectNodeColor = new Color(0.808f, 1, 0.439f, 1);

		[EditorHelp("Game Nodes", "The color of game related nodes (e.g. save games, scene loading).")]
		public Color gameNodeColor = new Color(1, 0.498f, 0.365f, 1);

		[EditorHelp("Input Nodes", "The color of input related nodes (e.g. input key).")]
		public Color inputNodeColor = new Color(1, 1, 0, 1);

		[EditorHelp("Machine Nodes", "The color of machine related nodes (e.g. start tagged machine).")]
		public Color machineNodeColor = new Color(0.533f, 0.655f, 0.804f, 1);

		[EditorHelp("Movement Nodes", "The color of movement related nodes (e.g. nav mesh, rotation, movement).")]
		public Color movementNodeColor = new Color(0.463f, 0.831f, 1, 1);

		[EditorHelp("UI Nodes", "The color of UI related nodes (e.g. dialogues).")]
		public Color uiNodeColor = new Color(0.278f, 1, 0.839f, 1);

		[EditorHelp("Value Nodes", "The color of value related nodes (e.g. variables).")]
		[EditorCallback("button:resetTypeNodeColors", EditorCallbackType.After)]
		public Color valueNodeColor = new Color(1, 0.365f, 0.635f, 1);

		// connection colors
		[EditorHelp("Child Connection", "The color of connections to child nodes.")]
		[EditorTitleLabel("Connection Colors")]
		[EditorSeparator]
		public Color childConnectionColor = new Color(0, 0.9f, 0, 1);

		[EditorHelp("Parent Connection", "The color of connections to parent nodes.")]
		[EditorCallback("button:resetNodeConnectionColors", EditorCallbackType.After)]
		public Color parentConnectionColor = new Color(0, 0, 0.9f, 1);

		// grid colors
		[EditorHelp("Grid Line", "The color of grid lines.")]
		[EditorTitleLabel("Grid Colors")]
		[EditorSeparator]
		public Color gridLineColor = new Color(0.122f, 0.173f, 0.22f, 1);

		[EditorHelp("Grid Line Full", "The color of full grid lines.")]
		public Color gridLineFullColor = new Color(0.063f, 0.086f, 0.11f, 1);

		[EditorHelp("Grid Background", "The color of grid background.")]
		[EditorCallback("button:resetNodeGridColors", EditorCallbackType.After)]
		public Color gridBackgroundColor = new Color(0.204f, 0.286f, 0.369f, 1);

		// debug colors
		[EditorHelp("Debug Connection", "The color of connections that where used during debugging.")]
		[EditorTitleLabel("Debug Colors")]
		[EditorSeparator]
		public Color debugConnectionColor = Color.yellow;

		[EditorHelp("Debug Connection Current", "The color of the last used connection during debugging.")]
		public Color debugConnectionCurrentColor = new Color(1, 0.5f, 0, 1);

		[EditorHelp("Debug Node", "The color of nodes that where used during debugging.")]
		public Color debugNodeColor = Color.yellow;

		[EditorHelp("Debug Node Current", "The color of the current node while during debugging.")]
		[EditorEndFoldout]
		[EditorCallback("button:resetDebugColors", EditorCallbackType.After)]
		public Color debugNodeCurrentColor = new Color(1, 0.5f, 0, 1);

		public EditorSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Editor Settings"; }
		}
	}
}

