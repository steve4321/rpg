
using UnityEngine;
using System.Text;
using System.Reflection;

namespace GamingIsLove.Makinom.Reflection
{
	public class CallFunction<T> : BaseData where T : IObjectSelection, new()
	{
		[EditorHelp("Class Name", "The name of the class that contains the function.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Class, typeof(Component))]
		public string className = "";

		[EditorHelp("Function Name", "The name of the function that will be called.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Function, typeof(Component), "className")]
		public string functionName = "";

		// parameters
		[EditorArray("Add Parameter", "Adds a parameter that will be used when calling the function.", "",
			"Remove", "Removes this parameter.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] { "Parameter", "The parameter will be used when calling the function.", "" })]
		public CallParameter<T>[] parameter = new CallParameter<T>[0];

		public CallFunction()
		{

		}

		public virtual bool NeedsCall
		{
			get
			{
				for(int i = 0; i < this.parameter.Length; i++)
				{
					if(this.parameter[i].NeedsCall)
					{
						return true;
					}
				}
				return false;
			}
		}

		public bool Call(object instance, IDataCall call, bool isStatic)
		{
			if(this.className != "" && this.functionName != "")
			{
				System.Type instanceType = isStatic ?
					Maki.ReflectionHandler.GetType(this.className) :
					Maki.ReflectionHandler.GetTypeOrInterface(this.className, typeof(Component));
				if(instanceType != null)
				{
					if(!isStatic && instance is GameObject)
					{
						instance = ((GameObject)instance).GetComponent(instanceType);
						if(instance == null)
						{
							Debug.LogWarning("Component not found on game object: " + this.className);
						}
					}

					if(isStatic || instance != null)
					{
						if(this.parameter.Length > 0)
						{
							System.Type[] types = new System.Type[this.parameter.Length];
							object[] values = new object[this.parameter.Length];

							for(int i = 0; i < this.parameter.Length; i++)
							{
								if(ParameterType.Enum == this.parameter[i].type)
								{
									types[i] = ReflectionTypeHandler.Instance.GetEnumType(this.parameter[i].enumName);
								}
								else
								{
									types[i] = EnumConverter.ToType(this.parameter[i].type);
								}
								values[i] = this.parameter[i].GetParameterValue(call);
							}

							MethodInfo methodInfo = Maki.ReflectionHandler.GetMethod(
								this.functionName, types, ref instance, ref instanceType);
							if(methodInfo != null)
							{
								try
								{
									methodInfo.Invoke(isStatic ? null : instance, values);
									return true;
								}
								catch(System.Exception ex)
								{
									Debug.LogWarning("Method call failed (" + instanceType + "): " +
										this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
								}
							}
							else
							{
								Debug.LogWarning("Method not found (" + instanceType + "): " + this.functionName);
							}
						}
						else
						{
							MethodInfo methodInfo = Maki.ReflectionHandler.GetMethod(
								this.functionName, new System.Type[] { }, ref instance, ref instanceType);
							if(methodInfo != null)
							{
								try
								{
									methodInfo.Invoke(isStatic ? null : instance, null);
									return true;
								}
								catch(System.Exception ex)
								{
									Debug.LogWarning("Method call failed (" + instanceType + "): " +
										this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
								}
							}
							else
							{
								Debug.LogWarning("Method not found (" + instanceType + "): " + this.functionName);
							}
						}
					}
				}
				else
				{
					Debug.LogWarning("Component type not found: " + this.className);
				}
			}
			return false;
		}

		public object GetReturnValue(object instance, IDataCall call, bool isStatic)
		{
			if(this.className != "" && this.functionName != "")
			{
				System.Type instanceType = isStatic ?
					Maki.ReflectionHandler.GetType(this.className) :
					Maki.ReflectionHandler.GetTypeOrInterface(this.className, typeof(Component));
				if(instanceType != null)
				{
					if(!isStatic && instance is GameObject)
					{
						instance = ((GameObject)instance).GetComponent(instanceType);
						if(instance == null)
						{
							Debug.LogWarning("Component not found on game object: " + this.className);
						}
					}

					if(isStatic || instance != null)
					{
						if(this.parameter.Length > 0)
						{
							System.Type[] types = new System.Type[this.parameter.Length];
							object[] values = new object[this.parameter.Length];

							for(int i = 0; i < this.parameter.Length; i++)
							{
								if(ParameterType.Enum == this.parameter[i].type)
								{
									types[i] = ReflectionTypeHandler.Instance.GetEnumType(this.parameter[i].enumName);
								}
								else
								{
									types[i] = EnumConverter.ToType(this.parameter[i].type);
								}
								values[i] = this.parameter[i].GetParameterValue(call);
							}

							MethodInfo methodInfo = Maki.ReflectionHandler.GetMethod(
								this.functionName, types, ref instance, ref instanceType);
							if(methodInfo != null)
							{
								try
								{
									return methodInfo.Invoke(isStatic ? null : instance, values);
								}
								catch(System.Exception ex)
								{
									Debug.LogWarning("Method call failed (" + instanceType + "): " +
										this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
								}
							}
							else
							{
								Debug.LogWarning("Method not found (" + instanceType + "): " + this.functionName);
							}
						}
						else
						{
							MethodInfo methodInfo = Maki.ReflectionHandler.GetMethod(
								this.functionName, new System.Type[] { }, ref instance, ref instanceType);
							if(methodInfo != null)
							{
								try
								{
									return methodInfo.Invoke(isStatic ? null : instance, null);
								}
								catch(System.Exception ex)
								{
									Debug.LogWarning("Method call failed (" + instanceType + "): " +
										this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
								}
							}
							else
							{
								Debug.LogWarning("Method not found (" + instanceType + "): " + this.functionName);
							}
						}
					}
				}
				else
				{
					Debug.LogWarning("Component type not found: " + this.className);
				}
			}
			return null;
		}

		public override string ToString()
		{
			StringBuilder builder = new StringBuilder(this.className).
				Append(".").Append(this.functionName);
			if(this.parameter.Length > 0)
			{
				builder.Append("(");
				for(int i = 0; i < this.parameter.Length; i++)
				{
					if(i > 0)
					{
						builder.Append(", ");
					}
					builder.Append(this.parameter[i].ToString());
				}
				builder.Append(")");
			}
			return builder.ToString();
		}
	}
}
