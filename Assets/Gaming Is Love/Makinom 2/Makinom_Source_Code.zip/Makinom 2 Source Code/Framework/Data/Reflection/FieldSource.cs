﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	public class FieldSource
	{
		public object instance;

		public string name;

		public FieldSource(object instance, string name)
		{
			this.instance = instance;
			this.name = name;
		}

		public override int GetHashCode()
		{
			unchecked
			{
				int hash = 17;
				hash = hash * 23 + instance.GetHashCode();
				hash = hash * 23 + name.GetHashCode();
				return hash;
			}
		}

		public override bool Equals(object obj)
		{
			if(obj is FieldSource)
			{
				FieldSource other = (FieldSource)obj;
				return this.instance == other.instance &&
					this.name == other.name;
			}
			return false;
		}

		public bool IsAlive()
		{
			return ComponentHelper.IsAlive(instance);
		}
	}
}
