﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/UI/No Tooltip (Scene Game Objects)")]
	public class NoTooltipComponent : MonoBehaviour
	{

	}
}
