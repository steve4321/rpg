﻿
using UnityEngine;
using UnityEngine.AI;
using GamingIsLove.Makinom.Reflection;
using System.Collections.Generic;
using System.Reflection;

namespace GamingIsLove.Makinom.Components
{
	public interface IMoveToInteraction
	{
		void MoveToInteractionStarted(IInteractionBehaviour interaction);

		void MoveToInteractionStopped(IInteractionBehaviour interaction);
	}

	[AddComponentMenu("")]
	public class MoveToInteractionComponent : MonoBehaviour
	{
		// interaction
		protected IInteractionBehaviour interaction;

		protected bool isMoving = false;

		protected Vector3 destination = Vector3.zero;

		private float updateTimestamp = 0;


		// move components
		protected IMovementComponent moveComponent;

		public virtual void Init()
		{
			this.moveComponent = ComponentHelper.GetMovementComponent(this.gameObject);
			if(this.moveComponent == null)
			{
				this.moveComponent = Maki.GameControls.interaction.moveToInteraction.moveComponent.Init(this.gameObject);
			}
		}


		/*
		============================================================================
		Movement functions
		============================================================================
		*/
		public virtual void MoveToInteraction(IInteractionBehaviour interaction)
		{
			if(interaction != null)
			{
				this.interaction = interaction;

				if(this.interaction.MoveToInteractionSettings == null)
				{
					this.StartInteraction();
				}
				else if(this.interaction.MoveToInteractionSettings.destinationObject != null)
				{
					if(!this.SetDestination(this.interaction.MoveToInteractionSettings.destinationObject.transform.position, true, false))
					{
						this.StartInteraction();
					}
				}
				else if(!this.SetDestination(this.interaction.transform.position -
						(this.interaction.transform.position - this.transform.position).normalized *
							(RadiusComponent.GetRadius(this.gameObject) + this.interaction.MoveDestinationOffset), false, false))
				{
					this.StartInteraction();
				}
			}
		}

		protected virtual void Update()
		{
			if(!Maki.Game.Paused &&
				this.isMoving &&
				this.interaction != null)
			{
				if(Maki.GameControls.interaction.moveToInteraction.CancelMovement())
				{
					this.Stop();
					this.interaction = null;
				}
				else if(this.interaction.MoveToInteractionSettings.destinationObject)
				{
					if(VectorHelper.Distance(this.gameObject, this.interaction.MoveToInteractionSettings.destinationObject,
								Maki.GameControls.interaction.moveToInteraction.ignoreDistance,
								Maki.GameControls.interaction.moveToInteraction.ignoreRadius) <
							Maki.GameControls.interaction.moveToInteraction.interactionDistance ||
						(Maki.GameControls.interaction.moveToInteraction.updatePosition &&
							this.updateTimestamp < Time.realtimeSinceStartup &&
							!this.SetDestination(this.interaction.MoveToInteractionSettings.destinationObject.transform.position, true, true)))
					{
						this.StartInteraction();
					}
				}
				else if(VectorHelper.Distance(this.gameObject, this.destination,
								Maki.GameControls.interaction.moveToInteraction.ignoreDistance,
								Maki.GameControls.interaction.moveToInteraction.ignoreRadius) <
							Maki.GameControls.interaction.moveToInteraction.interactionDistance ||
						(Maki.GameControls.interaction.moveToInteraction.updatePosition &&
							this.updateTimestamp < Time.realtimeSinceStartup &&
							!this.SetDestination(this.interaction.transform.position -
						(this.interaction.transform.position - this.transform.position).normalized *
							(RadiusComponent.GetRadius(this.gameObject) + this.interaction.MoveDestinationOffset), false, true)))
				{
					this.StartInteraction();
				}
			}
		}

		protected virtual void StartInteraction()
		{
			this.Stop();
			IInteractionBehaviour tmpInteraction = this.interaction;
			this.interaction = null;
			tmpInteraction.StartInteraction(this.gameObject);
		}


		/*
		============================================================================
		Component functions
		============================================================================
		*/
		public virtual bool SetDestination(Vector3 position, bool force, bool isUpdate)
		{
			if(force ||
				VectorHelper.Distance(this.interaction.gameObject, position,
					Maki.GameControls.interaction.moveToInteraction.ignoreDistance,
					Maki.GameControls.interaction.moveToInteraction.ignoreRadius) <
				VectorHelper.Distance(this.gameObject, this.interaction.gameObject,
					Maki.GameControls.interaction.moveToInteraction.ignoreDistance,
					Maki.GameControls.interaction.moveToInteraction.ignoreRadius))
			{
				if(!isUpdate)
				{
					IMoveToInteraction[] control = this.gameObject.GetComponentsInChildren<IMoveToInteraction>();
					if(control != null)
					{
						for(int i = 0; i < control.Length; i++)
						{
							control[i].MoveToInteractionStarted(this.interaction);
						}
					}
					if(Maki.GameControls.interaction.moveToInteraction.blockPlayer)
					{
						Maki.Control.SetBlockPlayer(1, true);
					}
					if(Maki.GameControls.interaction.moveToInteraction.blockCamera)
					{
						Maki.Control.SetBlockCamera(1, true);
					}
				}

				this.isMoving = true;
				this.updateTimestamp = Time.realtimeSinceStartup + Maki.GameControls.interaction.moveToInteraction.updateTimeout;
				float speed = this.interaction.MoveToInteractionSettings.overrideMoveToSpeed ?
					this.interaction.MoveToInteractionSettings.moveToSpeed.GetValue(
						this.interaction.MoveToInteractionSettings.moveToSpeed.NeedsCall ? new DataCall(this.gameObject) : null) :
					Maki.GameControls.interaction.moveToInteraction.moveSpeed.GetSpeed(this.gameObject,
						Maki.GameControls.interaction.moveToInteraction.moveSpeed.speed.NeedsCall ? new DataCall(this.gameObject) : null);
				this.destination = position;

				if(this.moveComponent != null)
				{
					return this.moveComponent.MoveTo(ref this.destination, speed);
				}
			}
			return false;
		}

		public virtual void Stop()
		{
			if(this.isMoving)
			{
				this.isMoving = false;

				if(this.moveComponent != null)
				{
					this.moveComponent.Stop();
				}

				IMoveToInteraction[] control = this.gameObject.GetComponentsInChildren<IMoveToInteraction>();
				if(control != null)
				{
					for(int i = 0; i < control.Length; i++)
					{
						control[i].MoveToInteractionStopped(this.interaction);
					}
				}

				if(Maki.GameControls.interaction.moveToInteraction.blockPlayer)
				{
					Maki.Control.SetBlockPlayer(-1, true);
				}
				if(Maki.GameControls.interaction.moveToInteraction.blockCamera)
				{
					Maki.Control.SetBlockCamera(-1, true);
				}
			}
		}
	}
}
