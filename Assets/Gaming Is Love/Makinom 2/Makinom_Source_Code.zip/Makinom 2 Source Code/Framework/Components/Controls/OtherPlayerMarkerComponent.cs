﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public class OtherPlayerMarkerComponent : MonoBehaviour
	{
		protected virtual void OnDestroy()
		{
			Maki.Game.Player.RemoveOtherPlayer(this.gameObject);
		}
	}
}
