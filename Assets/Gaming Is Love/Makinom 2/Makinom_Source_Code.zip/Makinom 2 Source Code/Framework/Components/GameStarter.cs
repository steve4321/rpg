
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;
using System.Collections;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Makinom Game Starter")]
	public class GameStarter : MonoBehaviour, ISchematicStarter
	{
		public static bool Reinitialize = false;

		public bool useAssetBundle = false;

		public MakinomProjectAsset project;

		public MakinomProjectAssetBundleLoader assetBundle = new MakinomProjectAssetBundleLoader();


		// start game
		public bool startGame = false;

		public MakinomSchematicAsset schematicAsset;

		protected virtual void Awake()
		{
			if(!Maki.Initialized ||
				GameStarter.Reinitialize)
			{
				if(this.useAssetBundle)
				{
					if(this.assetBundle.loadAsync)
					{
						this.StartCoroutine(this.assetBundle.GetProjectAssetAsync(this.LoadProject));
					}
					else
					{
						this.LoadProject(this.assetBundle.GetProjectAsset());
					}
				}
				else
				{
					this.LoadProject(this.project);
				}
			}
		}

		protected virtual void LoadProject(MakinomProjectAsset projectAsset)
		{
			if(!Maki.Initialized ||
				GameStarter.Reinitialize)
			{
				GameStarter.Reinitialize = false;
				if(projectAsset != null)
				{
					Maki.Initialize(projectAsset);
				}
				else
				{
					Debug.LogError("You must select a Project Asset!");
				}

				this.UseStartOptions();
			}
		}

		protected virtual void UseStartOptions()
		{
			if(!Maki.Game.Running)
			{
				if(this.startGame)
				{
					Maki.Game.NewGame(true, true);
				}
				if(this.schematicAsset != null)
				{
					Schematic schematic = new Schematic(this.schematicAsset);
					schematic.PlaySchematic(this, this,
						this.gameObject, this.gameObject,
						true, MachineUpdateType.Update, Maki.Control.InputID);
				}
			}
		}

		public virtual float AsyncProgress
		{
			get
			{
				if(this.useAssetBundle &&
					this.assetBundle.loadAsync)
				{
					return this.assetBundle.Progress;
				}
				return 0;
			}
		}

		public virtual void SchematicFinished(Schematic schematic)
		{
			GameObject.Destroy(this);
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/GameStarter Icon.png");
		}
	}
}
