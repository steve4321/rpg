
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Machines/Collision Machine")]
	public class CollisionMachineComponent : BaseMachineComponent, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;

		public override bool CanRestart(GameObject startingObject)
		{
			return this.settings.startSetting.CanStart(this, startingObject);
		}


		/*
		============================================================================
		Collision functions
		============================================================================
		*/
		protected virtual void OnCollisionEnter(Collision collision)
		{
			if(this.settings.startSetting.CheckCollisionEnter(this, collision))
			{
				this.StartMachine(collision.gameObject,
					VariableHelper.AddCollisionInfo(collision,
						this.startVariableSetting.HasStartVariables ?
							this.startVariableSetting.GetStartVariables(
								this.startVariableSetting.NeedsCall ?
									new DataCall(this.gameObject, collision.gameObject,
										this.assetSetting.inputID.GetInputID(this.gameObject, collision.gameObject)) : null) :
							null));
			}
		}

		protected virtual void OnCollisionStay(Collision collision)
		{
			if(this.settings.startSetting.CheckCollisionStay(this, collision))
			{
				this.StartMachine(collision.gameObject,
					VariableHelper.AddCollisionInfo(collision,
						this.startVariableSetting.HasStartVariables ?
							this.startVariableSetting.GetStartVariables(
								this.startVariableSetting.NeedsCall ?
									new DataCall(this.gameObject, collision.gameObject,
										this.assetSetting.inputID.GetInputID(this.gameObject, collision.gameObject)) : null) :
							null));
			}
		}

		protected virtual void OnCollisionExit(Collision collision)
		{
			if(this.settings.startSetting.CheckCollisionExit(this, collision))
			{
				this.StartMachine(collision.gameObject,
					VariableHelper.AddCollisionInfo(collision,
						this.startVariableSetting.HasStartVariables ?
							this.startVariableSetting.GetStartVariables(
								this.startVariableSetting.NeedsCall ?
									new DataCall(this.gameObject, collision.gameObject,
										this.assetSetting.inputID.GetInputID(this.gameObject, collision.gameObject)) : null) :
							null));
			}
		}

		protected virtual void OnParticleCollision(GameObject other)
		{
			if(this.settings.startSetting.CheckParticleCollision(this, other))
			{
				this.StartMachine(other,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, other,
									this.assetSetting.inputID.GetInputID(this.gameObject, other)) : null) :
						null);
			}
		}

		protected virtual void OnControllerColliderHit(ControllerColliderHit hit)
		{
			if(this.settings.startSetting.CheckControllerColliderHit(this, hit))
			{
				// get start variables
				VariableHandler handler = this.startVariableSetting.HasStartVariables ?
					this.startVariableSetting.GetStartVariables(
						this.startVariableSetting.NeedsCall ?
							new DataCall(this.gameObject, hit.gameObject,
								this.assetSetting.inputID.GetInputID(this.gameObject, hit.gameObject)) : null) :
						new VariableHandler();
				if(handler == null)
				{
					handler = new VariableHandler();
				}

				// float
				handler.Set("moveLength", hit.moveLength);

				// Vector3
				handler.Set("moveDirection", hit.moveDirection);
				handler.Set("normal", hit.normal);
				handler.Set("point", hit.point);

				this.StartMachine(hit.gameObject, handler);
			}
		}


		/*
		============================================================================
		Collision2D functions
		============================================================================
		*/
		protected virtual void OnCollisionEnter2D(Collision2D collision)
		{
			if(this.settings.startSetting.CheckCollisionEnter2D(this, collision))
			{
				this.StartMachine(collision.gameObject, VariableHelper.AddCollision2DInfo(collision,
					this.startVariableSetting.GetStartVariables(
						this.startVariableSetting.NeedsCall ?
							new DataCall(this.gameObject, collision.gameObject,
								this.assetSetting.inputID.GetInputID(this.gameObject, collision.gameObject)) : null)));
			}
		}

		protected virtual void OnCollisionStay2D(Collision2D collision)
		{
			if(this.settings.startSetting.CheckCollisionStay2D(this, collision))
			{
				this.StartMachine(collision.gameObject,
					VariableHelper.AddCollision2DInfo(collision,
						this.startVariableSetting.HasStartVariables ?
							this.startVariableSetting.GetStartVariables(
								this.startVariableSetting.NeedsCall ?
									new DataCall(this.gameObject, collision.gameObject,
										this.assetSetting.inputID.GetInputID(this.gameObject, collision.gameObject)) : null) :
							null));
			}
		}

		protected virtual void OnCollisionExit2D(Collision2D collision)
		{
			if(this.settings.startSetting.CheckCollisionExit2D(this, collision))
			{
				this.StartMachine(collision.gameObject,
					VariableHelper.AddCollision2DInfo(collision,
						this.startVariableSetting.HasStartVariables ?
							this.startVariableSetting.GetStartVariables(
								this.startVariableSetting.NeedsCall ?
									new DataCall(this.gameObject, collision.gameObject,
										this.assetSetting.inputID.GetInputID(this.gameObject, collision.gameObject)) : null) :
							null));
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/CollisionMachineComponent Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorFoldout("Start Settings", "Define the start settings of this machine.", "")]
			[EditorEndFoldout]
			public CollisionMachineStartSetting startSetting = new CollisionMachineStartSetting();

			public Settings()
			{

			}
		}
	}
}
