
using UnityEngine;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public class BoundsMoverComponent : MonoBehaviour
	{
		protected Collider colComp;

		protected Collider2D colComp2D;

		protected GetFloat deltaTime;

		protected bool inPause = false;


		// time
		protected float time;

		protected float time2;


		// values
		protected Vector3 value = Vector3.zero;

		protected bool useDeltaTime = false;


		// options
		protected bool expand = false;

		protected bool useTime = false;


		/*
		============================================================================
		Init functions
		============================================================================
		*/
		public virtual void Clear()
		{
			this.value = Vector3.zero;

			this.inPause = false;
			this.expand = false;
			this.useTime = false;
			this.deltaTime = null;
		}

		protected virtual void IsExpanding(bool expand)
		{
			this.expand = expand;
			this.enabled = expand;
		}

		public virtual void Setup(Collider collider, Vector3 value, GetFloat deltaTime, bool inPause)
		{
			this.Clear();

			this.colComp = collider;
			this.deltaTime = deltaTime;
			this.inPause = inPause;

			this.value = value;
		}

		public virtual void Setup2D(Collider2D collider, Vector3 value, GetFloat deltaTime, bool inPause)
		{
			this.Clear();

			this.colComp2D = collider;
			this.deltaTime = deltaTime;
			this.inPause = inPause;

			this.value = value;
		}

		public virtual void StartExpansion(float time, bool useDeltaTime)
		{
			this.useDeltaTime = useDeltaTime;
			if(time >= 0)
			{
				this.time = 0;
				this.time2 = time;
				this.useTime = true;
			}
			else
			{
				this.useTime = false;
			}

			this.IsExpanding(true);
		}

		public virtual void StopExpansion()
		{
			this.IsExpanding(false);
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		protected virtual void Update()
		{
			if(this.expand && 
				(this.inPause || !Maki.Game.Paused))
			{
				if(this.colComp != null)
				{
					ColliderHelper.Expand(this.colComp,
						this.useDeltaTime ?
							this.value * (this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime()) :
							this.value);
				}
				else if(this.colComp2D != null)
				{
					ColliderHelper.Expand(this.colComp2D,
						this.useDeltaTime ?
							this.value * (this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime()) :
							this.value);
				}

				if(this.useTime)
				{
					this.time += (this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime());
					if(this.time >= this.time2)
					{
						this.IsExpanding(false);
					}
				}
			}
		}
	}
}
