
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Machines/Animation Machine")]
	public class AnimationMachineComponent : BaseMachineComponent, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;

		public override bool CanRestart(GameObject startingObject)
		{
			return this.settings.startSetting.CanStart(this, startingObject);
		}


		/*
		============================================================================
		Animation functions
		============================================================================
		*/
		protected virtual void OnAnimatorIK(int layerIndex)
		{
			if(this.settings.startSetting.isAnimatorIK)
			{
				DataCall call = this.startVariableSetting.NeedsCall ||
						(this.settings.startSetting.checkLayerIndex && 
							this.settings.startSetting.layerCheck.NeedsCall) ?
					new DataCall(this.gameObject, Maki.Game.Player.GameObject,
						this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null;
				if(this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject) &&
					this.settings.startSetting.CheckLayer(call, layerIndex))
				{
					VariableHandler handler = this.startVariableSetting.GetStartVariables(call);
					if(handler == null)
					{
						handler = new VariableHandler();
					}
					handler.Set("layerIndex", layerIndex);
					this.StartMachine(Maki.Game.Player.GameObject, handler);
				}
			}
		}

		protected virtual void OnAnimatorMove()
		{
			if(this.settings.startSetting.isAnimatorMove &&
				this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
		}

		protected virtual void OnJointBreak(float breakForce)
		{
			if(this.settings.startSetting.isJointBreak)
			{
				DataCall call = this.startVariableSetting.NeedsCall || 
						(this.settings.startSetting.checkBreakForce && 
							this.settings.startSetting.breakForceCheck.NeedsCall) ?
					new DataCall(this.gameObject, Maki.Game.Player.GameObject,
						this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null;
				if(this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject) &&
					this.settings.startSetting.CheckBreakForce(call, breakForce))
				{
					VariableHandler handler = this.startVariableSetting.GetStartVariables(call);
					if(handler == null)
					{
						handler = new VariableHandler();
					}
					handler.Set("breakForce", breakForce);
					this.StartMachine(Maki.Game.Player.GameObject, handler);
				}
			}
		}


		/*
		============================================================================
		Animation event functions
		============================================================================
		*/
		public virtual void AnimationEvent()
		{
			if(this.settings.startSetting.isAnimationEvent &&
				this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
		}

		public virtual void AnimationEventInt(int parameter)
		{
			if(this.settings.startSetting.isAnimationEventInt)
			{
				DataCall call = this.startVariableSetting.NeedsCall ||
						(this.settings.startSetting.checkParameter &&
							this.settings.startSetting.parameterCheck.NeedsCall) ?
					new DataCall(this.gameObject, Maki.Game.Player.GameObject,
						this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null;
				if(this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject) &&
					this.settings.startSetting.CheckIntParameter(call, parameter))
				{
					VariableHandler handler = this.startVariableSetting.GetStartVariables(call);
					if(handler == null)
					{
						handler = new VariableHandler();
					}
					handler.Set("parameter", parameter);
					this.StartMachine(Maki.Game.Player.GameObject, handler);
				}
			}
		}

		public virtual void AnimationEventFloat(float parameter)
		{
			if(this.settings.startSetting.isAnimationEventFloat)
			{
				DataCall call = this.startVariableSetting.NeedsCall ||
						(this.settings.startSetting.checkParameter &&
							this.settings.startSetting.parameterCheck.NeedsCall) ?
					new DataCall(this.gameObject, Maki.Game.Player.GameObject,
						this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null;
				if(this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject) &&
					this.settings.startSetting.CheckFloatParameter(call, parameter))
				{
					VariableHandler handler = this.startVariableSetting.GetStartVariables(call);
					if(handler == null)
					{
						handler = new VariableHandler();
					}
					handler.Set("parameter", parameter);
					this.StartMachine(Maki.Game.Player.GameObject, handler);
				}
			}
		}

		public virtual void AnimationEventString(string parameter)
		{
			if(this.settings.startSetting.isAnimationEventString)
			{
				DataCall call = this.startVariableSetting.NeedsCall ||
						(this.settings.startSetting.checkStringParameter &&
							this.settings.startSetting.stringParameterValue.NeedsCall) ?
					new DataCall(this.gameObject, Maki.Game.Player.GameObject,
						this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null;
				if(this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject) &&
					this.settings.startSetting.CheckStringParameter(call, parameter))
				{
					VariableHandler handler = this.startVariableSetting.GetStartVariables(call);
					if(handler == null)
					{
						handler = new VariableHandler();
					}
					handler.Set("parameter", parameter);
					this.StartMachine(Maki.Game.Player.GameObject, handler);
				}
			}
		}

		public virtual void UIGameObject(GameObject startingObject)
		{
			if(this.settings.startSetting.isUIGameObject &&
				this.settings.startSetting.CanStart(this, startingObject))
			{
				this.StartMachine(startingObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/AnimationMachineComponent Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorFoldout("Start Settings", "Define the start settings of this machine.", "")]
			[EditorEndFoldout]
			public AnimationMachineStartSetting startSetting = new AnimationMachineStartSetting();

			public Settings()
			{

			}
		}
	}
}
