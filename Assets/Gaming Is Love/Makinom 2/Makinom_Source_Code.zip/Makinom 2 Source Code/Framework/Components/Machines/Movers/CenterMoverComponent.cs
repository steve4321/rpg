
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public class CenterMoverComponent : MonoBehaviour
	{
		protected List<GameObject> targets;

		protected bool localSpace = false;

		protected Vector3 offset = Vector3.zero;

		protected float time = 0;

		protected float time2 = 0;

		protected GetFloat deltaTime;

		protected bool inPause = false;

		public virtual void SetCenter(List<GameObject> list, bool ls, Vector3 o, float t, GetFloat deltaTime, bool inPause)
		{
			this.targets = list;
			this.localSpace = ls;
			this.offset = o;
			this.time = 0;
			this.time2 = t;
			this.deltaTime = deltaTime;
			this.inPause = inPause;

			this.ToCenter();
		}

		public virtual void ToCenter()
		{
			TransformHelper.SetCenterPosRot(this.transform, this.targets);
			if(this.localSpace)
			{
				this.transform.position = this.transform.TransformPoint(this.offset);
			}
			else
			{
				this.transform.position = this.transform.position + this.offset;
			}
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		protected virtual void Update()
		{
			if(this.targets != null &&
				(this.inPause || !Maki.Game.Paused))
			{
				this.time += this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime();

				this.ToCenter();

				if(this.time >= this.time2)
				{
					UnityWrapper.Destroy(this.gameObject);
				}
			}
		}
	}
}
