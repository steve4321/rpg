﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Radius")]
	public class RadiusComponent : SerializedBehaviour<RadiusComponent.Settings>
	{
		// in-game
		protected bool setRadius = false;

		protected float tmpRadius = 0;

		protected bool schematicAdded = false;

		protected static Dictionary<GameObject, RadiusComponent> cache = new Dictionary<GameObject, RadiusComponent>();

		protected virtual void Reset()
		{
			this.settings.radius = new FloatValue<GameObjectSelection>(TransformHelper.DetermineRadius(this.gameObject));
		}

		public virtual float Radius
		{
			get
			{
				if(this.setRadius)
				{
					return this.tmpRadius * this.ScaleFactor;
				}
				return this.settings.radius.GetValue(this.settings.radius.NeedsCall ? new DataCall(this.gameObject) : null) * this.ScaleFactor;
			}
			set
			{
				this.tmpRadius = value;
				this.setRadius = true;
			}
		}

		public virtual void ResetRadius()
		{
			if(this.schematicAdded)
			{
				GameObject.Destroy(this);
			}
			else
			{
				this.setRadius = false;
				this.tmpRadius = 0;
			}
		}

		public virtual bool SchematicAdded
		{
			get { return this.schematicAdded; }
			set { this.schematicAdded = value; }
		}

		public static float GetRadius(GameObject gameObject)
		{
			if(gameObject != null)
			{
				RadiusComponent comp = null;
				if(RadiusComponent.cache.TryGetValue(gameObject, out comp))
				{
					return comp.Radius;
				}
				else
				{
					return TransformHelper.DetermineRadius(gameObject);
				}
			}
			return 0;
		}

		protected virtual void Awake()
		{
			RadiusComponent.cache.Add(this.gameObject, this);
		}

		protected virtual void OnDestroy()
		{
			RadiusComponent.cache.Remove(this.gameObject);
		}

		protected virtual float ScaleFactor
		{
			get
			{
				if(this.settings.useScale)
				{
					if(AxisType.X == this.settings.scaleAxis)
					{
						return this.transform.localScale.x;
					}
					else if(AxisType.Y == this.settings.scaleAxis)
					{
						return this.transform.localScale.y;
					}
					else if(AxisType.Z == this.settings.scaleAxis)
					{
						return this.transform.localScale.z;
					}
				}
				return 1;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Radius", "Defines the radius of the game object.\n" +
				"The radius is e.g. used when using 'Move To Interactin' to determine the movement destination.")]
			public FloatValue<GameObjectSelection> radius = new FloatValue<GameObjectSelection>();

			[EditorHelp("Use Scale", "The game object's scale will impact the final radius.")]
			[EditorSeparator]
			public bool useScale = true;

			[EditorHelp("Scale Axis", "Define which axis will be used for impacting the radius.")]
			[EditorIndent]
			[EditorCondition("useScale", true)]
			[EditorEndCondition]
			public AxisType scaleAxis = AxisType.X;

			public Settings()
			{

			}
		}
	}
}
