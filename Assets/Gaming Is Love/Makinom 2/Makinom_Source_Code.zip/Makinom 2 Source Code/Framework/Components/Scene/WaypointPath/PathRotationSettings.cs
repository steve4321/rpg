
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[System.Serializable]
	public class PathRotationSettings : BaseData
	{
		[EditorHelp("Rotation Type", "Select how the moving game object will rotate while moving along the path:\n" +
			"- None: No rotation.\n" +
			"- Value: To a defined rotation value.\n" +
			"- Move Direction: Look into the move direction.\n" +
			"- Look At Object: Look at an object.", "")]
		public PathRotationType type = PathRotationType.None;


		// rotation lock
		[EditorHelp("Lock Rotation", "Enable the axes the game object should not rotate on when looking into the direction.", "")]
		[EditorCondition("type", PathRotationType.MoveDirection)]
		[EditorCondition("type", PathRotationType.LookAtObject)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AxisBool lockAxis;

		public PathRotationSettings()
		{

		}

		public void LookAt(Transform user, Vector3 target, float smooth)
		{
			if((PathRotationType.MoveDirection == this.type ||
					PathRotationType.LookAtObject == this.type) &&
				this.lockAxis != null)
			{
				if(this.lockAxis.x)
				{
					target.x = user.position.x;
				}
				if(this.lockAxis.y)
				{
					target.y = user.position.y;
				}
				if(this.lockAxis.z)
				{
					target.z = user.position.z;
				}
			}
			target -= user.position;

			if(target != Vector3.zero)
			{
				if(smooth > 0)
				{
					user.rotation = Quaternion.Slerp(user.rotation,
						Quaternion.LookRotation(target), smooth);
				}
				else
				{
					user.rotation = Quaternion.LookRotation(target);
				}
			}
		}
	}
}
