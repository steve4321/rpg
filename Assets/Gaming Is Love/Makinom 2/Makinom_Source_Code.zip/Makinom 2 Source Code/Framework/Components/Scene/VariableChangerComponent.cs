﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Variable Changer")]
	public class VariableChangerComponent : BaseInteractionComponent, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		/*
		============================================================================
		Scene change functions
		============================================================================
		*/
		public override void StartInteraction(GameObject startingObject)
		{
			this.DoTurns(startingObject);
			this.settings.variable.SetVariables(new DataCall(this.gameObject, startingObject));
			this.EndCheck();
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/VariableChangerComponent Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorLabel("This game object will be the 'User', " +
				"the game object that started the interaction (e.g. the player) is the 'Target'.\n" +
				"Please note that not all start types have a game object starting it, i.e. a 'Target' might not be available.")]
			public VariableSetter<GameObjectSelection> variable = new VariableSetter<GameObjectSelection>();

			public Settings()
			{

			}
		}
	}
}