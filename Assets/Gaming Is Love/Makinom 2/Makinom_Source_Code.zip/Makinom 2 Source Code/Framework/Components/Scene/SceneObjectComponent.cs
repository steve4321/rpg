
using UnityEngine;
using GamingIsLove.Makinom.UI;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Scene Object")]
	public class SceneObjectComponent : BaseConditionComponent, IContent, ITypeContent, IPortraitContent,
		ICustomTextCodes, IHUDUpdate, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// ingame
		protected bool isInitialized = false;

		protected SceneObjectAsset sceneObject;

		protected SceneObjectTypeWrapper sceneObjectType;

		protected bool cursorChanged = false;

		public virtual bool SceneObjectActive
		{
			get
			{
				return this.CheckConditions(Maki.Game.Player.GameObject, false);
			}
		}

		protected Notify updateHUDHandler;
		public event Notify UpdateHUD
		{
			add { this.updateHUDHandler += value; }
			remove { this.updateHUDHandler -= value; }
		}


		/*
		============================================================================
		Auto start functions
		============================================================================
		*/
		protected override void OnEnable()
		{
			if(Maki.Initialized)
			{
				this.Init();
			}
		}

		protected override void Start()
		{
			this.Init();
		}

		protected virtual void Init()
		{
			if(!this.isInitialized)
			{
				this.isInitialized = true;
				bool check = true;
				if(ConditionAutoCheckType.Start == this.conditionSetting.autoCheckType)
				{
					check = this.CheckAutoDestroy();
				}
				if(check)
				{
					this.LoadSceneObject(this.settings.sceneObject);
				}
			}
		}

		public virtual void LoadSceneObject(SceneObjectAsset sceneObject)
		{
			if(sceneObject != null)
			{
				this.sceneObject = sceneObject;
				if(this.sceneObject.Settings.TypeData != null)
				{
					this.sceneObjectType = new SceneObjectTypeWrapper(this.sceneObject.Settings.TypeData, this);
				}
				if(this.sceneObject.Settings.ownObjectVariables)
				{
					if(this.sceneObject.Settings.useObjectVariables)
					{
						this.sceneObject.Settings.objectVariables.AddComponent(this.gameObject);
					}
				}
				else if(this.sceneObjectType != null &&
					this.sceneObjectType.Settings.useObjectVariables)
				{
					this.sceneObjectType.Settings.objectVariables.AddComponent(this.gameObject);
				}
				if(this.updateHUDHandler != null)
				{
					this.updateHUDHandler();
				}
			}
		}


		/*
		============================================================================
		Cursor functions
		============================================================================
		*/
		public virtual void CursorEnter()
		{
			if(this.CheckConditions(Maki.Game.Player.GameObject, false) &&
				this.sceneObject != null)
			{
				this.cursorChanged = this.sceneObject.Settings.Cursor.SetCursor();
			}
		}

		public virtual void CursorExit()
		{
			if(this.cursorChanged)
			{
				this.cursorChanged = false;
				if(this.sceneObject != null)
				{
					this.sceneObject.Settings.Cursor.ResetCursor();
				}
			}
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public virtual void ReplaceCustomTextCodes(ref string text)
		{
			for(int i = 0; i < this.settings.customTextCode.Length; i++)
			{
				this.settings.customTextCode[i].Replace(ref text);
			}
			if(this.sceneObject != null)
			{
				this.sceneObject.Settings.ReplaceCustomTextCodes(ref text);
			}
			if(this.sceneObjectType != null)
			{
				this.sceneObjectType.ReplaceCustomTextCodes(ref text);
			}
		}

		public virtual int ID
		{
			get
			{
				return this.sceneObject != null ?
					this.sceneObject.Index : -1;
			}
		}

		public virtual string GetName()
		{
			if(this.sceneObject != null)
			{
				string name = this.sceneObject.Settings.GetName();
				this.ReplaceCustomTextCodes(ref name);
				if(this.sceneObject.Settings.useObjectVariableTextCodes)
				{
					ObjectVariablesComponent objVariables = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(this.gameObject);
					name = TextHelper.ReplaceVariables(name,
						objVariables != null ? objVariables.Handler : null);
				}
				return name;
			}
			return "";
		}

		public virtual string GetShortName()
		{
			if(this.sceneObject != null)
			{
				string shortName = this.sceneObject.Settings.GetShortName();
				this.ReplaceCustomTextCodes(ref shortName);
				if(this.sceneObject.Settings.useObjectVariableTextCodes)
				{
					ObjectVariablesComponent objVariables = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(this.gameObject);
					shortName = TextHelper.ReplaceVariables(shortName,
						objVariables != null ? objVariables.Handler : null);
				}
				return shortName;
			}
			return "";
		}

		public virtual string GetDescription()
		{
			if(this.sceneObject != null)
			{
				string description = this.sceneObject.Settings.GetDescription();
				this.ReplaceCustomTextCodes(ref description);
				if(this.sceneObject.Settings.useObjectVariableTextCodes)
				{
					ObjectVariablesComponent objVariables = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(this.gameObject);
					description = TextHelper.ReplaceVariables(description,
						objVariables != null ? objVariables.Handler : null);
				}
				return description;
			}
			return "";
		}

		public virtual Sprite GetIconSprite()
		{
			return this.sceneObject != null ?
				this.sceneObject.Settings.GetIconSprite() : null;
		}

		public virtual Texture GetIconTexture()
		{
			return this.sceneObject != null ?
				this.sceneObject.Settings.GetIconTexture() : null;
		}

		public virtual string GetIconTextCode()
		{
			return this.sceneObject != null ?
				this.sceneObject.Settings.GetIconTextCode() : null;
		}

		public virtual string GetCustomContent(string contentKey)
		{
			if(this.sceneObject != null)
			{
				string content = this.sceneObject.Settings.GetCustomContent(contentKey);
				this.ReplaceCustomTextCodes(ref content);
				if(this.sceneObject.Settings.useObjectVariableTextCodes)
				{
					ObjectVariablesComponent objVariables = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(this.gameObject);
					content = TextHelper.ReplaceVariables(content,
						objVariables != null ? objVariables.Handler : null);
				}
				return content;
			}
			return "";
		}

		public virtual IPortrait GetPortrait(PortraitTypeAsset portraitType)
		{
			return this.sceneObject != null ?
				this.sceneObject.Settings.GetPortrait(portraitType) : null;
		}

		public virtual IContent GetTypeContent()
		{
			return this.sceneObjectType;
		}

		public virtual bool NoTooltip
		{
			get { return this.sceneObject != null && this.sceneObject.Settings.noTooltip; }
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/SceneObjectComponent Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Scene Object", "Select the scene object that will be used.", "")]
			public AssetSelection<SceneObjectAsset> sceneObject = new AssetSelection<SceneObjectAsset>();

			[EditorArray("Add Text Code", "Adds a custom text code.", "",
				"Remove", "Removes this custom text code.", "", enbox=true)]
			public CustomTextCode[] customTextCode = new CustomTextCode[0];

			public Settings()
			{

			}
		}
	}
}
