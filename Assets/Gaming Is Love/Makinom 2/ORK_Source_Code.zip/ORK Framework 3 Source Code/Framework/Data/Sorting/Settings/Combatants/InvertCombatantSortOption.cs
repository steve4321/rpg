﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Invert", "Inverts the current sort order.", "")]
	public class InvertCombatantSortOption<T> : BaseCombatantSortOption<T> where T : IObjectSelection, new()
	{
		public InvertCombatantSortOption()
		{

		}

		public override string ToString()
		{
			return "Invert";
		}

		public override void Sort(List<Combatant> list, IDataCall call)
		{
			list.Reverse();
		}
	}
}
