﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class InventorySpaceSorter : IComparer<IInventoryShortcut>
	{
		private int quantity = -1;

		private bool invert = false;

		public InventorySpaceSorter(int quantity, bool invert)
		{
			this.quantity = quantity;
			this.invert = invert;
		}

		public int Compare(IInventoryShortcut x, IInventoryShortcut y)
		{
			if(this.invert)
			{
				int result = y.GetOccupiedSpace(quantity >= 0 ? quantity : y.Quantity).CompareTo(
					x.GetOccupiedSpace(quantity >= 0 ? quantity : x.Quantity));
				if(result == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				return result;
			}
			else
			{
				int result = x.GetOccupiedSpace(quantity >= 0 ? quantity : x.Quantity).CompareTo(
					y.GetOccupiedSpace(quantity >= 0 ? quantity : y.Quantity));
				if(result == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				return result;
			}
		}
	}
}
