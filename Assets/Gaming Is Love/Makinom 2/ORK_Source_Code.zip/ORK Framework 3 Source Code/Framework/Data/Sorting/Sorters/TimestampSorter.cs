﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class TimestampSorter : IComparer<ITimestamp>
	{
		private bool invert = false;

		public TimestampSorter(bool invert)
		{
			this.invert = invert;
		}

		public int Compare(ITimestamp x, ITimestamp y)
		{
			if(this.invert)
			{
				return y.Timestamp.CompareTo(x.Timestamp);
			}
			else
			{
				return x.Timestamp.CompareTo(y.Timestamp);
			}
		}
	}
}
