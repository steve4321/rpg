﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class SortOption : LanguageContentInformation
	{
		[EditorHelp("Default Sorting", "Uses the default sorting settings.", "")]
		public bool isDefault = true;

		[EditorCondition("isDefault", false)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AdvancedContentSorter sorter;


		// key
		[EditorHelp("Use Sort Key", "Use an input key to change to this sorting option.", "")]
		[EditorSeparator]
		public bool useSortKey = false;

		[EditorFoldout("Sort Key", "Select the input key used to select this sorting option.", "")]
		[EditorEndFoldout]
		[EditorCondition("useSortKey", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AudioInputSelection sortKey;

		public SortOption()
		{

		}
	}
}
