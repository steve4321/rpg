
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class EquipmentSlotsSettings : GenericAssetListSettings<EquipmentSlotAsset, EquipmentSlotSetting>
	{
		public EquipmentSlotsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Equipment Slots"; }
		}
	}
}

