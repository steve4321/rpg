﻿
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class ResearchTypesSettings : GenericAssetListSettings<ResearchTypeAsset, ResearchType>
	{
		public ResearchTypesSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Research Types"; }
		}
	}
}
