
using UnityEngine;
using GamingIsLove.ORKFramework.UI;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.ORKFramework
{
	public class MenuScreensSettings : GenericAssetListSettings<MenuScreenAsset, MenuScreen>
	{
		// change menu
		[EditorHelp("Allow Menu Change", "Use input keys to change between open menu screens.", "")]
		[EditorFoldout("Menu Change Keys", "Optionally allow changing the active menu screen using input keys.\n" +
			"You can change between open menu screens that (individually) allow being changed to.", "")]
		public bool allowMenuChange = false;

		[EditorFoldout("Previous Key", "Select the key to change to the previous menu screen.", "")]
		[EditorEndFoldout]
		[EditorCondition("allowMenuChange", true)]
		public AudioInputSelection previousMenuKey = new AudioInputSelection();

		[EditorFoldout("Next Key", "Select the key to change to the next menu screen.", "")]
		[EditorEndFoldout(2)]
		[EditorEndCondition]
		public AudioInputSelection nextMenuKey = new AudioInputSelection();


		// menu background
		[EditorFoldout("Default Backgrounds", "Menu screens can display background UIs.\n" +
			"You can select the default backgrounds for all menu screens here.\n" +
			"Each menu screen can override the default background UI.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Default Background", "Adds a default background UI.", "",
			"Remove", "Removes this default background UI.", "", foldout=true,
			foldoutText=new string[] {
				"Default Background", "Define the default background UI that will be displayed.\n" +
				"Default backgrounds can be overridden by menu screens.", ""
			})]
		public UIBackgroundSettings[] defaultMenuBG = new UIBackgroundSettings[0];

		[EditorFoldout("General Backgrounds", "General background UIs are displayed in all menu screens and can't be overridden.", "")]
		[EditorEndFoldout]
		[EditorArray("Add General Background", "Adds a general background UI.", "",
			"Remove", "Removes this general background UI.", "", foldout=true,
			foldoutText=new string[] {
				"General Background", "Define the general background UI that will be displayed in all menu screens.\n" +
				"This background can't be overridden in individual menu screens.", ""
			})]
		public UIBackgroundSettings[] generalMenuBG = new UIBackgroundSettings[0];

		public MenuScreensSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Menu Screens"; }
		}

		public override bool HasGeneralSettings
		{
			get { return true; }
		}
	}
}
