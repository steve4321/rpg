﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class ORKDataHandlerCache
	{
		public ORKDataHandlerCache()
		{

		}

		private ControlMapsSettings controlMaps;
		public ControlMapsSettings ControlMaps
		{
			get
			{
				if(this.controlMaps == null)
				{
					this.controlMaps = Maki.Data.Get<ControlMapsSettings>();
				}
				return this.controlMaps;
			}
		}

		private AnimationTypesSettings animationTypes;
		public AnimationTypesSettings AnimationTypes
		{
			get
			{
				if(this.animationTypes == null)
				{
					this.animationTypes = Maki.Data.Get<AnimationTypesSettings>();
				}
				return this.animationTypes;
			}
		}

		private ConsoleTypesSettings consoleTypes;
		public ConsoleTypesSettings ConsoleTypes
		{
			get
			{
				if(this.consoleTypes == null)
				{
					this.consoleTypes = Maki.Data.Get<ConsoleTypesSettings>();
				}
				return this.consoleTypes;
			}
		}

		private DifficultiesSettings difficulties;
		public DifficultiesSettings Difficulties
		{
			get
			{
				if(this.difficulties == null)
				{
					this.difficulties = Maki.Data.Get<DifficultiesSettings>();
				}
				return this.difficulties;
			}
		}

		private ORKGameSettings gameSettings;
		public ORKGameSettings GameSettings
		{
			get
			{
				if(this.gameSettings == null)
				{
					this.gameSettings = Maki.Data.Get<ORKGameSettings>();
				}
				return this.gameSettings;
			}
		}

		private ConsoleSettings consoleSettings;
		public ConsoleSettings ConsoleSettings
		{
			get
			{
				if(this.consoleSettings == null)
				{
					this.consoleSettings = Maki.Data.Get<ConsoleSettings>();
				}
				return this.consoleSettings;
			}
		}

		private ORKGameControlsSettings gameControls;
		public ORKGameControlsSettings GameControls
		{
			get
			{
				if(this.gameControls == null)
				{
					this.gameControls = Maki.Data.Get<ORKGameControlsSettings>();
				}
				return this.gameControls;
			}
		}

		private AreaSettings areaSettings;
		public AreaSettings AreaSettings
		{
			get
			{
				if(this.areaSettings == null)
				{
					this.areaSettings = Maki.Data.Get<AreaSettings>();
				}
				return this.areaSettings;
			}
		}

		private AreaTypesSettings areaTypes;
		public AreaTypesSettings AreaTypes
		{
			get
			{
				if(this.areaTypes == null)
				{
					this.areaTypes = Maki.Data.Get<AreaTypesSettings>();
				}
				return this.areaTypes;
			}
		}

		private AreasSettings areas;
		public AreasSettings Areas
		{
			get
			{
				if(this.areas == null)
				{
					this.areas = Maki.Data.Get<AreasSettings>();
				}
				return this.areas;
			}
		}

		private TeleportsSettings teleports;
		public TeleportsSettings Teleports
		{
			get
			{
				if(this.teleports == null)
				{
					this.teleports = Maki.Data.Get<TeleportsSettings>();
				}
				return this.teleports;
			}
		}

		private AttackModifiersSettings attackModifiers;
		public AttackModifiersSettings AttackModifiers
		{
			get
			{
				if(this.attackModifiers == null)
				{
					this.attackModifiers = Maki.Data.Get<AttackModifiersSettings>();
				}
				return this.attackModifiers;
			}
		}

		private DefenceModifiersSettings defenceModifiers;
		public DefenceModifiersSettings DefenceModifiers
		{
			get
			{
				if(this.defenceModifiers == null)
				{
					this.defenceModifiers = Maki.Data.Get<DefenceModifiersSettings>();
				}
				return this.defenceModifiers;
			}
		}

		private StatusTypesSettings statusTypes;
		public StatusTypesSettings StatusTypes
		{
			get
			{
				if(this.statusTypes == null)
				{
					this.statusTypes = Maki.Data.Get<StatusTypesSettings>();
				}
				return this.statusTypes;
			}
		}

		private StatusValuesSettings statusValues;
		public StatusValuesSettings StatusValues
		{
			get
			{
				if(this.statusValues == null)
				{
					this.statusValues = Maki.Data.Get<StatusValuesSettings>();
				}
				return this.statusValues;
			}
		}

		private StatusEffectsSettings statusEffects;
		public StatusEffectsSettings StatusEffects
		{
			get
			{
				if(this.statusEffects == null)
				{
					this.statusEffects = Maki.Data.Get<StatusEffectsSettings>();
				}
				return this.statusEffects;
			}
		}

		private AbilityTypesSettings abilityTypes;
		public AbilityTypesSettings AbilityTypes
		{
			get
			{
				if(this.abilityTypes == null)
				{
					this.abilityTypes = Maki.Data.Get<AbilityTypesSettings>();
				}
				return this.abilityTypes;
			}
		}

		private AbilitiesSettings abilities;
		public AbilitiesSettings Abilities
		{
			get
			{
				if(this.abilities == null)
				{
					this.abilities = Maki.Data.Get<AbilitiesSettings>();
				}
				return this.abilities;
			}
		}

		private InventorySettings inventorySettings;
		public InventorySettings InventorySettings
		{
			get
			{
				if(this.inventorySettings == null)
				{
					this.inventorySettings = Maki.Data.Get<InventorySettings>();
				}
				return this.inventorySettings;
			}
		}

		private InventoryContainersSettings inventoryContainersSettings;
		public InventoryContainersSettings InventoryContainers
		{
			get
			{
				if(this.inventoryContainersSettings == null)
				{
					this.inventoryContainersSettings = Maki.Data.Get<InventoryContainersSettings>();
				}
				return this.inventoryContainersSettings;
			}
		}

		private ItemTypesSettings itemTypes;
		public ItemTypesSettings ItemTypes
		{
			get
			{
				if(this.itemTypes == null)
				{
					this.itemTypes = Maki.Data.Get<ItemTypesSettings>();
				}
				return this.itemTypes;
			}
		}

		private CurrenciesSettings currencies;
		public CurrenciesSettings Currencies
		{
			get
			{
				if(this.currencies == null)
				{
					this.currencies = Maki.Data.Get<CurrenciesSettings>();
				}
				return this.currencies;
			}
		}

		private ItemsSettings items;
		public ItemsSettings Items
		{
			get
			{
				if(this.items == null)
				{
					this.items = Maki.Data.Get<ItemsSettings>();
				}
				return this.items;
			}
		}

		private EquipmentSlotsSettings equipmentSlots;
		public EquipmentSlotsSettings EquipmentSlots
		{
			get
			{
				if(this.equipmentSlots == null)
				{
					this.equipmentSlots = Maki.Data.Get<EquipmentSlotsSettings>();
				}
				return this.equipmentSlots;
			}
		}

		private EquipmentSettings equipment;
		public EquipmentSettings Equipment
		{
			get
			{
				if(this.equipment == null)
				{
					this.equipment = Maki.Data.Get<EquipmentSettings>();
				}
				return this.equipment;
			}
		}

		private CraftingSettings craftingSettings;
		public CraftingSettings CraftingSettings
		{
			get
			{
				if(this.craftingSettings == null)
				{
					this.craftingSettings = Maki.Data.Get<CraftingSettings>();
				}
				return this.craftingSettings;
			}
		}

		private CraftingTypesSettings craftingTypes;
		public CraftingTypesSettings CraftingTypes
		{
			get
			{
				if(this.craftingTypes == null)
				{
					this.craftingTypes = Maki.Data.Get<CraftingTypesSettings>();
				}
				return this.craftingTypes;
			}
		}

		private CraftingRecipesSettings craftingRecipes;
		public CraftingRecipesSettings CraftingRecipes
		{
			get
			{
				if(this.craftingRecipes == null)
				{
					this.craftingRecipes = Maki.Data.Get<CraftingRecipesSettings>();
				}
				return this.craftingRecipes;
			}
		}

		private FactionsSettings factions;
		public FactionsSettings Factions
		{
			get
			{
				if(this.factions == null)
				{
					this.factions = Maki.Data.Get<FactionsSettings>();
				}
				return this.factions;
			}
		}

		private ClassSlotsSettings classSlots;
		public ClassSlotsSettings ClassSlots
		{
			get
			{
				if(this.classSlots == null)
				{
					this.classSlots = Maki.Data.Get<ClassSlotsSettings>();
				}
				return this.classSlots;
			}
		}

		private ClassesSettings classes;
		public ClassesSettings Classes
		{
			get
			{
				if(this.classes == null)
				{
					this.classes = Maki.Data.Get<ClassesSettings>();
				}
				return this.classes;
			}
		}

		private ActionCombosSettings actionCombos;
		public ActionCombosSettings ActionCombos
		{
			get
			{
				if(this.actionCombos == null)
				{
					this.actionCombos = Maki.Data.Get<ActionCombosSettings>();
				}
				return this.actionCombos;
			}
		}

		private AITypesSettings aiTypes;
		public AITypesSettings AITypes
		{
			get
			{
				if(this.aiTypes == null)
				{
					this.aiTypes = Maki.Data.Get<AITypesSettings>();
				}
				return this.aiTypes;
			}
		}

		private AIBehavioursSettings aiBehaviours;
		public AIBehavioursSettings AIBehaviours
		{
			get
			{
				if(this.aiBehaviours == null)
				{
					this.aiBehaviours = Maki.Data.Get<AIBehavioursSettings>();
				}
				return this.aiBehaviours;
			}
		}

		private AIRulesetsSettings aiRulesets;
		public AIRulesetsSettings AIRulesets
		{
			get
			{
				if(this.aiRulesets == null)
				{
					this.aiRulesets = Maki.Data.Get<AIRulesetsSettings>();
				}
				return this.aiRulesets;
			}
		}

		private FormationsSettings formations;
		public FormationsSettings Formations
		{
			get
			{
				if(this.formations == null)
				{
					this.formations = Maki.Data.Get<FormationsSettings>();
				}
				return this.formations;
			}
		}

		private CombatantTypesSettings combatantTypes;
		public CombatantTypesSettings CombatantTypes
		{
			get
			{
				if(this.combatantTypes == null)
				{
					this.combatantTypes = Maki.Data.Get<CombatantTypesSettings>();
				}
				return this.combatantTypes;
			}
		}

		private CombatantsSettings combatants;
		public CombatantsSettings Combatants
		{
			get
			{
				if(this.combatants == null)
				{
					this.combatants = Maki.Data.Get<CombatantsSettings>();
				}
				return this.combatants;
			}
		}

		private ResearchTypesSettings researchTypes;
		public ResearchTypesSettings ResearchTypes
		{
			get
			{
				if(this.researchTypes == null)
				{
					this.researchTypes = Maki.Data.Get<ResearchTypesSettings>();
				}
				return this.researchTypes;
			}
		}

		private ResearchTreesSettings researchTrees;
		public ResearchTreesSettings ResearchTrees
		{
			get
			{
				if(this.researchTrees == null)
				{
					this.researchTrees = Maki.Data.Get<ResearchTreesSettings>();
				}
				return this.researchTrees;
			}
		}

		private BattleTargetSettings targetSettings;
		public BattleTargetSettings TargetSettings
		{
			get
			{
				if(this.targetSettings == null)
				{
					this.targetSettings = Maki.Data.Get<BattleTargetSettings>();
				}
				return this.targetSettings;
			}
		}

		private BattleCameraSettings battleCamera;
		public BattleCameraSettings BattleCamera
		{
			get
			{
				if(this.battleCamera == null)
				{
					this.battleCamera = Maki.Data.Get<BattleCameraSettings>();
				}
				return this.battleCamera;
			}
		}

		private BattleSettings battleSettings;
		public BattleSettings BattleSettings
		{
			get
			{
				if(this.battleSettings == null)
				{
					this.battleSettings = Maki.Data.Get<BattleSettings>();
				}
				return this.battleSettings;
			}
		}

		private BattleSpotsSettings battleSpots;
		public BattleSpotsSettings BattleSpots
		{
			get
			{
				if(this.battleSpots == null)
				{
					this.battleSpots = Maki.Data.Get<BattleSpotsSettings>();
				}
				return this.battleSpots;
			}
		}

		private BattleTextsSettings battleTexts;
		public BattleTextsSettings BattleTexts
		{
			get
			{
				if(this.battleTexts == null)
				{
					this.battleTexts = Maki.Data.Get<BattleTextsSettings>();
				}
				return this.battleTexts;
			}
		}

		private BattleEndSettings battleEnd;
		public BattleEndSettings BattleEnd
		{
			get
			{
				if(this.battleEnd == null)
				{
					this.battleEnd = Maki.Data.Get<BattleEndSettings>();
				}
				return this.battleEnd;
			}
		}

		private BattleGridSettings battleGridSettings;
		public BattleGridSettings BattleGridSettings
		{
			get
			{
				if(this.battleGridSettings == null)
				{
					this.battleGridSettings = Maki.Data.Get<BattleGridSettings>();
				}
				return this.battleGridSettings;
			}
		}

		private BattleGridHighlightSettings battleGridHighlights;
		public BattleGridHighlightSettings BattleGridHighlights
		{
			get
			{
				if(this.battleGridHighlights == null)
				{
					this.battleGridHighlights = Maki.Data.Get<BattleGridHighlightSettings>();
				}
				return this.battleGridHighlights;
			}
		}

		private StartMenuSettings startMenu;
		public StartMenuSettings StartMenu
		{
			get
			{
				if(this.startMenu == null)
				{
					this.startMenu = Maki.Data.Get<StartMenuSettings>();
				}
				return this.startMenu;
			}
		}

		private ORKSaveGameSettings saveGameSettings;
		public ORKSaveGameSettings SaveGameSettings
		{
			get
			{
				if(this.saveGameSettings == null)
				{
					this.saveGameSettings = Maki.Data.Get<ORKSaveGameSettings>();
				}
				return this.saveGameSettings;
			}
		}

		private LogSettings logSettings;
		public LogSettings LogSettings
		{
			get
			{
				if(this.logSettings == null)
				{
					this.logSettings = Maki.Data.Get<LogSettings>();
				}
				return this.logSettings;
			}
		}

		private LogTypesSettings logTypes;
		public LogTypesSettings LogTypes
		{
			get
			{
				if(this.logTypes == null)
				{
					this.logTypes = Maki.Data.Get<LogTypesSettings>();
				}
				return this.logTypes;
			}
		}

		private LogsSettings logs;
		public LogsSettings Logs
		{
			get
			{
				if(this.logs == null)
				{
					this.logs = Maki.Data.Get<LogsSettings>();
				}
				return this.logs;
			}
		}

		private LogTextsSettings logTexts;
		public LogTextsSettings LogTexts
		{
			get
			{
				if(this.logTexts == null)
				{
					this.logTexts = Maki.Data.Get<LogTextsSettings>();
				}
				return this.logTexts;
			}
		}

		private QuestSettings questSettings;
		public QuestSettings QuestSettings
		{
			get
			{
				if(this.questSettings == null)
				{
					this.questSettings = Maki.Data.Get<QuestSettings>();
				}
				return this.questSettings;
			}
		}

		private QuestTypesSettings questTypes;
		public QuestTypesSettings QuestTypes
		{
			get
			{
				if(this.questTypes == null)
				{
					this.questTypes = Maki.Data.Get<QuestTypesSettings>();
				}
				return this.questTypes;
			}
		}

		private QuestsSettings quests;
		public QuestsSettings Quests
		{
			get
			{
				if(this.quests == null)
				{
					this.quests = Maki.Data.Get<QuestsSettings>();
				}
				return this.quests;
			}
		}

		private QuestTasksSettings questTasks;
		public QuestTasksSettings QuestTasks
		{
			get
			{
				if(this.questTasks == null)
				{
					this.questTasks = Maki.Data.Get<QuestTasksSettings>();
				}
				return this.questTasks;
			}
		}

		private TextDisplaySettings textDisplaySettings;
		public TextDisplaySettings TextDisplaySettings
		{
			get
			{
				if(this.textDisplaySettings == null)
				{
					this.textDisplaySettings = Maki.Data.Get<TextDisplaySettings>();
				}
				return this.textDisplaySettings;
			}
		}

		private CursorSettings cursorSettings;
		public CursorSettings CursorSettings
		{
			get
			{
				if(this.cursorSettings == null)
				{
					this.cursorSettings = Maki.Data.Get<CursorSettings>();
				}
				return this.cursorSettings;
			}
		}

		private ORKUISettings menuSettings;
		public ORKUISettings UISettings
		{
			get
			{
				if(this.menuSettings == null)
				{
					this.menuSettings = Maki.Data.Get<ORKUISettings>();
				}
				return this.menuSettings;
			}
		}

		private NotificationSettings notificationSettings;
		public NotificationSettings NotificationSettings
		{
			get
			{
				if(this.notificationSettings == null)
				{
					this.notificationSettings = Maki.Data.Get<NotificationSettings>();
				}
				return this.notificationSettings;
			}
		}

		private CombatantSelectionsSettings combatantSelections;
		public CombatantSelectionsSettings CombatantSelections
		{
			get
			{
				if(this.combatantSelections == null)
				{
					this.combatantSelections = Maki.Data.Get<CombatantSelectionsSettings>();
				}
				return this.combatantSelections;
			}
		}

		private QuantitySelectionsSettings quantitySelections;
		public QuantitySelectionsSettings QuantitySelections
		{
			get
			{
				if(this.quantitySelections == null)
				{
					this.quantitySelections = Maki.Data.Get<QuantitySelectionsSettings>();
				}
				return this.quantitySelections;
			}
		}

		private ShortcutSettings shortcutSettings;
		public ShortcutSettings ShortcutSettings
		{
			get
			{
				if(this.shortcutSettings == null)
				{
					this.shortcutSettings = Maki.Data.Get<ShortcutSettings>();
				}
				return this.shortcutSettings;
			}
		}

		private MenuScreensSettings menuScreens;
		public MenuScreensSettings MenuScreens
		{
			get
			{
				if(this.menuScreens == null)
				{
					this.menuScreens = Maki.Data.Get<MenuScreensSettings>();
				}
				return this.menuScreens;
			}
		}

		private ShopLayoutsSettings shopLayouts;
		public ShopLayoutsSettings ShopLayouts
		{
			get
			{
				if(this.shopLayouts == null)
				{
					this.shopLayouts = Maki.Data.Get<ShopLayoutsSettings>();
				}
				return this.shopLayouts;
			}
		}
	}
}
