﻿
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class ClassSlotsSettings : GenericAssetListSettings<ClassSlotAsset, ClassSlotSetting>
	{
		public ClassSlotsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Class Slots"; }
		}
	}
}

