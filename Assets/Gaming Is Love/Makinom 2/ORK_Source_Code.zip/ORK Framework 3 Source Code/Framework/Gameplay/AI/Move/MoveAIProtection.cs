﻿
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class MoveAIProtection : BaseData
	{
		[EditorHelp("Use Protection", "The protection settings are enabled.\n" +
			"The combatant will move between a target (enemy) and a member of its own group.\n" +
			"Protection can only be used when there is at least 1 additional member in the combatant's group.", "")]
		public bool enabled = false;

		[EditorHelp("Stopped Look At Target", "Look at the target while the combatant is stopped.", "")]
		[EditorCondition("enabled", true)]
		public bool stoppedLookAtTarget = false;


		// detection schematic
		[EditorHelp("Detection Schematic", "Select a schematic asset that will be started when the combatant detects a target and starts protecting members from it.\n" +
			"The combatant will be used as 'Machine Object', the detected target as 'Starting Object'.", "")]
		[EditorSeparator]
		public AssetSource<MakinomSchematicAsset> detectionSchematic = new AssetSource<MakinomSchematicAsset>();

		[EditorHelp("Wait", "Wait for the detection schematic to finish before starting to protect members from it.", "")]
		[EditorCondition("detectionSchematic.HasAsset", true)]
		[EditorEndCondition]
		[EditorIndent]
		public bool detectionWaitForSchematic = false;


		// protection range
		[EditorHelp("Use Protection Range", "The combatant will only protect within a range of its start position " +
			"(i.e. the position it has been spawned at).\n" +
			"When leaving the protection range, the combatant will return to its start position.\n" +
			"If disabled, there is no limit to the protection range.", "")]
		[EditorFoldout("Protection Range", "Optionally only protect within a defined range of the combatant's start position.", "")]
		public bool useRange = false;

		[EditorEndFoldout]
		[EditorCondition("useRange", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public RangeValue range;


		// protection distance
		[EditorFoldout("Stop Range", "The combatant will stay within the defined range to the target (or protected member).", "")]
		public RangeValue stopRange = new RangeValue(3, 0, false, false, false, true);

		[EditorHelp("From Protected", "Stay within the defined range to the protected member instead of the target.", "")]
		[EditorSeparator]
		public bool stopRangeFromProtected = false;

		[EditorHelp("Use Action Range", "The use range of a selected action is used when moving into range.\n" +
			"A combatant will only move into range when the used action is out of range to the target.\n" +
			"If the action doesn't have a use range, the stop range will be used.", "")]
		[EditorEndFoldout]
		public bool useActionStopRange = false;


		// target conditions
		[EditorHelp("Conditions Needed", "Select if all or just one condition must be valid to protect a group member from the target.", "")]
		[EditorFoldout("Protection Conditions (Target)", "Optionally only use protection when defined conditions are valid (checking the detected target).", "")]
		public Needed neededTarget = Needed.One;

		[EditorEndFoldout]
		[EditorArray("Add Protection Condition", "Adds a protection condition to check the detected target.\n" +
			"You can use multiple conditions to determine if the combatant protects a group member from the target.", "",
			"Remove", "Removes this protection condition.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Protection Condition (Target)", "Protection conditions determine if the combatant protects a group member from the target.", ""
			})]
		public MoveCondition[] conditionTarget = new MoveCondition[0];


		// member conditions
		[EditorHelp("Conditions Needed", "Select if all or just one condition must be valid to protect a group member.", "")]
		[EditorFoldout("Protection Conditions (Member)", "Optionally only protect a member of the combatant's group " +
			"when defined conditions are valid (checking the group members).", "")]
		public Needed neededMember = Needed.One;

		[EditorEndFoldout]
		[EditorEndCondition]
		[EditorArray("Add Protection Condition", "Adds a protection condition to check the group members.\n" +
			"You can use multiple conditions to determine if the combatant protects a group member.", "",
			"Remove", "Removes this protection condition.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Protection Condition", "Protection conditions determine if the combatant protects a group member.", ""
			})]
		public MoveCondition[] conditionMember = new MoveCondition[0];

		public MoveAIProtection()
		{

		}


		/*
		============================================================================
		Protection functions
		============================================================================
		*/
		public bool CheckProtectFrom(Combatant combatant, Combatant target)
		{
			if(this.enabled && combatant.IsAggressive)
			{
				if(this.conditionTarget != null && this.conditionTarget.Length > 0)
				{
					for(int i = 0; i < this.conditionTarget.Length; i++)
					{
						if(this.conditionTarget[i].IsValid(combatant, target))
						{
							if(Needed.One == this.neededTarget)
							{
								return true;
							}
						}
						else if(Needed.All == this.neededTarget)
						{
							return false;
						}
					}

					if(Needed.All == this.neededTarget)
					{
						return true;
					}
					else if(Needed.One == this.neededTarget)
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}

		public Combatant GetProtectedMember(MoveAIComponent moveAI)
		{
			List<Combatant> group = moveAI.Combatant.Group.GetBattle();
			if(group.Count > 1)
			{
				Combatant protect = null;
				float distance = Mathf.Infinity;
				for(int i = 0; i < group.Count; i++)
				{
					if(moveAI.Combatant != group[i] &&
						this.CheckProtectMember(moveAI.Combatant, group[i]))
					{
						float tmpDistance = moveAI.Combatant.Object.DistanceTo(group[i],
							true, false, moveAI.settings.horizontalPlane);
						if(tmpDistance < distance)
						{
							distance = tmpDistance;
							protect = group[i];
						}
					}
				}
				return protect;
			}
			return null;
		}

		public bool CheckProtectMember(Combatant combatant, Combatant member)
		{
			if(this.enabled && combatant.IsAggressive)
			{
				if(this.conditionMember != null && this.conditionMember.Length > 0)
				{
					for(int i = 0; i < this.conditionMember.Length; i++)
					{
						if(this.conditionMember[i].IsValid(combatant, member))
						{
							if(Needed.One == this.neededMember)
							{
								return true;
							}
						}
						else if(Needed.All == this.neededMember)
						{
							return false;
						}
					}

					if(Needed.All == this.neededMember)
					{
						return true;
					}
					else if(Needed.One == this.neededMember)
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}

		public bool IsInRange(Vector3 startPosition, Combatant combatant)
		{
			return !this.useRange ||
				this.range == null ||
				this.range.InRange(startPosition, combatant.GameObject);
		}

		public bool IsOutOfRange(Vector3 startPosition, Combatant combatant)
		{
			return this.useRange &&
				this.range != null &&
				this.range.OutOfRange(startPosition, combatant.GameObject);
		}

		public void Use(MoveAIComponent moveAI)
		{
			if(this.enabled)
			{
				Vector3 targetPosition = this.GetTargetPosition(moveAI);

				// reached position
				if(moveAI.ProtectStopRange.InRange(targetPosition, moveAI.Combatant.GameObject, true, 0.1f))
				{
					moveAI.targetPosTimeout = -1;
					moveAI.Stop();
					return;
				}

				// out of range
				if(this.IsOutOfRange(moveAI.startPosition, moveAI.Combatant))
				{
					moveAI.targetLostTimeout = -1;
					moveAI.ClearTarget(false);

					moveAI.SetMode(MoveAIMode.Waypoint);
					moveAI.SetMovePosition(moveAI.startPosition);
					return;
				}
			}

			if(!moveAI.IsTargetLost())
			{
				moveAI.UpdateTargetPosition(true);
			}
		}


		/*
		============================================================================
		Target functions
		============================================================================
		*/
		public Vector3 GetTargetPosition(MoveAIComponent moveAI)
		{
			if(this.enabled &&
				moveAI.TargetCombatant != null &&
				moveAI.TargetCombatant.GameObject != null &&
				moveAI.ProtectedCombatant != null &&
				moveAI.ProtectedCombatant.GameObject != null)
			{
				if(this.stopRangeFromProtected &&
					(!this.useActionStopRange || !moveAI.HasActionRange))
				{
					return Vector3.MoveTowards(
						moveAI.ProtectedCombatant.GameObject.transform.position,
						moveAI.TargetCombatant.GameObject.transform.position,
						moveAI.ProtectStopRange.GetInRangeDistance(
							moveAI.Combatant.GameObject, moveAI.ProtectedCombatant.GameObject));
				}
				else
				{
					return Vector3.MoveTowards(
						moveAI.TargetCombatant.GameObject.transform.position,
						moveAI.ProtectedCombatant.GameObject.transform.position,
						moveAI.ProtectStopRange.GetInRangeDistance(
							moveAI.Combatant.GameObject, moveAI.TargetCombatant.GameObject));
				}
			}
			else
			{
				return moveAI.Combatant.GameObject.transform.position;
			}
		}
	}
}
