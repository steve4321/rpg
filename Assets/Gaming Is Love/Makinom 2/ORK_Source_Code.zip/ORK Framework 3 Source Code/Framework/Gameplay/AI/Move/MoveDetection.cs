
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class MoveDetection : BaseData, IFoldoutInfo
	{
		[EditorHelp("Detect Combatants", "This detection can detect combatants.", "")]
		public bool detectCombatants = true;

		[EditorHelp("Detect Points Of Interest", "This detection can detect points of interest.", "")]
		public bool detectPointsOfInterest = true;

		[EditorHelp("Type", "Select how movement will be detected within the defined settings:\n" +
			"- Sight: The combatant only needs to be present.\n" +
			"- Movement: The combatants needs to move.\n" +
			"- Combatant Trigger: The combatant needs to be within a combatant trigger of the user.", "")]
		[EditorSeparator]
		public MoveDetectionType type = MoveDetectionType.Sight;


		// combatant triggers
		[EditorCondition("type", MoveDetectionType.CombatantTrigger)]
		[EditorAutoInit]
		public CombatantTriggerCheck combatantTrigger;


		// others
		[EditorHelp("From Child Object", "The position of the defined child of the user's game object will be used for range and angle checks.\n" +
			"If the child can't be found, the game object itself will be used.", "")]
		[EditorElseCondition]
		public ChildObjectSettings fromChildObject = new ChildObjectSettings();


		// sight
		[EditorSeparator]
		[EditorCondition("type", MoveDetectionType.Sight)]
		[EditorEndCondition]
		public RaycastLineOfSightSetting raycastLOS = new RaycastLineOfSightSetting();


		// movement
		[EditorHelp("Minimum Speed", "The minimum speed at which the combatant must move to be detected.", "")]
		[EditorSeparator]
		[EditorCondition("type", MoveDetectionType.Movement)]
		[EditorLimit(0.0f, false)]
		public float minSpeed = 1;

		[EditorHelp("Horizontal Speed", "Only the horizontal speed will be used for the check.\n" +
			"If disabled, also the vertical speed (e.g. jumping) will be used.", "")]
		[EditorEndCondition]
		public bool horizontalSpeed = false;


		// range
		[EditorHelp("Additional Range Check", "Do an additional range check (e.g. when checking within a different range than the base detection range).\n" +
			"Please note that the range check can't exceed the base detection range.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Range Settings")]
		public bool additionalRangeCheck = false;

		[EditorLabel("Can't exceed the base detection range.")]
		[EditorCondition("additionalRangeCheck", true)]
		[EditorEndCondition]
		public RangeValue range = new RangeValue(20);


		// radius
		[EditorHelp("Angle", "The angle (0 to 360) at which a combatant will be detected.\n" +
			"E.g. 180 will detect combatants at an angle of 90 degree to the left and right.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Angle Settings")]
		[EditorLimit(0.0f, 360.0f)]
		public float angle = 360;

		[EditorHelp("Angle Offset", "The offset (-180 to 180) added to the angle, e.g.:\n" +
			"- 0 is front" +
			"- -90 is left" +
			"- 90 is right" +
			"- 180/-180 is back", "")]
		[EditorLimit(-180.0f, 180.0f)]
		public float angleOffset = 0;

		[EditorEndCondition]
		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();

		public MoveDetection()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.fromChildObject.Upgrade(data, "fromChild");
		}

		public virtual string GetFoldoutInfo()
		{
			if(MoveDetectionType.CombatantTrigger == this.type)
			{
				return "Combatant Trigger";
			}
			else
			{
				return this.type + ": " + this.angle + "�";
			}
		}


		/*
		============================================================================
		Detection functions
		============================================================================
		*/
		public bool DetectedCombatant(Combatant owner, Combatant target)
		{
			if(this.detectCombatants &&
				owner != null && owner.GameObject != null &&
				target != null && target.GameObject != null)
			{
				if(MoveDetectionType.CombatantTrigger == this.type)
				{
					return this.combatantTrigger.Check(owner, target);
				}
				else
				{
					Transform ownerTransform = this.fromChildObject.GetChild(owner.GameObject.transform);
					if(!this.additionalRangeCheck ||
						(this.fromChildObject.UseChild ?
							this.range.InRange(ownerTransform.position, target.GameObject) :
							this.range.InRange(owner.GameObject, target.GameObject)))
					{
						// absolute value of the angle
						float tmpAngle = Mathf.Abs(VectorHelper.HorizontalAngle(ownerTransform,
							target.GameObject.transform.position, this.horizontalPlane) - this.angleOffset);
						// angle to the left and right
						if(tmpAngle <= this.angle / 2)
						{
							if(MoveDetectionType.Sight == this.type)
							{
								return this.raycastLOS.Check(owner.GameObject, target.GameObject);
							}
							else if(MoveDetectionType.Movement == this.type)
							{
								if(target.Object.Component != null)
								{
									if(this.horizontalSpeed)
									{
										return target.Object.Component.HorizontalSpeed >= this.minSpeed;
									}
									else
									{
										return target.Object.Component.HorizontalSpeed >= this.minSpeed ||
											target.Object.Component.VerticalSpeed >= this.minSpeed;
									}
								}
							}
						}
					}
				}
			}
			return false;
		}

		public bool DetectedPOI(Combatant owner, GameObject target)
		{
			if(this.detectPointsOfInterest &&
				owner != null && owner.GameObject != null &&
				target != null)
			{
				Transform ownerTransform = this.fromChildObject.GetChild(owner.GameObject.transform);
				if(this.range.InRange(target.transform.position, ownerTransform.position))
				{
					// absolute value of the angle
					float tmpAngle = Mathf.Abs(VectorHelper.HorizontalAngle(ownerTransform,
						target.transform.position, this.horizontalPlane) - this.angleOffset);
					// angle to the left and right
					if(tmpAngle <= this.angle / 2)
					{
						if(MoveDetectionType.Sight == this.type)
						{
							return this.raycastLOS.Check(owner.GameObject, target);
						}
						else if(MoveDetectionType.Movement == this.type)
						{
							CharacterController cc = target.GetComponent<CharacterController>();
							if(cc != null)
							{
								if(this.horizontalSpeed)
								{
									return new Vector3(cc.velocity.x, 0, cc.velocity.z).magnitude >= this.minSpeed;
								}
								else
								{
									return cc.velocity.magnitude >= this.minSpeed;
								}
							}
							else
							{
								Rigidbody rb = target.GetComponent<Rigidbody>();
								if(rb != null)
								{
									if(this.horizontalSpeed)
									{
										return new Vector3(rb.velocity.x, 0, rb.velocity.z).magnitude >= this.minSpeed;
									}
									else
									{
										return rb.velocity.magnitude >= this.minSpeed;
									}
								}
							}
						}
					}
				}
			}
			return false;
		}
	}
}
