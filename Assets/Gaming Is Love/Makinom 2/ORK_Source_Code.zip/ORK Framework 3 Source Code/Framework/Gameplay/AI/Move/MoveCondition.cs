
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class MoveCondition : BaseData, IFoldoutInfo
	{
		[EditorHelp("Type", "Select the type of the condition's check:\n" +
			"- Level: Checks the target's level.\n" +
			"- Class Level: Checks the target's class level.\n" +
			"- Group Size: Checks the target's group size.\n" +
			"- Status: Advanced status conditions.", "")]
		public MoveConditionType type = MoveConditionType.Level;


		// level/class level
		[EditorHelp("Use Offset", "The defined level value is added to the combatant's level for the check.\n" +
			"If disabled, only the defined level value is used.", "")]
		[EditorCondition("type", MoveConditionType.Level)]
		[EditorCondition("type", MoveConditionType.ClassLevel)]
		public bool levelOffset = true;

		[EditorHelp("Average Level", "Use the target's average group level for the check.\n" +
			"If disabled, the target's level is used.", "")]
		public bool levelAverage = false;

		[EditorHelp("Only Battle Group", "Only the target's battle group is used for the average level.\n" +
			"If disabled, the whole group is used.", "")]
		[EditorCondition("levelAverage", true)]
		[EditorEndCondition(2)]
		public bool levelOnlyBattle = true;


		// group size
		[EditorHelp("Only Battle Group", "Only the target's battle group is used for the size check.\n" +
			"If disabled, the whole size of the whole group is used (i.e. all available group members).", "")]
		[EditorCondition("type", MoveConditionType.GroupSize)]
		[EditorEndCondition]
		public bool groupSizeOnlyBattle = true;


		// check (level/group)
		[EditorCondition("type", MoveConditionType.Level)]
		[EditorCondition("type", MoveConditionType.ClassLevel)]
		[EditorCondition("type", MoveConditionType.GroupSize)]
		[EditorEndCondition]
		public ValueCheck<GameObjectSelection> valueCheck = new ValueCheck<GameObjectSelection>(1);


		// status condition
		[EditorHelp("Check Self", "Check the user of the move AI instead of the detected target.", "")]
		[EditorCondition("type", MoveConditionType.Status)]
		public bool statusCheckSelf = false;

		[EditorEndCondition]
		[EditorAutoInit]
		public StatusCondition statusConditions;

		public MoveCondition()
		{

		}

		public virtual string GetFoldoutInfo()
		{
			if(MoveConditionType.Level == this.type)
			{
				return "Level " + this.valueCheck.ToString();
			}
			else if(MoveConditionType.ClassLevel == this.type)
			{
				return "Class Level " + this.valueCheck.ToString();
			}
			else if(MoveConditionType.GroupSize == this.type)
			{
				return "Group Size " + this.valueCheck.ToString();
			}
			else if(MoveConditionType.Status == this.type)
			{
				return this.statusConditions.ToString();
			}
			return "";
		}

		public bool IsValid(Combatant combatant, Combatant target)
		{
			if(MoveConditionType.Level == this.type)
			{
				DataCall call = this.valueCheck.NeedsCall ? new DataCall(combatant, target) : null;
				if(this.levelAverage)
				{
					if(this.levelOnlyBattle)
					{
						return this.levelOffset ?
							this.valueCheck.Check(target.Group.AverageBattleLevel, combatant.Status.Level, call) :
							this.valueCheck.Check(target.Group.AverageBattleLevel, call);
					}
					else
					{
						return this.levelOffset ?
							this.valueCheck.Check(target.Group.AverageLevel, combatant.Status.Level, call) :
							this.valueCheck.Check(target.Group.AverageLevel, call);
					}
				}
				else
				{
					return this.levelOffset ?
						this.valueCheck.Check(target.Status.Level, combatant.Status.Level, call) :
						this.valueCheck.Check(target.Status.Level, call);
				}
			}
			else if(MoveConditionType.ClassLevel == this.type)
			{
				DataCall call = this.valueCheck.NeedsCall ? new DataCall(combatant, target) : null;
				if(this.levelAverage)
				{
					if(this.levelOnlyBattle)
					{
						return this.levelOffset ?
							this.valueCheck.Check(target.Group.AverageBattleClassLevel, combatant.Class.Level, call) :
							this.valueCheck.Check(target.Group.AverageBattleClassLevel, call);
					}
					else
					{
						return this.levelOffset ?
							this.valueCheck.Check(target.Group.AverageClassLevel, combatant.Class.Level, call) :
							this.valueCheck.Check(target.Group.AverageClassLevel, call);
					}
				}
				else
				{
					return this.levelOffset ?
						this.valueCheck.Check(target.Class.Level, combatant.Class.Level, call) :
						this.valueCheck.Check(target.Class.Level, call);
				}
			}
			else if(MoveConditionType.GroupSize == this.type)
			{
				DataCall call = this.valueCheck.NeedsCall ? new DataCall(combatant, target) : null;
				if(this.groupSizeOnlyBattle)
				{
					return this.valueCheck.Check(target.Group.BattleSize, call);
				}
				else
				{
					return this.valueCheck.Check(target.Group.Size, call);
				}
			}
			else if(MoveConditionType.Status == this.type)
			{
				return this.statusConditions.Check(this.statusCheckSelf ? combatant : target);
			}
			return false;
		}
	}
}
