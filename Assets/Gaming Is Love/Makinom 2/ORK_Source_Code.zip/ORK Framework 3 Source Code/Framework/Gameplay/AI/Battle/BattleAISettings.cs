
using UnityEngine;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.AI.Nodes;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class BattleAISettings : BaseNode
	{
		[EditorHelp("Name", "The name of the battle AI.", "")]
		[EditorFoldout("AI Settings", "Set the name and base settings of the battle AI.", "")]
		[EditorWidth(true)]
		public string name = "";

		[EditorHelp("Clear Found Targets", "Clear the found targets list at the start of this battle AI.\n" +
			"Removes all targets that where found by battle AIs that where executed before this one.", "")]
		[EditorEndFoldout]
		[EditorSeparator]
		public bool clearFoundTargets = false;


		// AI nodes
		[EditorHide]
		public BaseAINode[] node = new BaseAINode[0];

		[EditorHide]
		public NodeGroup[] group = new NodeGroup[0];

		[EditorHide]
		public int startIndex = -1;

		[EditorHide]
		public string[] layer = new string[] { "Base Layer" };

		public BattleAISettings()
		{

		}

		public BattleAISettings(string name)
		{
			this.name = name;
		}

		public virtual BaseAction GetAction(BattleAICall call)
		{
			BaseAction action = null;
			int currentNode = this.startIndex;

			if(this.clearFoundTargets)
			{
				call.foundTargets.Clear();
			}

			while(action == null &&
				currentNode >= 0 &&
				currentNode < this.node.Length)
			{
				if(this.node[currentNode].IsEnabled)
				{
					action = this.node[currentNode].Execute(ref currentNode, call);
				}
				else
				{
					currentNode = this.node[currentNode].GetNext(0);
				}
			}

			return action;
		}

		public static bool BodyPartCheck(IncludeCheckType includeBodyParts, Combatant combatant)
		{
			if(IncludeCheckType.No == includeBodyParts)
			{
				return !combatant.IsBodyPart;
			}
			else if(IncludeCheckType.Only == includeBodyParts)
			{
				return combatant.IsBodyPart;
			}
			else
			{
				return true;
			}
		}

		public static List<Combatant> GetTargetList(BattleAITargetType type, IncludeCheckType includeBodyParts,
			bool excludeSelf, bool excludeFoundTargets, BattleAICall call)
		{
			List<Combatant> list = new List<Combatant>();
			if(BattleAITargetType.Self == type)
			{
				if(IncludeCheckType.Yes == includeBodyParts)
				{
					list.Add(call.user);
					if(call.user.HasBodyParts)
					{
						List<CombatantBodyPart> bodyParts = call.user.GetBodyParts();
						for(int i = 0; i < bodyParts.Count; i++)
						{
							if(bodyParts[i] != null)
							{
								list.Add(bodyParts[i]);
							}
						}
					}
				}
				else if(IncludeCheckType.No == includeBodyParts)
				{
					list.Add(call.user);
				}
				else if(IncludeCheckType.Only == includeBodyParts)
				{
					if(call.user.HasBodyParts)
					{
						List<CombatantBodyPart> bodyParts = call.user.GetBodyParts();
						for(int i = 0; i < bodyParts.Count; i++)
						{
							if(bodyParts[i] != null)
							{
								list.Add(bodyParts[i]);
							}
						}
					}
				}
			}
			else if(BattleAITargetType.Ally == type)
			{
				if(excludeSelf ||
					excludeFoundTargets ||
					IncludeCheckType.Yes != includeBodyParts)
				{
					for(int i = 0; i < call.allies.Count; i++)
					{
						if((!excludeSelf ||
								call.allies[i] != call.user) &&
							(!excludeFoundTargets ||
								!call.foundTargets.Contains(call.allies[i])) &&
							BattleAISettings.BodyPartCheck(includeBodyParts, call.allies[i]))
						{
							list.Add(call.allies[i]);
						}
					}
				}
				else
				{
					list.AddRange(call.allies);
				}
			}
			else if(BattleAITargetType.Enemy == type)
			{
				if(excludeFoundTargets ||
					IncludeCheckType.Yes != includeBodyParts)
				{
					for(int i = 0; i < call.enemies.Count; i++)
					{
						if((!excludeFoundTargets ||
								!call.foundTargets.Contains(call.enemies[i])) &&
							BattleAISettings.BodyPartCheck(includeBodyParts, call.enemies[i]))
						{
							list.Add(call.enemies[i]);
						}
					}
				}
				else
				{
					list.AddRange(call.enemies);
				}
			}
			else if(BattleAITargetType.All == type)
			{
				// allies
				if(excludeSelf ||
					excludeFoundTargets ||
					IncludeCheckType.Yes != includeBodyParts)
				{
					for(int i = 0; i < call.allies.Count; i++)
					{
						if((!excludeSelf ||
								call.allies[i] != call.user) &&
							(!excludeFoundTargets ||
								!call.foundTargets.Contains(call.allies[i])) &&
							BattleAISettings.BodyPartCheck(includeBodyParts, call.allies[i]))
						{
							list.Add(call.allies[i]);
						}
					}
				}
				else
				{
					list.AddRange(call.allies);
				}
				// enemies
				if(excludeFoundTargets ||
					IncludeCheckType.Yes != includeBodyParts)
				{
					for(int i = 0; i < call.enemies.Count; i++)
					{
						if((!excludeFoundTargets ||
								!call.foundTargets.Contains(call.enemies[i])) &&
							BattleAISettings.BodyPartCheck(includeBodyParts, call.enemies[i]))
						{
							list.Add(call.enemies[i]);
						}
					}
				}
				else
				{
					list.AddRange(call.enemies);
				}
			}
			return list;
		}

		public static List<Combatant> GetTargetList(BattleAISelectedDataUser type, IncludeCheckType includeBodyParts,
			bool excludeSelf, bool excludeFoundTargets, BattleAICall call)
		{
			List<Combatant> list = new List<Combatant>();
			if(BattleAISelectedDataUser.Self == type)
			{
				if(IncludeCheckType.Yes == includeBodyParts)
				{
					list.Add(call.user);
					if(call.user.HasBodyParts)
					{
						List<CombatantBodyPart> bodyParts = call.user.GetBodyParts();
						for(int i=0; i< bodyParts.Count; i++)
						{
							if(bodyParts[i] != null)
							{
								list.Add(bodyParts[i]);
							}
						}
					}
				}
				else if(IncludeCheckType.No == includeBodyParts)
				{
					list.Add(call.user);
				}
				else if(IncludeCheckType.Only == includeBodyParts)
				{
					if(call.user.HasBodyParts)
					{
						List<CombatantBodyPart> bodyParts = call.user.GetBodyParts();
						for(int i = 0; i < bodyParts.Count; i++)
						{
							if(bodyParts[i] != null)
							{
								list.Add(bodyParts[i]);
							}
						}
					}
				}
			}
			else if(BattleAISelectedDataUser.Ally == type)
			{
				if(excludeSelf ||
					excludeFoundTargets ||
					IncludeCheckType.Yes != includeBodyParts)
				{
					for(int i = 0; i < call.allies.Count; i++)
					{
						if((!excludeSelf ||
								call.allies[i] != call.user) &&
							(!excludeFoundTargets ||
								!call.foundTargets.Contains(call.allies[i])) &&
							BattleAISettings.BodyPartCheck(includeBodyParts, call.allies[i]))
						{
							list.Add(call.allies[i]);
						}
					}
				}
				else
				{
					list.AddRange(call.allies);
				}
			}
			else if(BattleAISelectedDataUser.Enemy == type)
			{
				if(excludeFoundTargets ||
					IncludeCheckType.Yes != includeBodyParts)
				{
					for(int i = 0; i < call.enemies.Count; i++)
					{
						if((!excludeFoundTargets ||
								!call.foundTargets.Contains(call.enemies[i])) &&
							BattleAISettings.BodyPartCheck(includeBodyParts, call.enemies[i]))
						{
							list.Add(call.enemies[i]);
						}
					}
				}
				else
				{
					list.AddRange(call.enemies);
				}
			}
			else if(BattleAISelectedDataUser.All == type)
			{
				// allies
				if(excludeSelf ||
					excludeFoundTargets ||
					IncludeCheckType.Yes != includeBodyParts)
				{
					for(int i = 0; i < call.allies.Count; i++)
					{
						if((!excludeSelf ||
								call.allies[i] != call.user) &&
							(!excludeFoundTargets ||
								!call.foundTargets.Contains(call.allies[i])) &&
							BattleAISettings.BodyPartCheck(includeBodyParts, call.allies[i]))
						{
							list.Add(call.allies[i]);
						}
					}
				}
				else
				{
					list.AddRange(call.allies);
				}
				// enemies
				if(excludeFoundTargets ||
					IncludeCheckType.Yes != includeBodyParts)
				{
					for(int i = 0; i < call.enemies.Count; i++)
					{
						if((!excludeFoundTargets ||
								!call.foundTargets.Contains(call.enemies[i])) &&
							BattleAISettings.BodyPartCheck(includeBodyParts, call.enemies[i]))
						{
							list.Add(call.enemies[i]);
						}
					}
				}
				else
				{
					list.AddRange(call.enemies);
				}
			}
			else if(BattleAISelectedDataUser.FoundTargets == type)
			{
				list.AddRange(call.foundTargets);
			}
			return list;
		}

		public static List<Combatant> GetPreferredTargets(Combatant user, List<Combatant> foundTargets)
		{
			if(foundTargets.Count == 0)
			{
				List<Combatant> tmp = new List<Combatant>();
				if(user.Setting.AI.attackLastTarget &&
					user.Battle.LastTargets.Count > 0)
				{
					tmp.AddRange(user.Battle.LastTargets);
				}
				return tmp;
			}
			else
			{
				return foundTargets;
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeName()
		{
			return "Battle AI Settings";
		}

		public override string GetNodeDetails()
		{
			return "";
		}

		public override string GetNextName(int index)
		{
			return "Start";
		}

		public override bool IsRemovable()
		{
			return false;
		}


		/*
		============================================================================
		Next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 1;
		}

		public override int GetNext(int index)
		{
			return this.startIndex;
		}

		public override void SetNext(int index, int next)
		{
			this.startIndex = next;
		}
	}
}
