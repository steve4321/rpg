﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class MoveAIStopAngle : BaseData
	{
		[EditorHelp("Use Stop Angle", "The target position (based on the stop range) will be placed at a defined angle to the target.", "")]
		public bool useStopAngle = false;

		[EditorHelp("Local Space", "The stop angle is used in local space of the target.\n" +
			"E.g. 0 will always be in front, 90 on the right side.\n" +
			"If disabled, world space is used, e.g. 0 being north, 90 being east.\n" +
			"Depending on the used horizontal plane, a different rotation axis is used for determining the local space:\n" +
			"- XZ: The Y-axis.\n" +
			"- XY: The Z-axis.", "")]
		[EditorIndent]
		[EditorCondition("useStopAngle", true)]
		public bool stopAngleLocal = false;

		[EditorHelp("Stop Angle", "The angle used to determine the target position.", "")]
		[EditorIndent]
		[EditorEndCondition]
		public float stopAngle = 0;

		public MoveAIStopAngle()
		{

		}

		public override string ToString()
		{
			return this.useStopAngle ? this.stopAngle.ToString("0.0") + "°" : "None";
		}
	}

	public class MoveAIStopAngle<T> : BaseData where T : IObjectSelection, new()
	{
		[EditorHelp("Use Stop Angle", "The target position (based on the stop range) will be placed at a defined angle to the target.", "")]
		public bool useStopAngle = false;

		[EditorHelp("Local Space", "The stop angle is used in local space of the target.\n" +
			"E.g. 0 will always be in front, 90 on the right side.\n" +
			"If disabled, world space is used, e.g. 0 being north, 90 being east.\n" +
			"Depending on the used horizontal plane, a different rotation axis is used for determining the local space:\n" +
			"- XZ: The Y-axis.\n" +
			"- XY: The Z-axis.", "")]
		[EditorIndent]
		[EditorCondition("useStopAngle", true)]
		public bool stopAngleLocal = false;

		[EditorHelp("Stop Angle", "The angle used to determine the target position.", "")]
		[EditorIndent]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<T> stopAngle;

		public MoveAIStopAngle()
		{

		}

		public virtual MoveAIStopAngle ToStopAngle(IDataCall call)
		{
			MoveAIStopAngle tmp = new MoveAIStopAngle();
			tmp.useStopAngle = this.useStopAngle;
			if(this.useStopAngle)
			{
				tmp.stopAngleLocal = this.stopAngleLocal;
				tmp.stopAngle = this.stopAngle.GetValue(call);
			}
			return tmp;
		}

		public override string ToString()
		{
			return this.useStopAngle ? this.stopAngle.ToString() + "°" : "None";
		}
	}
}
