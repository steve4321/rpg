﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.UI;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	public class AIRulesetAsset : MakinomGenericAssetWithType<AIRuleset, AITypeAsset>
	{
		public AIRulesetAsset()
		{

		}

		public override string DataName
		{
			get { return "AI Ruleset"; }
		}
	}

	[TextCode(typeof(AIRulesetAsset), "AI Ruleset", "<airuleset.",
		new string[] { "<airuleset.name=", "<airuleset.shortname=", "<airuleset.description=", "<airuleset.icon=", "<airuleset.custom guid=\"",
			"<airuleset.type.name=", "<airuleset.type.shortname=", "<airuleset.type.description=", "<airuleset.type.icon=", "<airuleset.type.custom guid=\"",
			"<airuleset.inventory=", "<airuleset.equipped=", "<statistic.created.airuleset=", "<statistic.gained.airuleset=" },
		new string[] { "Name", "Short Name", "Description", "Icon", "Custom Content",
			"Type Name", "Type Short Name", "Type Description", "Type Icon", "Type Custom Content",
			"In Inventory", "Equipped", "Statistic Created", "Statistic Gained" })]
	[EditorLanguageExport("AIRuleset")]
	public class AIRuleset : BaseLanguageDataWithSubType<AITypeAsset, AIType>, IPortraitContent, ITextCode
	{
		// base settings
		[EditorHelp("AI Type", "Select the AI type of this AI ruleset.\n" +
			"This is the AI type the AI ruleset will belong to and that's used for the ruleset's type text codes.\n" +
			"Add secondary AI types to list the ruleset under multiple AI types in menus or other type checks.", "")]
		[EditorFoldout("Item Settings", "Define the base settings of this AI ruleset.", "")]
		public AssetSelection<AITypeAsset> type = new AssetSelection<AITypeAsset>();

		[EditorHelp("AI Type", "Select the AI type that'll be used as a secondary AI type.\n" +
			"Secondary AI types are used to list AI rulesets under multiple AI types in menus or other type checks.", "")]
		[EditorArray("Add Secondary AI Type", "Adds a secondary AI type.\n" +
			"Secondary AI types are used to list AI rulesets under multiple AI types in menus or other type checks.", "",
			"Remove", "Removes the secondary AI type.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Secondary AI Type", "Select the AI type that will be used as a secondary AI type.\n" +
				"Secondary AI types are used to list AI rulesets under multiple AI types in menus or other type checks.", ""
			})]
		public AssetSelection<AITypeAsset>[] secondaryAIType = new AssetSelection<AITypeAsset>[0];

		[EditorHelp("Use Quantity", "This AI ruleset uses quantity mechanics.\n" +
			"I.e. it can be collected multiple times and each unit " +
			"will be unavailable while being equipped on an AI ruleset slot.\n" +
			"If disabled, the AI ruleset can only be collected once and " +
			"equipping it on a slot doesn't make it unavailable for other combatants/slots.", "")]
		[EditorSeparator]
		public bool useQuantity = false;

		// sympathy
		[EditorHelp("Sympathy Change", "Additional to the faction's take item sympathy change, this value will be added to the change.\n" +
			"Use negative values to decrease sympathy, positive values to increase.", "")]
		[EditorSeparator]
		public float sympathyChange = 0;

		// chance
		[EditorHelp("Chance (%)", "The chance this AI ruleset will be used.", "")]
		public FloatValue<GameObjectSelection> chanceValue = new FloatValue<GameObjectSelection>(100);

		// price settings
		[EditorFoldout("Price Settings", "Set the prices for buying and selling this AI ruleset.", "")]
		[EditorEndFoldout]
		public PriceSettings price = new PriceSettings();

		// prefab settings
		[EditorHelp("Own Prefab", "Override the default item prefab defined in the inventory settings.")]
		[EditorFoldout("Prefab Settings", "Define the prefab used to display this AI ruleset in a scene.\n" +
			"Optionally use conditional prefabs to display different prefabs based on variable conditions.", "")]
		public bool ownPrefab = false;

		[EditorEndFoldout]
		[EditorCondition("ownPrefab", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public ItemPrefabSettings prefabSettings;


		// schematics
		[EditorHelp("Own Inventory Schematics", "This AI ruleset overrides the default inventory schematics ('Inventory > Inventory Settings').")]
		[EditorFoldout("Schematic Settings", "Define custom schematics that are used by this AI ruleset.")]
		public bool ownInventorySchematics = false;

		[EditorCondition("ownInventorySchematics", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public InventorySchematics inventorySchematics;

		// custom schematics
		[EditorFoldout("Custom Schematics", "Custom schematics can be used on an instance of this AI ruleset " +
			"in other schematics using a 'Custom Selected Data Schematic' node.\n" +
			"The AI ruleset is available as (local) selected data via the key 'action'.", "")]
		[EditorEndFoldout(3)]
		[EditorArray("Add Custom Schematic", "Adds a custom schematic.", "",
			"Remove", "Removes the custom schematic.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Custom Schematic", "Define the schematic assets that will be performed when using a " +
				"'Custom Selected Data Schematic' node with a matching key on an instance of this AI ruleset.\n" +
				"The AI ruleset is available as (local) selected data via the key 'action'.", ""
		})]
		public KeySchematicSetting[] customSchematic = new KeySchematicSetting[0];


		// UI settings
		// custom UI
		[EditorHelp("Own Shortcut UI", "Use a different shortcut UI setup for this AI ruleset.")]
		[EditorFoldout("UI Settings", "Define UI related settings for this AI ruleset.", "",
			"Custom Shortcut UI", "Optionally override the default shortcut UI setup for this AI ruleset.", "")]
		public bool ownShortcutUI = false;

		[EditorEndFoldout]
		[EditorCondition("ownShortcutUI", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public UIShortcutSettings shortcutUI;

		// portraits
		[EditorFoldout("Portraits", "The AI ruleset can display a portrait in menus when it's selected.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Portrait", "Adds a portrait.", "",
			"Remove", "Removes this portrait.", "", isMove = true, isCopy = true,
			foldout = true, foldoutText = new string[] {
				"Portrait", "Define the portrait that will be used.", ""
			})]
		public TypePrefabViewPortrait[] portrait = new TypePrefabViewPortrait[0];

		// information overrides
		// custom number format
		[EditorHelp("Own Number Format", "This AI ruleset overrides the default number formats defined in the text display settings.", "")]
		[EditorFoldout("Information Overrides", "Optionally override notifications or console texts for this AI ruleset.", "",
			"Number Format", "This AI ruleset can optionally override the default number format defined in 'UI > Text Display Settings'.", "",
			initialState = false)]
		public bool ownNumberFormat = false;

		[EditorFoldout("Quantity Format", "The format used to display the quantity of this AI ruleset.", "")]
		[EditorEndFoldout(2)]
		[EditorCondition("ownNumberFormat", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AdvancedNumberFormat quantityFormat;

		// notifications
		[EditorHelp("Own Notifications", "This AI ruleset overrides the default item notifications.", "")]
		[EditorFoldout("Notification Settings", "AI rulesets can override the default item notifications.", "")]
		public bool ownNotifications = false;

		[EditorFoldout("AI Ruleset Added", "This notification will be displayed " +
			"when this AI ruleset is added to the player.", "")]
		[EditorEndFoldout]
		[EditorLabel("<name> = name, <shortname> = short name, <description> = description, <icon> = icon, <customcontent=KEY> = custom content 'KEY'\n" +
			"<typename> = type name, <typeshortname> = type short name, <typedescription> = type description, <typeicon> = type icon, <typecustomcontent=KEY> = type custom content 'KEY'\n" +
			"<quantity> = quantity")]
		[EditorCondition("ownNotifications", true)]
		[EditorAutoInit]
		public AINotification addedNotification;

		[EditorFoldout("AI Ruleset Removed", "This notification will be displayed " +
			"when this AI ruleset is removed from the player.", "")]
		[EditorEndFoldout(2)]
		[EditorLabel("<name> = name, <shortname> = short name, <description> = description, <icon> = icon, <customcontent=KEY> = custom content 'KEY'\n" +
			"<typename> = type name, <typeshortname> = type short name, <typedescription> = type description, <typeicon> = type icon, <typecustomcontent=KEY> = type custom content 'KEY'\n" +
			"<quantity> = quantity")]
		[EditorEndCondition]
		[EditorAutoInit]
		public AINotification removedNotification;

		// console texts
		[EditorHelp("Own Add Text", "This AI ruleset overrides the default console add text.", "")]
		[EditorFoldout("Console Texts", "An AI ruleset can override the default console texts.", "")]
		public bool ownConsoleAdd = false;

		[EditorFoldout("Add Text", "The text displayed for adding this AI ruleset to the player.", "")]
		[EditorEndFoldout]
		[EditorCondition("ownConsoleAdd", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public ConsoleTextAI consoleAdd;

		[EditorHelp("Own Remove Text", "This AI ruleset overrides the default console remove text.", "")]
		[EditorSeparator]
		public bool ownConsoleRemove = false;

		[EditorFoldout("Remove Text", "The text displayed for removing this AI ruleset from the player.", "")]
		[EditorEndFoldout(4)]
		[EditorCondition("ownConsoleRemove", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public ConsoleTextAI consoleRemove;


		// move AI
		[EditorHelp("Change On Use", "Only change the move AI when an action of this AI ruleset is used.", "")]
		[EditorFoldout("AI Ruleset Settings", "Define move AI and equip/use conditions for this AI ruleset.", "",
			"Move AI Settings", "Equipping this AI ruleset can influence the move AI of the combatant.", "")]
		public bool moveAIChangeOnUse = false;

		[EditorSeparator]
		[EditorEndFoldout]
		public MoveAIChange moveAIChange = new MoveAIChange();

		// equip conditions
		[EditorHelp("Single Equip", "A combatant can only equip one AI ruleset of this kind.\n" +
			"If disabled, a combatant can equip this AI ruleset multiple times on different slots.", "")]
		[EditorFoldout("Equip Conditions", "Equipping this AI ruleset on an AI ruleset slot " +
			"can depend on valid conditions, e.g. combatant status or variable conditions.\n" +
			"The combatant equipping the AI ruleset is used for the checks.", "")]
		public bool singleEquip = true;

		[EditorHelp("Auto Unequip", "Automatically unequip this AI ruleset when the equip conditions are no longer valid.", "")]
		[EditorCondition("equipConditions.Has", true)]
		[EditorEndCondition]
		public bool autoUnequip = false;

		[EditorSeparator]
		[EditorEndFoldout]
		public CombatantGeneralConditionSettings equipConditions = new CombatantGeneralConditionSettings();

		// user conditions
		[EditorFoldout("User Conditions", "Using this AI ruleset can depend on valid conditions, " +
			"e.g. combatant status or variable conditions.", "")]
		[EditorEndFoldout(2)]
		public CombatantGeneralConditionSettings userConditions = new CombatantGeneralConditionSettings();


		// rules
		[EditorArray("Add Rule", "Adds a rule to this AI ruleset.\n" +
			"The rules will be used in the order they're added (i.e. starting with 'Rule 0').", "",
			"Remove", "Removes this rule.", "", isMove = true, isCopy = true,
			foldout = true, foldoutText = new string[] {
				"Rule", "Define the rule.", ""
			})]
		public AIRule[] rule = new AIRule[0];

		public AIRuleset()
		{

		}

		public AIRuleset(string name) : base(name)
		{

		}

		public virtual ItemPrefabSettings Prefab
		{
			get
			{
				return this.ownPrefab ?
					this.prefabSettings : ORK.InventorySettings.prefabSettings;
			}
		}

		public KeySchematicSetting GetCustomSchematic(string callKey)
		{
			for(int i = 0; i < this.customSchematic.Length; i++)
			{
				if(this.customSchematic[i].callKey == callKey)
				{
					return this.customSchematic[i];
				}
			}
			return null;
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public bool CanEquip(Combatant user)
		{
			return (!this.singleEquip || !user.AI.IsAIRulesetEquipped(this)) &&
				this.equipConditions.Check(user);
		}

		public bool CheckEquipConditions(Combatant user)
		{
			return this.equipConditions.Check(user);
		}

		public bool CheckConditions(Combatant user)
		{
			return Maki.GameSettings.CheckRandom(this.chanceValue.GetValue(user.Call)) &&
				this.userConditions.Check(user);
		}

		public bool CheckTargetRequirements(Combatant user, List<Combatant> allies, List<Combatant> enemies)
		{
			// target rule requirement
			for(int i = 0; i < this.rule.Length; i++)
			{
				if(AIRuleType.Target == this.rule[i].type &&
					this.rule[i].target.targetConditions.Has &&
					this.rule[i].target.isUseRequirement &&
					!this.rule[i].target.CheckRequirements(user, allies, enemies))
				{
					return false;
				}
			}
			return true;
		}


		/*
		============================================================================
		Ruleset functions
		============================================================================
		*/
		public BaseAction GetAction(BattleAICall call)
		{
			BaseAction action = null;
			if(this.CheckConditions(call.user) &&
				this.CheckTargetRequirements(call.user, call.allies, call.enemies))
			{
				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.Action == this.rule[i].type)
					{
						action = this.rule[i].action.GetAction(call.user);
						// check AI blocks
						if(!call.user.AI.CanUseAction(action))
						{
							action = null;
						}
						else if(action != null)
						{
							call.user.AI.SetActionTargets(action, call.user.Battle.LastTargets, call.allies, call.enemies);
							break;
						}
					}
					else if(AIRuleType.BattleAI == this.rule[i].type)
					{
						for(int j = 0; j < this.rule[i].battleAI.battleAI.Length; j++)
						{
							action = this.rule[i].battleAI.battleAI[j].GetAction(call);
							if(action != null)
							{
								break;
							}
						}
					}
				}
			}

			// action move AI and target changes
			if(action != null)
			{
				// target rule binding
				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.Target == this.rule[i].type &&
						this.rule[i].target.bindToRuleset)
					{
						if(this.rule[i].target.SetActionTargets(action, call.user, call.allies, call.enemies))
						{
							break;
						}
					}
				}

				// move AI changes
				if(this.moveAIChangeOnUse)
				{
					this.moveAIChange.Change(call.user);
				}
				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.MoveAI == this.rule[i].type &&
						this.rule[i].moveAI.moveAIChangeOnUse)
					{
						if(this.rule[i].moveAI.moveAIChange.Change(call.user))
						{
							break;
						}
					}
				}
			}

			return action;
		}

		public bool ChangeMoveAI(Combatant user)
		{
			if(this.CheckConditions(user))
			{
				if(!this.moveAIChangeOnUse &&
					this.moveAIChange.Change(user))
				{
					return true;
				}

				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.MoveAI == this.rule[i].type &&
						!this.rule[i].moveAI.moveAIChangeOnUse &&
						this.rule[i].moveAI.moveAIChange.Change(user))
					{
						return true;
					}
				}
			}
			return false;
		}

		public bool SetActionTargets(BaseAction action, Combatant user, List<Combatant> allies, List<Combatant> enemies)
		{
			if(this.CheckConditions(user))
			{
				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.Target == this.rule[i].type &&
						!this.rule[i].target.bindToRuleset)
					{
						if(this.rule[i].target.SetActionTargets(action, user, allies, enemies))
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		public bool CanUseAbility(Combatant user, AbilityShortcut ability)
		{
			if(this.CheckConditions(user))
			{
				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.BlockAbility == this.rule[i].type &&
						!this.rule[i].blockAbility.CanUse(ability))
					{
						return false;
					}
				}
			}
			return true;
		}

		public bool CanUseAttack(Combatant user)
		{
			if(this.CheckConditions(user))
			{
				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.BlockAttack == this.rule[i].type)
					{
						return false;
					}
				}
			}
			return true;
		}

		public bool CanUseCounterAttack(Combatant user)
		{
			if(this.CheckConditions(user))
			{
				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.BlockCounterAttack == this.rule[i].type)
					{
						return false;
					}
				}
			}
			return true;
		}

		public bool CanUseItem(Combatant user, ItemShortcut item)
		{
			if(this.CheckConditions(user))
			{
				for(int i = 0; i < this.rule.Length; i++)
				{
					if(AIRuleType.BlockItem == this.rule[i].type &&
						!this.rule[i].blockItem.CanUse(item))
					{
						return false;
					}
				}
			}
			return true;
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public override AITypeAsset TypeAsset
		{
			get { return this.type.StoredAsset; }
		}

		public override bool IsType(AIType type, bool checkParent)
		{
			if(base.IsType(type, checkParent))
			{
				return true;
			}
			else
			{
				for(int i = 0; i < this.secondaryAIType.Length; i++)
				{
					if(this.secondaryAIType[i].StoredAsset != null &&
						this.secondaryAIType[i].StoredAsset.Settings.IsType(type, checkParent))
					{
						return true;
					}
				}
			}
			return false;
		}

		public override void GetType(List<AIType> addToList)
		{
			base.GetType(addToList);
			for(int i = 0; i < this.secondaryAIType.Length; i++)
			{
				if(this.secondaryAIType[i].StoredAsset != null &&
					!addToList.Contains(this.secondaryAIType[i].StoredAsset.Settings))
				{
					addToList.Add(this.secondaryAIType[i].StoredAsset.Settings);
				}
			}
		}

		public ItemType ItemType
		{
			get { return this.TypeData != null ? this.TypeData.ItemType : null; }
		}

		public virtual bool IsItemType(ItemType type, bool checkParent)
		{
			return this.TypeData != null &&
				this.TypeData.IsItemType(type, checkParent);
		}

		public virtual void GetItemType(List<ItemType> addToList)
		{
			if(this.TypeData != null)
			{
				this.TypeData.GetItemType(addToList);
			}
		}

		public IPortrait GetPortrait(PortraitTypeAsset portraitType)
		{
			TypePrefabViewPortrait found = TypePrefabViewPortrait.GetPortrait(portraitType, this.portrait);
			this.Prefab.SetPortraitPrefab(found, null);
			return found;
		}

		public string FormatQuantity(int value)
		{
			if(this.ownNumberFormat)
			{
				return this.quantityFormat.FormatInt(value);
			}
			else if(this.TypeData != null &&
				this.TypeData.rulesetOwnNumberFormat)
			{
				return this.TypeData.rulesetQuantityFormat.FormatInt(value);
			}
			else
			{
				return ORK.TextDisplaySettings.numberFormatting.aiRulesetQuantityFormat.FormatInt(value);
			}
		}

		public string GetTextCode(int index)
		{
			if(index == 10)
			{
				return this.FormatQuantity(ORK.Game.ActiveGroup.Inventory.AIRulesets.GetCount(this));
			}
			else if(index == 11)
			{
				return this.FormatQuantity(ORK.Game.ActiveGroup.Inventory.AIRulesets.GetEquippedCount(this));
			}
			else if(index == 12)
			{
				return this.FormatQuantity(ORK.Statistic.GetCreatedAIRuleset(this.ID));
			}
			else if(index == 13)
			{
				return this.FormatQuantity(ORK.Statistic.GetGainedAIRuleset(this.ID));
			}
			return "";
		}
	}
}
