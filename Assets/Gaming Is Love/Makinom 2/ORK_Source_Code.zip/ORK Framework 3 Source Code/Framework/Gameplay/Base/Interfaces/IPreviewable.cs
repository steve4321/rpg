﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public interface IPreviewable : IContent
	{
		StatusPreview GetPreview(Combatant combatant, PreviewSelection selectedPreview);
	}
}
