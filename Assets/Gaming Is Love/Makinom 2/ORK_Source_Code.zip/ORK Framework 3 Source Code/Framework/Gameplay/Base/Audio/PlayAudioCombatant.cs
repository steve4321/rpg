
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class PlayAudioCombatant : BaseData
	{
		[EditorHelp("Use Sound Type", "The combatant's defined sound of a selected sound type will be used.", "")]
		public bool useSoundType = false;

		[EditorHelp("Sound Type", "Select the sound type that will be played.", "")]
		[EditorCondition("useSoundType", true)]
		[EditorAutoInit]
		public AssetSelection<SoundTypeAsset> soundType;

		[EditorHelp("Audio Clip", "The selected audio clip will be played.", "")]
		[EditorElseCondition]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSource<AudioClip> audioClip;

		[EditorHelp("Volume", "The volume used to play the audio clip.", "")]
		[EditorLimit(0.0f, 1.0f)]
		public float volume = 1;

		public PlayAudioCombatant()
		{

		}

		public void Play(Combatant combatant)
		{
			if(combatant != null)
			{
				AudioClip clip = this.useSoundType ?
					combatant.Animations.GetAudioClip(this.soundType) :
					clip = this.audioClip;
				if(clip != null)
				{
					AudioSource source = combatant.Object.GetAudioSource();
					if(source != null)
					{
						ComponentHelper.PlayOneShot(source.gameObject, clip, this.volume);
					}
				}
			}
		}
	}
}
