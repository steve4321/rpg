﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Group Size", "The combatant's group size will be compared to a defined value.")]
	public class GroupSizeStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Check Battle Group", "Check the battle group size.\n" +
			"If disabled, the whole group size (i.e. all members) will be checked.", "")]
		public bool battleGroup = true;

		[EditorHelp("Include Alive", "Alive group members are included in the size.")]
		public bool includeAlive = true;

		[EditorHelp("Include Dead", "Dead group members are included in the size.")]
		public bool includeDead = true;

		public ValueCheck<GameObjectSelection> check = new ValueCheck<GameObjectSelection>();

		public GroupSizeStatusConditionType()
		{

		}

		public override string ToString()
		{
			return (this.battleGroup ? "battle group size " : "group size ") + this.check.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.check.Check(
				combatant.Group.GetGroupSize(this.battleGroup, this.includeAlive, this.includeDead),
				combatant.Call);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.GroupChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.GroupChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.GroupChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.GroupChangedSimple -= notify;
		}
	}
}
