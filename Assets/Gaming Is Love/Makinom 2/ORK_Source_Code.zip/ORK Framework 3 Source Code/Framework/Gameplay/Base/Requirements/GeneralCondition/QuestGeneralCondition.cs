﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Quest", "Check quest status conditions.")]
	public class QuestGeneralCondition<T> : BaseGeneralCondition<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Needed", "Either all or just one of the quest conditions needs to be valid.", "")]
		public Needed needed = Needed.All;

		[EditorArray("Add Quest Condition", "Adds a new quest status condition.", "",
			"Remove", "Removes the quest status condition.", "", 
			isMove=true, isCopy=true, removeCheckField="quest",
			foldout=true, foldoutText=new string[] {
				"Quest Status Condition", "Define the quest status condition that must be valid.", ""
		})]
		public CheckQuestStatus[] questStatus = new CheckQuestStatus[0];

		public QuestGeneralCondition()
		{

		}

		public override string ToString()
		{
			return "Quest";
		}

		public override bool Check(IDataCall call)
		{
			if(this.questStatus.Length > 0)
			{
				for(int i = 0; i < this.questStatus.Length; i++)
				{
					if(this.questStatus[i].Check())
					{
						if(Needed.One == this.needed)
						{
							return true;
						}
					}
					else if(Needed.All == this.needed)
					{
						return false;
					}
				}
				if(Needed.All == this.needed)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return true;
			}
		}

		public override void Register(IDataCall call, Notify notify, ref List<VariableHandler> unregisterHandlers)
		{
			ORK.Game.Quests.Changed += notify;
		}

		public override void Unregister(IDataCall call, Notify notify)
		{
			ORK.Game.Quests.Changed -= notify;
		}
	}
}
