﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Formulas
{
	public static class FormulaExtensions
	{
		public static Combatant GetUserCombatant(this FormulaCall call)
		{
			return ORKComponentHelper.ToCombatant(call.User);
		}

		public static Combatant GetTargetCombatant(this FormulaCall call)
		{
			return ORKComponentHelper.ToCombatant(call.Target);
		}
	}
}
