﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Target Selection End", "When player group member ends selecting targets.")]
	public class TargetSelectionEndGameStateChangeType : BaseGameStateChangeType
	{
		public TargetSelectionEndGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			ORK.Battle.TargetSelectionEnd += notify;
		}
	}
}
