﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Is Target", "The combatant must or mustn't be a target of an action (ability/item).")]
	public class IsTargetStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Targeted By", "Select who the combatant must be targeted by.\n" +
			"- Self: The combatant itself.\n" +
			"- Ally: Allies of the combatant.\n" +
			"- Enemy: Enemies of the combatant.\n" +
			"- All: Any combatant.")]
		public TargetType targetedBy = TargetType.Enemy;

		[EditorHelp("Is Target", "The combatant must be the target of an action.\n" +
			"If disabled, the combatant mustn't be a target of an action.", "")]
		public bool isTarget = true;


		// actions
		[EditorHelp("Is Active Action", "The combatant is the target of actions currently being performed by combatants.")]
		[EditorSeparator]
		public bool isActiveAction = true;

		[EditorHelp("Is Casting Action", "The combatant is the target of actions currently being casted by combatants.")]
		public bool isCastingAction = true;

		[EditorHelp("Is Scheduled Action", "The combatant is the target of actions that have been selected by combatants and are scheduled for performing.")]
		public bool isScheduledAction = true;

		public IsTargetStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.isTarget ? "is target" : "is not target";
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return ORK.Battle.Actions.IsTarget(combatant, this.targetedBy, this.isScheduledAction, this.isCastingAction, this.isActiveAction) == this.isTarget;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			ORK.Battle.Actions.TargetsChanged += notify.NotifyStatusChanged;
			ORK.Battle.Actions.TargetsChanged += combatant.Status.Effects.MarkAutoEffectCheck;

			ORK.Battle.Actions.Changed += notify.NotifyStatusChanged;
			ORK.Battle.Actions.Changed += combatant.Status.Effects.MarkAutoEffectCheck;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			ORK.Battle.Actions.TargetsChanged -= notify.NotifyStatusChanged;
			ORK.Battle.Actions.TargetsChanged -= combatant.Status.Effects.MarkAutoEffectCheck;

			ORK.Battle.Actions.Changed -= notify.NotifyStatusChanged;
			ORK.Battle.Actions.Changed -= combatant.Status.Effects.MarkAutoEffectCheck;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			ORK.Battle.Actions.TargetsChanged += notify;
			ORK.Battle.Actions.Changed += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			ORK.Battle.Actions.TargetsChanged -= notify;
			ORK.Battle.Actions.Changed -= notify;
		}
	}
}
