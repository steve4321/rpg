﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Animations
{
	public class MecanimFloatParameterDamping : BaseData
	{
		[EditorHelp("Use Damping", "Damp the float parameter change.")]
		public bool useDamping = false;

		[EditorHelp("Damp Time (s)", "The damp time in seconds.")]
		[EditorIndent]
		[EditorLimit(0, false)]
		[EditorCondition("useDamping", true)]
		[EditorEndCondition]
		public float dampTime = 1;

		public MecanimFloatParameterDamping()
		{

		}

		public void Set(Animator animator, string name, float value)
		{
			if(this.useDamping && 
				this.dampTime > 0)
			{
				animator.SetFloat(name, value, this.dampTime, Maki.Game.DeltaTime * ORK.Game.AnimationFactor);
				if(float.IsNaN(animator.GetFloat(name)))
				{
					animator.SetFloat(name, value);
				}
			}
			else
			{
				animator.SetFloat(name, value);
			}
		}
	}
}
