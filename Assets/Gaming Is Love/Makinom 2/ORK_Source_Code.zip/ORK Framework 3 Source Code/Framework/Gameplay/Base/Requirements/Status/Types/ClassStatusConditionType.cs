﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Class (Single)", "The combatant must or mustn't be of the selected class.\n" +
		"Checks the combatant's single-class, use the 'Class Slot' check to check for classes on class slots.")]
	public class ClassStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Class", "Select the class that will be used.", "")]
		public AssetSelection<ClassAsset> checkClass = new AssetSelection<ClassAsset>();

		[EditorHelp("Is Class", "The combatant must have the defined class as it's current single-class.\n" +
			"If disabled, the combatant mustn't be the defined class.", "")]
		public bool isClass = true;

		public ClassStatusConditionType()
		{

		}

		public override string ToString()
		{
			return (this.isClass ? "is " : "not ") + this.checkClass.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return (combatant.Class.Current != null ?
					this.checkClass.Is(combatant.Class.Current.Settings) :
					(this.checkClass.StoredAsset == null)) == this.isClass;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ClassChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ClassChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.ClassChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.ClassChangedSimple -= notify;
		}
	}
}
