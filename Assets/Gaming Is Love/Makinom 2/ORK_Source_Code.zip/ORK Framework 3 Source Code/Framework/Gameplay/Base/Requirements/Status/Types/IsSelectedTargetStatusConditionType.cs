﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Is Selected Target", "The combatant must or mustn't be a selected target during the player's target selection (only used when the player selects targets).")]
	public class IsSelectedTargetStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Is Selected Target", "The combatant must be a selected target during the player's target selection.\n" +
			"If disabled, the combatant mustn't be a selected target during the player's target selection.", "")]
		public bool isTarget = true;

		[EditorHelp("Check Target Type", "Check the 'Target Type' of the ability/item the combatant is a selected target for.\n" +
			"This allows checking if the action is targeting allies or enemies (e.g. when switching target types using the 'Target Type Key').")]
		public bool checkTargetType = false;

		[EditorHelp("Target Type", "Select who the combatant must be targeted by:\n" +
			"- Self: The combatant itself.\n" +
			"- Ally: Allies of the combatant.\n" +
			"- Enemy: Enemies of the combatant.\n" +
			"- All: Any combatant.")]
		[EditorCondition("checkTargetType", true)]
		[EditorEndCondition]
		public TargetType targetType = TargetType.Enemy;

		public IsSelectedTargetStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.isTarget ? "is selected target" : "is not selected target";
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return TargetHighlight.IsSelectedTarget(combatant, this.checkTargetType, this.targetType) == this.isTarget;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			TargetHighlight.SelectedTargetsChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			TargetHighlight.SelectedTargetsChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			TargetHighlight.SelectedTargetsChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			TargetHighlight.SelectedTargetsChangedSimple -= notify;
		}
	}
}
