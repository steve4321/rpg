﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Is Body Part", "The combatant must or mustn't be a body part of another combatant.")]
	public class IsBodyPartStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Is Body Part", "The combatant must be a body part of another combatant.\n" +
			"If disabled, the combatant mustn't be a body part.", "")]
		public bool isBodyPart = true;

		[EditorHelp("Check Combatant", "Check for being a body part of a defined combatant.")]
		public bool checkCombatant = false;

		[EditorHelp("Combatant", "Select the combatant that will be checked for.\n" +
			"If 'Is Body Part' is enabled, the defined combatant must be the parent combatant of the body part.\n" +
			"If 'Is Body Part' is disabled, the defined combatant mustn't be the parent combatant of the checked combatant (also valid if no body part).")]
		[EditorCondition("checkCombatant", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSelection<CombatantAsset> combatant;

		public IsBodyPartStatusConditionType()
		{

		}

		public override string ToString()
		{
			return (this.isBodyPart ? "is body part" : "not body part") +
				(this.checkCombatant ? " of " + this.combatant.ToString() : "");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.checkCombatant)
			{
				if(this.combatant.StoredAsset != null)
				{
					CombatantBodyPart bodyPart = combatant as CombatantBodyPart;
					if(this.isBodyPart)
					{
						return bodyPart != null &&
							this.combatant.Is(bodyPart.Parent.Setting);
					}
					else
					{
						return bodyPart == null ||
							!this.combatant.Is(bodyPart.Parent.Setting);
					}
				}
				return false;
			}
			else
			{
				return combatant.IsBodyPart == this.isBodyPart;
			}
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			// static state > can't change
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			// static state > can't change
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			// static state > can't change
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			// static state > can't change
		}
	}
}
