﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Shop Open", "When a shop is opened.")]
	public class ShopOpenGameStateChangeType : BaseGameStateChangeType
	{
		public ShopOpenGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			ORK.Menu.ShopOpened += notify;
		}
	}
}
