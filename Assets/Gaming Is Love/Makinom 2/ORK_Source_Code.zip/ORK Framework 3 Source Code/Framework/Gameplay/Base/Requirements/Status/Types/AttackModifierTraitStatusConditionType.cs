﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Attack Modifier Trait", "The defined attack modifier attribute must or mustn't be recongized as a defined trait (strength, weakness, etc.).")]
	public class AttackModifierTraitStatusConditionType : BaseStatusConditionType
	{
		public AttackModifierAttributeSelection selection = new AttackModifierAttributeSelection();

		[EditorHelp("Trait", "Select which trait will be checked for:\n" +
			"- None: The attribute isn't recognized as any trait.\n" +
			"- Strength: The attribute is recognized as strengths.\n" +
			"- Weakness: The attribute is recognized as weaknesses.\n" +
			"- Immunity: The attribute is recognized as immunities.\n" +
			"- Recovery: The attribute is recognized as recoveries.", "")]
		public ModifierTraitType trait = ModifierTraitType.Strength;

		[EditorHelp("Is Trait", "The attack modifier attribute must be the defined trait.\n" +
			"If disabled, it mustn't be the trait.", "")]
		public bool isTrait = true;

		public AttackModifierTraitStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.selection.ToString() + (this.isTrait ? " is " : " is not ") + this.trait;
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.selection.IsTrait(combatant, this.trait) == this.isTrait;
		}

		public override bool CheckPreview(Combatant combatant)
		{
			return this.selection.IsTrait(combatant, this.trait) == this.isTrait;
		}

		public override bool CheckBestiary(Combatant combatant)
		{
			if(combatant.Bestiary != null &&
				(combatant.Bestiary.IsComplete ||
					this.selection.CheckBestiary(combatant)))
			{
				return this.selection.IsTrait(combatant, this.trait) == this.isTrait;
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			AttackModifierValues modifier = this.selection.GetModifier(combatant);
			if(modifier != null)
			{
				modifier.Changed += notify.NotifyStatusChanged;
			}
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			AttackModifierValues modifier = this.selection.GetModifier(combatant);
			if(modifier != null)
			{
				modifier.Changed -= notify.NotifyStatusChanged;
			}
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			AttackModifierValues modifier = this.selection.GetModifier(combatant);
			if(modifier != null)
			{
				modifier.SimpleChanged += notify;
			}
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			AttackModifierValues modifier = this.selection.GetModifier(combatant);
			if(modifier != null)
			{
				modifier.SimpleChanged -= notify;
			}
		}
	}
}
