﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public interface ILevel
	{
		int Level
		{
			get;
		}
	}
}
