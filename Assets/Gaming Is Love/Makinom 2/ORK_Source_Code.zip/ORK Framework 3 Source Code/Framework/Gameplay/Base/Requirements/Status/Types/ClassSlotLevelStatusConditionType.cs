﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Class Slot Level", "The level of a class equipped on a defined class slot will be compared to a defined value.\n" +
		"Fails if the slot isn't equipped with any class.")]
	public class ClassSlotLevelStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Class Slot", "Select the class slot that will be check.", "")]
		public AssetSelection<ClassSlotAsset> classSlot = new AssetSelection<ClassSlotAsset>();

		[EditorSeparator]
		public ValueCheck<GameObjectSelection> check = new ValueCheck<GameObjectSelection>();

		public ClassSlotLevelStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.classSlot.ToString() + " level " + this.check.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.classSlot.StoredAsset != null)
			{
				ClassSlot slot = combatant.Class.GetSlot(this.classSlot.StoredAsset.Settings);
				return slot != null &&
					slot.Equipped &&
					this.check.Check(slot.Class.Level, combatant.Call);
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ClassSlotsChanged += notify.NotifyStatusChanged;
			combatant.Events.ClassLevelChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ClassSlotsChanged -= notify.NotifyStatusChanged;
			combatant.Events.ClassLevelChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.ClassSlotsChangedSimple += notify;
			combatant.Events.ClassLevelChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.ClassSlotsChangedSimple -= notify;
			combatant.Events.ClassLevelChangedSimple -= notify;
		}
	}
}
