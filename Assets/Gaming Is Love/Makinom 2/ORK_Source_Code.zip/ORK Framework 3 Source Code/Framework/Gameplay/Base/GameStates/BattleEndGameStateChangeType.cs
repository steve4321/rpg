﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Battle End", "When a battle ends.")]
	public class BattleEndGameStateChangeType : BaseGameStateChangeType
	{
		public BattleEndGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			ORK.Control.BattleEnd += notify;
		}
	}
}
