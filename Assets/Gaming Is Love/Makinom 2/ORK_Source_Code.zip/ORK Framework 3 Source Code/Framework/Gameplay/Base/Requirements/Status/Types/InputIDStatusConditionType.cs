﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Input ID", "The combatant's input ID must or mustn't be set.")]
	public class InputIDStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Check Group Input ID", "Check the input ID of the group instead of the combatant.")]
		public bool checkGroup = false;

		[EditorHelp("Is Set", "If enabled, the combatant's input ID must be set.\n" +
			"If disabled, it mustn't be set.", "")]
		public bool isSet = false;

		[EditorHelp("Check Input ID", "Check for a defined input ID.")]
		public bool checkInputID = false;

		[EditorHelp("Input ID", "Define the input ID that will be checked for.")]
		[EditorIndent]
		[EditorLimit(0)]
		[EditorCondition("checkInputID", true)]
		[EditorEndCondition]
		public int inputID = 0;

		public InputIDStatusConditionType()
		{

		}

		public override string ToString()
		{
			return (this.checkGroup ? "Group " : "") +
				(this.checkInputID ?
					(this.isSet ? "Input ID is " + this.inputID : "Input ID not " + this.inputID) :
					(this.isSet ? "Input ID is set" : "Input ID not set"));
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.checkGroup)
			{
				if(this.checkInputID)
				{
					return (combatant.Group.InputID == this.inputID) == this.isSet;
				}
				else
				{
					return combatant.Group.IsInputIDSet() == this.isSet;
				}
			}
			else
			{
				if(this.checkInputID)
				{
					return (combatant.InputID == this.inputID) == this.isSet;
				}
				else
				{
					return combatant.IsInputIDSet() == this.isSet;
				}
			}
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.InputIDChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.InputIDChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.InputIDChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.InputIDChangedSimple -= notify;
		}
	}
}
