﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Inventory", "The combatant's (or group's) inventory will be checked for a defined item, equipment, currency, etc.")]
	public class InventoryStatusConditionType : BaseStatusConditionType
	{
		public ItemGain<GameObjectSelection> itemCheck = new ItemGain<GameObjectSelection>();

		[EditorHelp("In Inventory", "If enabled, the defined item, equipment, currency, etc. " +
			"must be in the combatant's inventory.\n" +
			"If disabled, it mustn't be in the inventory.", "")]
		public bool inInventory = true;

		public InventoryStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.itemCheck.ToString() + (this.inInventory ? " in inventory" : " not in inventory");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.inInventory == this.itemCheck.HasInInventory(combatant.Call, combatant.Inventory);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.InventoryChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.InventoryChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.InventoryChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.InventoryChangedSimple -= notify;
		}
	}
}
