﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Has Body Part", "The combatant must or mustn't have body parts.")]
	public class HasBodyPartStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Has Body Part", "The combatant must have at least one body part.\n" +
			"If disabled, the combatant mustn't have any body parts.", "")]
		public bool hasBodyPart = true;

		[EditorHelp("Check Combatant", "Check for a defined combatant being a body part.")]
		public bool checkCombatant = false;

		[EditorHelp("Combatant", "Select the combatant that will be checked for.\n" +
			"If 'Has Body Part' is enabled, the defined combatant must be a body part of the checked combatant.\n" +
			"If 'Has Body Part' is disabled, the defined combatant mustn't be a body part of the checked combatant (also valid if no body parts).")]
		[EditorCondition("checkCombatant", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSelection<CombatantAsset> combatant;

		public HasBodyPartStatusConditionType()
		{

		}

		public override string ToString()
		{
			return (this.hasBodyPart ? "has body part" : "no body part") +
				(this.checkCombatant ? " " + this.combatant.ToString() : "");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.checkCombatant)
			{
				if(this.combatant.StoredAsset != null)
				{
					return combatant.HasBodyPart(this.combatant.StoredAsset.Settings) == this.hasBodyPart;
				}
				return false;
			}
			else
			{
				return combatant.HasBodyParts == this.hasBodyPart;
			}
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			// static state > can't change
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			// static state > can't change
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			// static state > can't change
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			// static state > can't change
		}
	}
}
