﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class ItemPrefab : BaseData
	{
		[EditorHelp("Item Prefab ", "The prefab used to display this item in scenes.\n" +
			"The prefab is used by 'Item Collector' components to spawn the item in a scene.", "")]
		public AssetSource<GameObject> prefab = new AssetSource<GameObject>();

		[EditorHelp("Spawn Offset", "Offset added to the game object's position when spawning.", "")]
		public Vector3 spawnOffset = Vector3.zero;

		public ItemPrefab()
		{

		}
	}
}
