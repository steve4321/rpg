﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Faction", "The combatant must or mustn't be part of a defined faction.")]
	public class FactionStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Faction", "Select the faction that will be checked for.")]
		public AssetSelection<FactionAsset> faction = new AssetSelection<FactionAsset>();

		[EditorHelp("Is In Faction", "The combatant must be part of the defined faction.\n" +
			"If disabled, the combatant mustn't be part of the defined faction.", "")]
		public bool isInFaction = true;

		public FactionStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.isInFaction ? "in faction" : "not in faction";
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.isInFaction == this.faction.Is(combatant.Faction);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.GroupChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.GroupChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.GroupChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.GroupChangedSimple -= notify;
		}
	}
}
