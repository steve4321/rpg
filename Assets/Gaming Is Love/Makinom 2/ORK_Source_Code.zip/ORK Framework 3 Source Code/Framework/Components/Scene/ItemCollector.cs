
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;
using GamingIsLove.Makinom.Schematics;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Animations;
using GamingIsLove.ORKFramework.UI;

namespace GamingIsLove.ORKFramework.Components
{
	public enum ItemCollectorType { Single, Box };

	[AddComponentMenu("ORK Framework/Interaction/Item Collector")]
	public class ItemCollector : BaseInteractionComponent, ISceneID, ISceneGUID, ISchematicStarter, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// ingame
		protected bool isInitialized = false;

		protected int prefabIndex = -1;

		protected GameObject prefabInstance;

		protected float despawnTimer = -1;

		protected bool prefabChangeRegistered = false;

		protected DropInfo dropInfo;

		protected IShortcut item;

		protected ItemBoxData itemBox;

		protected ISchematicStarter starter;

		protected bool startSchematicRunning = false;

		protected bool endSchematicRunning = false;

		protected bool collectionFinishedOk = false;

		public virtual bool UseSceneID
		{
			get { return this.settings.useSceneID; }
			set { this.settings.useSceneID = value; }
		}

		public virtual int SceneID
		{
			get { return this.settings.sceneID; }
			set { this.settings.sceneID = value; }
		}

		public virtual bool UseSceneGUID
		{
			get { return this.settings.useBoxID; }
			set { this.settings.useBoxID = value; }
		}

		public virtual string SceneGUID
		{
			get { return this.settings.boxID; }
			set { this.settings.boxID = value; }
		}

		public virtual GameObject PrefabInstance
		{
			get { return this.prefabInstance; }
		}

		protected virtual void Reset()
		{
			if(ORK.Initialized &&
				ORK.InventorySettings.itemCollection.useDefaultStartSettings)
			{
				this.startSettings.SetData(ORK.InventorySettings.itemCollection.defaultStartSettings.GetData());
			}
			else
			{
				this.startSettings.interactStartSetting.isInteract = true;
				this.startSettings.turnStartingObject = true;
			}
		}

		protected override void OnDisable()
		{
			Maki.Instance.SceneLoaded -= this.OnAutoSceneLoaded;
			this.UnregisterPrefabChange();
			if(this.prefabInstance != null)
			{
				this.prefabInstance.SetActive(false);
			}
			base.OnDisable();
		}

		protected override void OnDestroy()
		{
			this.DestroySpawnedPrefab();
			base.OnDestroy();
		}

		public override bool UseAutoStopDistance
		{
			get { return this.settings.useAutoStopDistance; }
		}

		public override void AutoStopInteraction()
		{
			if(ItemCollectorType.Box == this.settings.collectionType)
			{
				if(this.settings.useInventoryExchangeMenu &&
					this.settings.menuScreen.StoredAsset != null)
				{
					this.settings.menuScreen.StoredAsset.Settings.Close();
				}
				else
				{
					ORK.InventorySettings.itemBoxCollection.Close();
				}
			}
			else if(this.item != null)
			{
				if(this.settings.showDialogue)
				{
					ORK.InventorySettings.itemCollection.Close(false);
				}
			}
		}


		/*
		============================================================================
		Item list functions
		============================================================================
		*/
		public virtual IShortcut Item
		{
			get { return this.item; }
		}

		public virtual ItemBoxData ItemBox
		{
			get { return this.itemBox; }
		}

		public virtual bool IsEmpty
		{
			get
			{
				return ItemCollectorType.Box == this.settings.collectionType ?
					(this.itemBox == null || this.itemBox.Inventory.IsEmpty) :
					this.item == null;
			}
		}

		public virtual void SetDropInfo(DropInfo info)
		{
			this.dropInfo = info;
			this.item = this.dropInfo.Item;
			this.settings.useSceneID = false;
			this.settings.collectionType = ItemCollectorType.Single;
			ORK.InventorySettings.dropCollectorSettings.Set(this);
			this.startSettings = ORK.InventorySettings.dropStartSettings;
			this.conditionSetting = ORK.InventorySettings.dropConditionSettings;

			// drop on ground
			if(ORK.InventorySettings.dropOnGround)
			{
				PlaceOnGround place = this.gameObject.AddComponent<PlaceOnGround>();
				place.settings = ORK.InventorySettings.dropOnGroundSettings;
				place.Place();
			}

			if(this.dropInfo.despawnTime > 0)
			{
				this.settings.despawn = true;
				this.settings.despawnTime = this.dropInfo.despawnTime;
				this.settings.despawnCollected = true;
			}
		}

		protected override void Update()
		{
			base.Update();

			if(this.prefabInstance != null &&
				!this.settings.doMount)
			{
				this.transform.position = this.prefabInstance.transform.position;
				this.transform.rotation = this.prefabInstance.transform.rotation;
			}

			if(this.dropInfo != null &&
				ORK.InventorySettings.dropSaveUpdatedPosition)
			{
				this.dropInfo.position = this.transform.position;
				this.dropInfo.rotation = this.transform.eulerAngles;
			}

			if(this.despawnTimer > 0 &&
				!Maki.Game.Paused &&
				!Maki.Control.Blocked)
			{
				this.despawnTimer -= Time.deltaTime;
				if(this.dropInfo != null)
				{
					this.dropInfo.despawnTime = this.despawnTimer;
				}
				if(this.despawnTimer <= 0)
				{
					if(this.settings.despawnCollected)
					{
						if(this.settings.useSceneID)
						{
							ORK.Game.Scene.ItemCollected(
								SceneManager.GetActiveScene().name,
								this.settings.sceneID, true);
						}
						if(this.dropInfo != null)
						{
							ORK.Game.Scene.Collected(this.dropInfo);
						}
					}
					GameObject.Destroy(this.gameObject);
				}
			}
		}


		/*
		============================================================================
		Interaction functions
		============================================================================
		*/
		protected override void Start()
		{
			bool destroyed = false;

			if(ConditionAutoCheckType.Start == this.conditionSetting.autoCheckType)
			{
				destroyed = this.CheckAutoDestroy();
			}

			if(!destroyed)
			{
				if(!this.isInitialized)
				{
					this.DoStartSetup();
				}
				else if(this.startSettings.autoStartSetting.isStart)
				{
					this.AutoStartCheck();
				}
			}
		}

		protected override void OnEnable()
		{
			Maki.Instance.SceneLoaded += this.OnAutoSceneLoaded;
			bool destroyed = false;

			if(ConditionAutoCheckType.Enable == this.conditionSetting.autoCheckType)
			{
				destroyed = this.CheckAutoDestroy();
			}

			if(!destroyed)
			{
				if(this.prefabInstance != null)
				{
					this.prefabInstance.SetActive(true);
				}

				this.Register();

				if(this.startSettings.autoStartSetting.isEnable)
				{
					if(!this.isInitialized)
					{
						this.DoStartSetup();
					}
					else
					{
						this.AutoStartCheck();
					}
				}
			}
		}

		public override void OnAutoSceneLoaded()
		{
			Maki.Instance.SceneLoaded -= this.OnAutoSceneLoaded;
			if(this.startSettings.autoStartSetting.isLevelWasLoaded)
			{
				if(!this.isInitialized)
				{
					this.DoStartSetup();
				}
				else
				{
					this.AutoStartCheck();
				}
			}
		}

		protected virtual void DoStartSetup()
		{
			if(!this.isInitialized)
			{
				this.isInitialized = true;
				if(this.dropInfo != null)
				{
					this.StartCheck();
				}
				else
				{
					if(ItemCollectorType.Box != this.settings.collectionType &&
						this.settings.useSceneID &&
						ORK.Game.Scene.IsItemCollected(SceneManager.GetActiveScene().name, this.settings.sceneID))
					{
						if(this.settings.destroyObject ||
							this.settings.destroyCollectedObject)
						{
							UnityWrapper.Destroy(this.gameObject);
						}
						else if(this.settings.collectedSchematicAsset.StoredAsset != null)
						{
							Schematic.Play(this.settings.collectedSchematicAsset.StoredAsset, this, this,
								this.gameObject, ORK.Game.ActiveGroup.Leader);
							GameObject.Destroy(this);
						}
					}
					else if(ORK.Game.ActiveGroup.Leader == null)
					{
						this.StartCoroutine(this.InitWaitForPlayer());
					}
					else
					{
						this.InitItems();
					}
				}
			}
		}

		protected virtual IEnumerator InitWaitForPlayer()
		{
			yield return null;
			if(ORK.Game.ActiveGroup.Leader != null)
			{
				this.InitItems();
			}
			else
			{
				this.StartCoroutine(this.InitWaitForPlayer());
			}
		}

		protected virtual void InitItems()
		{
			bool destroy = false;
			this.item = null;
			this.itemBox = null;

			if(ItemCollectorType.Single == this.settings.collectionType)
			{
				if(this.settings.item.Length > 0)
				{
					this.item = this.settings.item[UnityWrapper.Range(0, this.settings.item.Length)].
						CreateShortcutChance(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader);
				}
			}
			else if(ItemCollectorType.Box == this.settings.collectionType)
			{
				this.itemBox = this.settings.useBoxID ? ORK.Game.Scene.GetItemBox(this.settings.boxID, false) : null;
				if(this.itemBox != null)
				{
					this.itemBox.Collector = this;
					this.settings.spaceLimit = this.itemBox.SpaceLimit;
				}
				else
				{
					if(this.settings.useBoxID)
					{
						this.itemBox = ORK.Game.Scene.GetItemBox(this.settings.boxID, true);
						if(this.itemBox != null)
						{
							this.itemBox.SpaceLimit = this.settings.spaceLimit;
						}
					}
					if(this.itemBox == null)
					{
						this.itemBox = new ItemBoxData();
					}
					this.itemBox.Collector = this;

					if(this.settings.useLoot)
					{
						if(this.settings.loot.StoredAsset != null)
						{
							List<IShortcut> list = new List<IShortcut>();
							this.settings.loot.StoredAsset.Settings.Get(ref list,
								ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader,
								ORK.InventorySettings.itemBoxCollection.useInventoryAddType);
							this.itemBox.Inventory.Add(list, false, false);
						}
					}
					else
					{
						DataCall call = ORK.Game.ActiveGroup.Leader != null ?
							ORK.Game.ActiveGroup.Leader.Call : new DataCall();
						for(int i = 0; i < this.settings.item.Length; i++)
						{
							this.settings.item[i].AddToInventory(call, this.itemBox.Inventory, true, false, false);
						}
					}
				}
			}

			if(this.IsEmpty)
			{
				if(this.settings.setOnChance)
				{
					if(this.settings.useSceneID &&
						ItemCollectorType.Box != this.settings.collectionType)
					{
						ORK.Game.Scene.ItemCollected(
							SceneManager.GetActiveScene().name,
							this.settings.sceneID, true);
					}
				}
				if(ItemCollectorType.Box != this.settings.collectionType ||
					this.settings.destroyEmptyBox)
				{
					if(this.settings.destroyObject)
					{
						UnityWrapper.Destroy(this.gameObject);
					}
					else
					{
						GameObject.Destroy(this);
					}
					destroy = true;
				}
			}

			if(!destroy)
			{
				this.StartCheck();
			}
		}

		protected virtual void StartCheck()
		{
			if(this.IsEmpty)
			{
				if(ItemCollectorType.Box == this.settings.collectionType)
				{
					if(this.settings.destroyEmptyBox)
					{
						UnityWrapper.Destroy(this.gameObject);
					}
				}
				else if(this.settings.destroyObject)
				{
					UnityWrapper.Destroy(this.gameObject);
				}
				else
				{
					GameObject.Destroy(this);
				}
			}
			else if(this.startSettings.autoStartSetting.IsStartCheck)
			{
				if(!this.AutoStartCheck())
				{
					if(this.settings.destroyObject)
					{
						UnityWrapper.Destroy(this.gameObject);
					}
					else
					{
						GameObject.Destroy(this);
					}
				}
			}
			else
			{
				this.SpawnPrefab();
			}
		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		protected virtual void SpawnPrefab()
		{
			if(this.settings.spawnPrefab &&
				ItemCollectorType.Box != this.settings.collectionType)
			{
				if(!this.settings.spawnUseConditions || this.CheckConditions(ORK.Game.GetPlayer(), false))
				{
					GameObject prefab = null;
					Vector3 offset = Vector3.zero;
					if(this.item is EquipShortcut)
					{
						EquipShortcut item = (EquipShortcut)this.item;
						EquipmentPrefabSettings prefabSettings = item.GetPrefabSettings();
						if(prefabSettings != null)
						{
							if(prefabSettings.HasConditions)
							{
								this.prefabChangeRegistered = true;
								Maki.Game.Variables.Changed += this.CheckSpawnedPrefab;
								if(item != null &&
									item.HasVariables)
								{
									item.Variables.Changed += this.CheckSpawnedPrefab;
								}
							}
							prefab = prefabSettings.GetPrefab(item, ref this.prefabIndex, ref offset);
						}
					}
					else if(this.item is CurrencyShortcut)
					{
						CurrencyShortcut item = (CurrencyShortcut)this.item;
						prefab = this.GetPrefab(item.Setting.Prefab, item, ref offset);
					}
					else if(this.item is ItemShortcut)
					{
						ItemShortcut item = (ItemShortcut)this.item;
						prefab = this.GetPrefab(item.Setting.Prefab, item, ref offset);
					}
					else if(this.item is AIBehaviourShortcut)
					{
						AIBehaviourShortcut item = (AIBehaviourShortcut)this.item;
						prefab = this.GetPrefab(item.Setting.Prefab, item, ref offset);
					}
					else if(this.item is AIRulesetShortcut)
					{
						AIRulesetShortcut item = (AIRulesetShortcut)this.item;
						prefab = this.GetPrefab(item.Setting.Prefab, item, ref offset);
					}
					else if(this.item is CraftingRecipeShortcut)
					{
						CraftingRecipeShortcut item = (CraftingRecipeShortcut)this.item;
						prefab = this.GetPrefab(item.Setting.Prefab, item, ref offset);
					}
					else if(this.item is CombatantShortcut)
					{
						CombatantShortcut item = (CombatantShortcut)this.item;
						prefab = ORK.InventorySettings.prefabSettings.GetPrefab(null, ref this.prefabIndex, ref offset);
					}

					if(prefab != null)
					{
						this.prefabInstance = UnityWrapper.Instantiate(prefab);
					}

					if(this.prefabInstance != null)
					{
						if(this.settings.doMount)
						{
							if(this.settings.mountOnPrefab)
							{
								this.prefabInstance.transform.position = this.transform.position;
								this.prefabInstance.transform.rotation = this.transform.rotation;
								this.settings.mount.MountTo(this.prefabInstance.transform, this.transform);
							}
							else
							{
								this.settings.mount.MountTo(this.transform, this.prefabInstance.transform);
							}
						}
						else
						{
							this.prefabInstance.transform.position = this.transform.position;
							this.prefabInstance.transform.rotation = this.transform.rotation;
						}
						this.prefabInstance.transform.position += offset;
						this.prefabInstance.AddComponent<InteractionForwarder>().interaction = this;

						if(this.settings.despawn)
						{
							this.despawnTimer = this.settings.despawnTime;
						}
					}
				}
				else if(this.settings.repeatCheckSpawn)
				{
					StartCoroutine(this.SpawnPrefab2());
				}
			}
		}

		protected virtual GameObject GetPrefab(ItemPrefabSettings prefabSettings, IVariableSource variableSource, ref Vector3 offset)
		{
			if(prefabSettings.HasConditions)
			{
				this.prefabChangeRegistered = true;
				Maki.Game.Variables.Changed += this.CheckSpawnedPrefab;
				if(variableSource != null &&
					variableSource.HasVariables)
				{
					variableSource.Variables.Changed += this.CheckSpawnedPrefab;
				}
			}
			return prefabSettings.GetPrefab(variableSource, ref this.prefabIndex, ref offset);
		}

		protected virtual IEnumerator SpawnPrefab2()
		{
			if(this.settings.repeatCheckTime > 0)
			{
				yield return new WaitForSeconds(this.settings.repeatCheckTime);
			}
			else
			{
				yield return new WaitForSeconds(0.1f);
			}
			this.SpawnPrefab();
		}

		public virtual void CheckSpawnedPrefab()
		{
			if(this.prefabInstance != null &&
				this.item != null)
			{
				GameObject prefab = null;
				Vector3 offset = Vector3.zero;
				int tmp = -1;

				if(this.item is EquipShortcut)
				{
					EquipShortcut item = (EquipShortcut)this.item;
					EquipmentPrefabSettings prefabSettings = item.GetPrefabSettings();
					if(prefabSettings != null)
					{
						prefab = prefabSettings.GetPrefab(item, ref tmp, ref offset);
					}
				}
				else if(this.item is CurrencyShortcut)
				{
					CurrencyShortcut item = (CurrencyShortcut)this.item;
					prefab = item.Setting.Prefab.GetPrefab(item, ref tmp, ref offset);
				}
				else if(this.item is ItemShortcut)
				{
					ItemShortcut item = (ItemShortcut)this.item;
					prefab = item.Setting.Prefab.GetPrefab(item, ref tmp, ref offset);
				}
				else if(this.item is AIBehaviourShortcut)
				{
					AIBehaviourShortcut item = (AIBehaviourShortcut)this.item;
					prefab = item.Setting.Prefab.GetPrefab(item, ref tmp, ref offset);
				}
				else if(this.item is AIRulesetShortcut)
				{
					AIRulesetShortcut item = (AIRulesetShortcut)this.item;
					prefab = item.Setting.Prefab.GetPrefab(item, ref tmp, ref offset);
				}
				else if(this.item is CraftingRecipeShortcut)
				{
					CraftingRecipeShortcut item = (CraftingRecipeShortcut)this.item;
					prefab = item.Setting.Prefab.GetPrefab(item, ref tmp, ref offset);
				}

				if(this.prefabIndex != tmp)
				{
					this.prefabIndex = tmp;
					Vector3 position = this.prefabInstance.transform.position;
					Quaternion rotation = this.prefabInstance.transform.rotation;
					UnityWrapper.Destroy(this.prefabInstance);
					this.prefabInstance = UnityWrapper.Instantiate(prefab, position, rotation);
					if(this.prefabInstance != null)
					{
						if(this.settings.doMount)
						{
							this.settings.mount.MountTo(this.transform, this.prefabInstance.transform);
						}
						this.prefabInstance.AddComponent<InteractionForwarder>().interaction = this;
					}
				}
			}
		}

		protected virtual void UnregisterPrefabChange()
		{
			if(this.prefabChangeRegistered)
			{
				this.prefabChangeRegistered = false;

				Maki.Game.Variables.Changed -= this.CheckSpawnedPrefab;
				if(this.item != null)
				{
					IVariableSource source = this.item as IVariableSource;
					if(source.HasVariables)
					{
						source.Variables.Changed -= this.CheckSpawnedPrefab;
					}
				}
			}
		}

		public override bool CanInteract(GameObject startingObject)
		{
			return base.CanInteract(startingObject) &&
				((ItemCollectorType.Box == this.settings.collectionType &&
					(ORK.InventorySettings.itemBoxCollection.useInventoryExchangeMenu ||
						!ORK.InventorySettings.itemBoxCollection.autoClose ||
						this.itemBox != null && !this.itemBox.Inventory.IsEmpty)) ||
				(ItemCollectorType.Box != this.settings.collectionType &&
					(!this.settings.useSceneID || !ORK.Game.Scene.IsItemCollected(
						SceneManager.GetActiveScene().name, this.settings.sceneID))));
		}

		public override void StartInteraction(GameObject startingObject)
		{
			this.DoTurns(startingObject);
			this.DoStartInteraction(ORKComponentHelper.GetCombatant(startingObject));
		}

		public virtual void StartInteraction(ISchematicStarter starter)
		{
			this.starter = starter;
			this.DoStartInteraction(ORK.Game.ActiveGroup.Leader);
		}

		protected virtual void DoStartInteraction(Combatant user)
		{
			this.CancelInvoke("AutoDestroy");
			this.isInvoking = false;

			if(!this.isStarted)
			{
				if(user == null)
				{
					user = ORK.Game.ActiveGroup.Leader;
				}

				this.isStarted = true;
				ORK.Control.FireItemCollectionStart();

				if(this.settings.startSchematicAsset.StoredAsset != null)
				{
					this.startSchematicRunning = true;
					Schematic.Play(this.settings.startSchematicAsset.StoredAsset, this, this,
						this.settings.startSchematicUsePrefab && this.prefabInstance != null ? this.prefabInstance : this.gameObject,
						user);
				}
				else
				{
					this.startSchematicRunning = false;
					this.StartCoroutine(this.StartCollection(user));
				}
			}
		}

		protected virtual IEnumerator StartCollection(Combatant user)
		{
			if(this.settings.blockPlayerControl)
			{
				Maki.Control.SetBlockPlayer(1, true);
			}
			if(this.settings.blockCameraControl)
			{
				Maki.Control.SetBlockCamera(1, true);
			}
			if(this.settings.blockControlMaps)
			{
				ORK.Control.SetBlockControlMaps(1);
			}
			if(ItemCollectorType.Box == this.settings.collectionType)
			{
				if(this.itemBox != null)
				{
					float waitTime = ORK.InventorySettings.itemBoxCollection.animateBefore.Play(user);
					if(waitTime >= 0)
					{
						yield return new WaitForSeconds(waitTime);
					}

					if(this.settings.autoTakeAll)
					{
						this.itemBox.TakeAll(user);
						this.CollectionFinished(true, user);
					}
					else if(this.settings.useInventoryExchangeMenu &&
						this.settings.menuScreen.StoredAsset != null)
					{
						this.itemBox.CallCollectionFinished = true;
						this.settings.menuScreen.StoredAsset.Settings.ShowInventoryExchange(this.itemBox,
							user.Inventory, this.itemBox.Inventory);
					}
					else
					{
						ORK.InventorySettings.itemBoxCollection.Show(this, user);
					}
				}
			}
			else if(this.item != null)
			{
				float waitTime = ORK.InventorySettings.itemCollection.animateBefore.Play(user);
				if(waitTime >= 0)
				{
					yield return new WaitForSeconds(waitTime);
				}

				if(this.settings.showDialogue)
				{
					ORK.InventorySettings.itemCollection.Show(this, this.item, user);
				}
				else if(user.Inventory.CanCollect(this.item, -1))
				{
					this.CollectionFinished(true, user);
				}
				else
				{
					ORK.InventorySettings.notifications.full.Show(user, this.item, this.item.Quantity);
					this.CollectionFinished(false, user);
				}
			}
		}

		public virtual void CollectionFinished(bool ok, Combatant user)
		{
			if(this.settings.useCancelEndSchematic)
			{
				if(ok)
				{
					if(this.settings.endSchematicAsset.StoredAsset != null)
					{
						this.startSchematicRunning = false;
						this.endSchematicRunning = true;
						this.collectionFinishedOk = ok;

						Schematic.Play(this.settings.endSchematicAsset.StoredAsset, this, this,
							this.settings.endSchematicUsePrefab && this.prefabInstance != null ? this.prefabInstance : this.gameObject,
							user);
					}
					else
					{
						this.StartCoroutine(this.CollectionFinished2(ok, user));
					}
				}
				else
				{
					if(this.settings.cancelEndSchematicAsset.StoredAsset != null)
					{
						this.startSchematicRunning = false;
						this.endSchematicRunning = true;
						this.collectionFinishedOk = ok;

						Schematic.Play(this.settings.cancelEndSchematicAsset.StoredAsset, this, this,
							this.settings.cancelEndSchematicUsePrefab && this.prefabInstance != null ? this.prefabInstance : this.gameObject,
							user);
					}
					else
					{
						this.StartCoroutine(this.CollectionFinished2(ok, user));
					}
				}
			}
			else if(this.settings.endSchematicAsset.StoredAsset != null)
			{
				this.startSchematicRunning = false;
				this.endSchematicRunning = true;
				this.collectionFinishedOk = ok;

				Schematic.Play(this.settings.endSchematicAsset.StoredAsset, this, this,
					this.settings.endSchematicUsePrefab && this.prefabInstance != null ? this.prefabInstance : this.gameObject,
					user);
			}
			else
			{
				this.StartCoroutine(this.CollectionFinished2(ok, user));
			}
		}

		protected virtual IEnumerator CollectionFinished2(bool ok, Combatant user)
		{
			bool useEndCheck = true;
			if(ItemCollectorType.Box == this.settings.collectionType)
			{
				float waitTime = ORK.InventorySettings.itemBoxCollection.animateAfter.Play(user);
				if(waitTime >= 0)
				{
					yield return new WaitForSeconds(waitTime);
				}

				if(this.settings.destroyEmptyBox && this.itemBox.Inventory.IsEmpty)
				{
					useEndCheck = false;
					UnityWrapper.Destroy(this.gameObject);
				}
			}
			else
			{
				if(ok)
				{
					float waitTime = ORK.InventorySettings.itemCollection.animateAfterOk.Play(user);
					if(waitTime >= 0)
					{
						yield return new WaitForSeconds(waitTime);
					}

					if(this.settings.useSceneID)
					{
						ORK.Game.Scene.ItemCollected(
							SceneManager.GetActiveScene().name,
							this.settings.sceneID, true);
					}

					this.CollectItem(user);

					if(this.dropInfo != null)
					{
						ORK.Game.Scene.Collected(this.dropInfo);
					}
					if(this.prefabInstance != null)
					{
						UnityWrapper.Destroy(this.prefabInstance);
					}
					if(this.settings.destroyObject)
					{
						UnityWrapper.Destroy(this.gameObject);
					}
					else
					{
						GameObject.Destroy(this);
					}
					useEndCheck = false;
				}
				else
				{
					float waitTime = ORK.InventorySettings.itemCollection.animateAfterCancel.Play(user);
					if(waitTime >= 0)
					{
						yield return new WaitForSeconds(waitTime);
					}
				}
			}
			if(this.settings.blockPlayerControl)
			{
				Maki.Control.SetBlockPlayer(-1, true);
			}
			if(this.settings.blockCameraControl)
			{
				Maki.Control.SetBlockCamera(-1, true);
			}
			if(this.settings.blockControlMaps)
			{
				ORK.Control.SetBlockControlMaps(-1);
			}

			if(ComponentHelper.IsAlive(this.starter))
			{
				ISchematicStarter tmpStarter = this.starter;
				this.starter = null;
				tmpStarter.SchematicFinished(null);
			}
			this.isStarted = false;
			ORK.Control.FireItemCollectionEnd();
			if(useEndCheck)
			{
				this.EndCheck();
			}
		}

		public virtual void SetCollected()
		{
			if(ItemCollectorType.Box != this.settings.collectionType)
			{
				if(this.settings.useSceneID)
				{
					ORK.Game.Scene.ItemCollected(
						SceneManager.GetActiveScene().name,
						this.settings.sceneID, true);
				}

				if(this.dropInfo != null)
				{
					ORK.Game.Scene.Collected(this.dropInfo);
				}
				if(this.prefabInstance != null)
				{
					UnityWrapper.Destroy(this.prefabInstance);
				}
				if(this.settings.destroyObject)
				{
					UnityWrapper.Destroy(this.gameObject);
				}
				else
				{
					GameObject.Destroy(this);
				}
			}
		}

		protected virtual void CollectItem(Combatant combatant)
		{
			if(this.item != null)
			{
				this.UnregisterPrefabChange();

				// change sympathy for player
				if(this.settings.useFaction &&
					this.settings.faction.StoredAsset != null)
				{
					ShortcutHelper.TakeFromFaction(this.item,
						this.settings.faction.StoredAsset.Settings, combatant.Group.Faction);
				}
				combatant.Inventory.AddAccess(this.item, this.settings.showNotification, this.settings.showConsole, true);
				this.item = null;
			}
		}

		public virtual void DestroySpawnedPrefab()
		{
			if(this.prefabInstance != null)
			{
				UnityWrapper.Destroy(this.prefabInstance);
			}
		}


		/*
		============================================================================
		Schematic starter functions
		============================================================================
		*/
		public virtual void SchematicFinished(Schematic schematic)
		{
			Combatant user = null;
			if(schematic != null &&
				schematic.StartingObject != null &&
				schematic.StartingObject.Objects.Count > 0)
			{
				user = ORKComponentHelper.ToCombatant(schematic.StartingObject.Objects[0]);
			}
			if(user == null)
			{
				user = ORK.Game.ActiveGroup.Leader;
			}

			if(this.startSchematicRunning)
			{
				this.startSchematicRunning = false;
				this.StartCoroutine(this.StartCollection(user));
			}
			else if(this.endSchematicRunning)
			{
				this.endSchematicRunning = true;
				this.StartCoroutine(this.CollectionFinished2(this.collectionFinishedOk, user));
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/ItemCollector Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			// scene ID
			[EditorHide]
			public bool useSceneID = true;

			[EditorHide]
			public int sceneID = -1;

			// box ID
			[EditorHide]
			public bool useBoxID = true;

			[EditorHide]
			public string boxID = "";

			// collection settings
			[EditorHelp("Collection Type", "\n" +
				"- Single: A single item. When multiple items are added, uses one randomly.\n" +
				"- Box: Opens an item box with all added items.")]
			[EditorFoldout("Collection Settings", "Define the type of item collection.")]
			public ItemCollectorType collectionType = ItemCollectorType.Single;

			[EditorHelp("Use Auto Stop Distance", "Automatically stop the interaction if the player is a defined distance away from the game object.\n" +
				"The auto stop distance settings can be set up in 'Base/Control > Game Controls' in the 'Interaction Settings > Auto Stop Interaction'.")]
			[EditorSeparator]
			public bool useAutoStopDistance = false;


			// single
			[EditorHelp("Destroy Object", "Destroy this game object after collecting the item.")]
			[EditorSeparator]
			[EditorCondition("collectionType", ItemCollectorType.Single)]
			public bool destroyObject = true;

			[EditorHelp("Destroy Collected", "Destroy this game object if the item has already been collected when loading the scene (or spawning the object).")]
			[EditorIndent]
			[EditorCondition("destroyObject", false)]
			[EditorEndCondition]
			public bool destroyCollectedObject = false;

			[EditorHelp("Show Dialogue", "Show the item collection dialogue.")]
			[EditorEndCondition]
			public bool showDialogue = true;


			// box
			[EditorHelp("Destroy Empty Box", "Destroy this game object if the item box is empty.")]
			[EditorSeparator]
			[EditorCondition("collectionType", ItemCollectorType.Box)]
			public bool destroyEmptyBox = false;

			[EditorHelp("Auto Take All", "Take everything in the item box without showing a collection dialogue.")]
			public bool autoTakeAll = false;

			// exchange menu
			[EditorHelp("Use Exchange Menu Screen", "Use menu screen with an 'Inventory Exchange' part instead of the item box dialogue.")]
			[EditorSeparator]
			[EditorCondition("autoTakeAll", false)]
			public bool useInventoryExchangeMenu = false;

			[EditorHelp("Menu Screen", "Select the menu screen that will be used.\n" +
				"The menu screen needs an 'Inventory Exchange' part.")]
			[EditorCondition("useInventoryExchangeMenu", true)]
			[EditorEndCondition]
			public AssetSelection<MenuScreenAsset> menuScreen = new AssetSelection<MenuScreenAsset>();

			// box space limit
			[EditorHelp("Use Space Limit", "Use a space limit for the item box.")]
			[EditorSeparator]
			public bool useSpaceLimit = false;

			[EditorHelp("Space Limit", "Define the space limit that will be used.")]
			[EditorIndent]
			[EditorCondition("useSpaceLimit", true)]
			[EditorEndCondition]
			public float spaceLimit = 0;

			// box container slots
			[EditorHelp("Use Container Slots", "Use a single inventory container with slots for the item box.")]
			[EditorSeparator]
			public bool useContainerSlots = false;

			[EditorHelp("Container Slots", "Define the slots the single inventory container will use.")]
			[EditorIndent]
			[EditorCondition("useContainerSlots", true)]
			[EditorEndCondition(3)]
			public int containerSlots = 0;


			// control
			[EditorHelp("Block Player Control", "Block the player control while collecting the item.")]
			[EditorSeparator]
			[EditorTitleLabel("Control Block Settings")]
			public bool blockPlayerControl = true;

			[EditorHelp("Block Camera Control", "Block the camera control while collecting the item.")]
			public bool blockCameraControl = true;

			[EditorHelp("Block Control Maps", "Block the control maps while collecting the item.")]
			public bool blockControlMaps = true;


			// faction
			[EditorHelp("Use Faction", "The item/box belongs to a faction.\n" +
				"Taking items will impact the faction sympathy value.")]
			[EditorSeparator]
			[EditorTitleLabel("Faction Settings")]
			public bool useFaction = false;

			[EditorHelp("Faction", "Select the faction that will be used.")]
			[EditorCondition("useFaction", true)]
			[EditorEndCondition]
			public AssetSelection<FactionAsset> faction = new AssetSelection<FactionAsset>();


			// schematics
			// start schematic
			[EditorHelp("Start Schematic", "Use a schematic asset before starting the item collection.")]
			[EditorFoldout("Schematic Settings", "Optionally start schematics before or after collecting items.",
				initialState = false)]
			public AssetSource<MakinomSchematicAsset> startSchematicAsset = new AssetSource<MakinomSchematicAsset>();

			[EditorHelp("Use Spawned Prefab", "Use the item's prefab as 'Machine Object'.\n" +
				"If disabled, uses this game object.")]
			[EditorIndent]
			[EditorCondition("startSchematicAsset.HasAsset", true)]
			[EditorEndCondition]
			public bool startSchematicUsePrefab = true;

			// end schematic
			[EditorHelp("End Schematic", "Uses a schematic asset after finishing the item collection.")]
			[EditorSeparator]
			public AssetSource<MakinomSchematicAsset> endSchematicAsset = new AssetSource<MakinomSchematicAsset>();

			[EditorHelp("Use Spawned Prefab", "Use the item's prefab as 'Machine Object'.\n" +
				"If disabled, uses this game object.")]
			[EditorIndent]
			[EditorCondition("endSchematicAsset.HasAsset", true)]
			[EditorEndCondition]
			public bool endSchematicUsePrefab = true;

			// collected schematic
			[EditorHelp("Collected Schematic", "Uses a schematic asset when loading the scene and the item is already collected.")]
			[EditorSeparator]
			public AssetSource<MakinomSchematicAsset> collectedSchematicAsset = new AssetSource<MakinomSchematicAsset>();

			// cancel schematic
			[EditorHelp("Use Cancel Schematic", "Use a different schematic when canceling the item collection.")]
			[EditorSeparator]
			public bool useCancelEndSchematic = false;

			[EditorHelp("Cancel End Schematic", "Uses a schematic asset after canceling the item collection.")]
			[EditorCondition("useCancelEndSchematic", true)]
			[EditorEndCondition]
			public AssetSource<MakinomSchematicAsset> cancelEndSchematicAsset = new AssetSource<MakinomSchematicAsset>();

			[EditorHelp("Use Spawned Prefab", "Use the item's prefab as 'Machine Object'.\n" +
				"If disabled, uses this game object.")]
			[EditorIndent]
			[EditorEndFoldout(2)]
			[EditorCondition("cancelEndSchematicAsset.HasAsset", true)]
			[EditorEndCondition]
			public bool cancelEndSchematicUsePrefab = true;


			// item
			[EditorHelp("Set On Fail", "Set the scene ID (when using 'Single') if no item was used (e.g. due to chances).")]
			[EditorFoldout("Item Settings", "Define the item(s) of this item collector/box.")]
			public bool setOnChance = false;

			[EditorHelp("Show Notification", "Show the inventory notifications when collecting items.")]
			public bool showNotification = true;

			[EditorHelp("Show Console", "Show the inventory console texts when collecting items.")]
			public bool showConsole = true;

			[EditorHelp("Use Loot", "Use a loot table to fill the item box.\n" +
				"Uses the player combatant for level and variable conditions.\n" +
				"The player combatant must already be added to the player group when the scene is loaded.")]
			[EditorSeparator]
			[EditorCondition("collectionType", ItemCollectorType.Box)]
			[EditorDefaultValue(false)]
			public bool useLoot = false;

			[EditorHelp("Loot", "Select the loot table that will be used.\n" +
				"Uses the player combatant for level and variable conditions.\n" +
				"The player combatant must already be added to the player group when the scene is loaded.")]
			[EditorCondition("useLoot", true)]
			[EditorEndCondition(2)]
			public AssetSelection<LootAsset> loot = new AssetSelection<LootAsset>();

			// prefab settings
			[EditorHelp("Spawn Prefab", "Spawn the prefab of the used item.")]
			[EditorSeparator]
			[EditorTitleLabel("Prefab Settings")]
			[EditorCondition("collectionType", ItemCollectorType.Single)]
			public bool spawnPrefab = true;

			[EditorHelp("Despawn After Time", "Despawn the prefab after a defined time.")]
			[EditorCondition("spawnPrefab", true)]
			public bool despawn = false;

			[EditorHelp("Despawn Time (s)", "The time in seconds until the item is despawned.")]
			[EditorIndent]
			[EditorCondition("despawn", true)]
			public float despawnTime = 0;

			[EditorHelp("Set Collected", "Despawning will set the item as collected.")]
			[EditorIndent]
			[EditorEndCondition]
			public bool despawnCollected = true;

			// mount prefab
			[EditorHelp("Mount Prefab", "Parent the prefab on this game object.")]
			public bool doMount = false;

			[EditorHelp("Mount On Prefab", "Parent the item collector on the spawned prefab instead of the prefab on the item collector.")]
			[EditorIndent]
			[EditorCondition("doMount", true)]
			public bool mountOnPrefab = false;

			[EditorIndent]
			[EditorEndCondition]
			public MountSettings mount = new MountSettings();

			// conditions (prefab)
			[EditorHelp("Use Conditions", "The prefab is only spawned if the conditions are valid.")]
			public bool spawnUseConditions = false;

			[EditorHelp("Repeat Spawn Check", "Repeat the condition check until the item can be spawned.")]
			[EditorIndent]
			[EditorCondition("spawnUseConditions", true)]
			public bool repeatCheckSpawn = false;

			[EditorHelp("Repeat Time (s)", "The time in seconds between checks.")]
			[EditorIndent]
			[EditorCondition("repeatCheckSpawn", true)]
			[EditorEndCondition(4)]
			public float repeatCheckTime = 0.0f;


			// items
			[EditorSeparator]
			[EditorTitleLabel("Items")]
			[EditorEndFoldout]
			[EditorLabel("In 'Single' collection type, adding multiple items will use one of them randomly.")]
			[EditorArray("Add Item", "Adds an item.", "",
				"Remove", "Removes this item.", "",
				isCopy = true, isMove = true,
				foldout = true, foldoutText = new string[] {
					"Item", "Select the item that will be used.", ""
				})]
			public ItemGain<GameObjectSelection>[] item = new ItemGain<GameObjectSelection>[] { new ItemGain<GameObjectSelection>() };

			public Settings()
			{

			}
		}
	}
}
