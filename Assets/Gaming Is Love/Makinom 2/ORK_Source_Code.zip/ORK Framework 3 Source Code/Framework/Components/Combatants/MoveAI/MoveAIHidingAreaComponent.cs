﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Move AI/Move AI Hiding Area")]
	public class MoveAIHidingAreaComponent : BaseColliderZone
	{
		// in-game
		protected HashSet<Combatant> combatants = new HashSet<Combatant>();

		private static List<MoveAIHidingAreaComponent> ActiveAreas = new List<MoveAIHidingAreaComponent>();

		public virtual bool Contains(Combatant combatant)
		{
			return this.combatants.Contains(combatant);
		}

		/*
		============================================================================
		Area functions
		============================================================================
		*/
		protected virtual void OnEnable()
		{
			ActiveAreas.Add(this);
		}

		protected virtual void OnDisable()
		{
			ActiveAreas.Remove(this);
		}

		public static bool IsHidden(Combatant combatant)
		{
			for(int i = 0; i < ActiveAreas.Count; i++)
			{
				if(ActiveAreas[i].combatants.Contains(combatant))
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		3D trigger functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter(Collider other)
		{
			if(other != null)
			{
				Combatant combatant = ORKComponentHelper.GetCombatant(other.gameObject);
				if(combatant != null)
				{
					this.combatants.Add(combatant);
				}
			}
		}

		protected virtual void OnTriggerExit(Collider other)
		{
			if(other != null)
			{
				Combatant combatant = ORKComponentHelper.GetCombatant(other.gameObject);
				if(combatant != null)
				{
					this.combatants.Remove(combatant);
				}
			}
		}


		/*
		============================================================================
		2D trigger functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter2D(Collider2D other)
		{
			if(other != null)
			{
				Combatant combatant = ORKComponentHelper.GetCombatant(other.gameObject);
				if(combatant != null)
				{
					this.combatants.Add(combatant);
				}
			}
		}

		protected virtual void OnTriggerExit2D(Collider2D other)
		{
			if(other != null)
			{
				Combatant combatant = ORKComponentHelper.GetCombatant(other.gameObject);
				if(combatant != null)
				{
					this.combatants.Remove(combatant);
				}
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/MoveAIHidingAreaComponent Icon.png");
		}
	}
}
