﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Battle/Target Selection Cursor: Affect Range Scale")]
	public class AffectRangeScaleTargetSelectionCursorPrefab : MonoBehaviour, ITargetSelectionCursorPrefab
	{
		public virtual void StartSelection(Combatant user, Combatant target, IShortcut shortcut)
		{
			bool used = false;
			TargetSelectionSettings targetSettings = TargetSelectionSettings.Get(shortcut);
			if(targetSettings != null)
			{
				UseRange affectRange = targetSettings.affectRange.GetConditionalRange(
					user, target, shortcut as IVariableSource);
				if(affectRange != null)
				{
					float range = affectRange.GetRangeValue(user);
					if(range > 0)
					{
						used = true;
						this.transform.localScale = new Vector3(range, range, range);
					}
				}
			}
			if(!used)
			{
				this.transform.localScale = Vector3.zero;
			}
		}

		public virtual void StopSelection()
		{
			this.transform.localScale = Vector3.one;
		}
	}
}
