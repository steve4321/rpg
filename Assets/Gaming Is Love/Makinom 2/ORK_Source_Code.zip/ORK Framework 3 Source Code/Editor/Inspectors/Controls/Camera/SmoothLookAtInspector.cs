﻿
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;

[CustomEditor(typeof(SmoothLookAt))]
public class SmoothLookAtInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as SmoothLookAt);
	}

	protected virtual void ComponentSetup(SmoothLookAt target)
	{
		Undo.RecordObject(target, "Change to 'Smooth Look At' on " + target.name);
		this.BaseInit(false);

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.EndSetup();
	}
}