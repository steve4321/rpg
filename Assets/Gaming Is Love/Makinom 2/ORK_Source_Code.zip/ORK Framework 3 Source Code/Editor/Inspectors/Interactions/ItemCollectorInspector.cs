
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(ItemCollector))]
public class ItemCollectorInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as ItemCollector);
	}

	protected ItemCollectorType lastType;

	private void ComponentSetup(ItemCollector target)
	{
		Undo.RecordObject(target, "Change to 'Item Collector' on " + target.name);
		this.BaseInit(true);

		if(this.lastType != target.settings.collectionType)
		{
			this.lastType = target.settings.collectionType;
			this.Repaint();
			return;
		}

		if(ItemCollectorType.Box == target.settings.collectionType)
		{
			this.ShowSceneGUID(target, "Use Box ID", "Get New Box ID",
				"The box ID is used to keep track of the contents of this item box.\n" +
				"If item boxes share the same box ID, their content will also be shared.\n" +
				"The box ID is used game-wide, i.e. also in different scenes.\n" +
				"You can use the box ID to change the content in schematics.");
		}
		else
		{
			this.ShowSceneID(target,
				"The scene ID is used to keep track of collected items.\n" +
				"If items share the same ID (in a scene), their collected state will be shared.\n" +
				"The scene ID is used scene-wide, i.e. not in different scenes.");
		}

		this.lastType = target.settings.collectionType;
		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.ShowBaseInteraction(target);

		this.EndSetup();
	}
}