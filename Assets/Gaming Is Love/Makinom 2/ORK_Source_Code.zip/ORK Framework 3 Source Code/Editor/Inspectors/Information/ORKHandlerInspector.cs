
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

[CustomEditor(typeof(ORKHandler))]
public class ORKHandlerInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.BaseInit(false);

		if(Application.isPlaying)
		{
			EditorGUILayout.LabelField("Control Maps Blocked", ORK.Control.ControlMapsBlocked.ToString());
			EditorGUILayout.LabelField("Menu Blocked", ORK.Control.MenuBlocked.ToString());
			EditorGUILayout.LabelField("In Menu", ORK.Control.InMenu.ToString());
			EditorGUILayout.LabelField("In Shop", ORK.Control.InShop.ToString());
			EditorGUILayout.LabelField("In Battle", ORK.Control.InBattle.ToString());
			if(ORK.Battle.System != null)
			{
				EditorGUILayout.LabelField("Battle System", ORK.Battle.System.EditorName);
				EditorGUILayout.LabelField("Battle Turn", ORK.Battle.Turn.ToString());
			}

			EditorGUILayout.Separator();
			EditorTool.BoldLabel("Battle Actions");
			EditorGUILayout.LabelField("Queued Actions", ORK.Battle.Actions.ActionCount.ToString());
			EditorGUILayout.LabelField("Casting Actions", ORK.Battle.Actions.CastingCount.ToString());
			EditorGUILayout.LabelField("Active Actions", ORK.Battle.Actions.ActiveCount.ToString());
		}
		else
		{
			GUILayout.Label("Shows information while playing.");
		}

		EditorGUILayout.Separator();
	}
}

