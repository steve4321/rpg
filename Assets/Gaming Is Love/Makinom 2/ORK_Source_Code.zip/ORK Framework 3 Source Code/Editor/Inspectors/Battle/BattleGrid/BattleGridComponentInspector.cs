﻿
using UnityEditor;
using UnityEngine;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

[CustomEditor(typeof(BattleGridComponent))]
public class BattleGridComponentInspector : BattleGridBaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ShowSettings(target as BattleGridComponent);
	}

	private void ShowSettings(BattleGridComponent target)
	{
		Undo.RecordObject(target, "Change to 'Battle Grid' on " + target.name);
		this.BaseInit(true);

		// start settings
		if(this.baseEditor.BeginFoldout("Battle Grid Generation", "", "", true))
		{
			EditorAutomation.Automate(target.settings, this.baseEditor);

			if(EditorTool.Button(new GUIContent("Generate Grid", EditorContent.Instance.AddIcon)))
			{
				Undo.SetCurrentGroupName("Generate battle grid on " + target.name);
				int undo = Undo.GetCurrentGroup();
				Undo.RegisterFullObjectHierarchyUndo(target.gameObject,
					 "Generate battle grid on " + target.name);

				target.ClearLookup();
				if(target.settings.generateKeepOldCells)
				{
					BattleGridCellRow[] cellRow = target.cellRow;
					target.cellRow = null;

					if(cellRow != null)
					{
						for(int i = 0; i < cellRow.Length; i++)
						{
							for(int j = 0; j < cellRow[i].cell.Length; j++)
							{
								if(cellRow[i].cell[j] != null)
								{
									cellRow[i].cell[j].gameObject.SetActive(false);
								}
							}
						}
					}

					BattleGridGenerator.Generate(target);

					if(cellRow != null)
					{
						// copy to new cells
						if(target.cellRow != null)
						{
							for(int i = 0; i < cellRow.Length; i++)
							{
								if(i < target.cellRow.Length)
								{
									for(int j = 0; j < cellRow[i].cell.Length; j++)
									{
										if(j < target.cellRow[i].cell.Length &&
											cellRow[i].cell[j] != null &&
											target.cellRow[i].cell[j] != null)
										{
											target.cellRow[i].cell[j].settings.SetData(cellRow[i].cell[j].settings.GetData());
											// connections
											for(int k = 0; k < target.cellRow[i].cell[j].connections.Length; k++)
											{
												if(cellRow[i].cell[j].connections[k] == null)
												{
													target.cellRow[i].cell[j].connections[k] = null;
												}
												else
												{
													target.cellRow[i].cell[j].connections[k] = target.GetCell(cellRow[i].cell[j].connections[k].CubeCoord);
												}
											}
										}
									}
								}
							}
						}
						// destroy old cells
						for(int i = 0; i < cellRow.Length; i++)
						{
							for(int j = 0; j < cellRow[i].cell.Length; j++)
							{
								if(cellRow[i].cell[j] != null)
								{
									GameObject.DestroyImmediate(cellRow[i].cell[j].gameObject);
								}
							}
						}
					}
				}
				else
				{
					target.RemoveGrid();
					BattleGridGenerator.Generate(target);
				}

				Undo.CollapseUndoOperations(undo);
			}
			if(target.cellRow != null && target.cellRow.Length > 0)
			{
				if(EditorTool.Button(new GUIContent("Remove Grid", EditorContent.Instance.RemoveIcon)))
				{
					Undo.SetCurrentGroupName("Remove battle grid from " + target.name);
					int undo = Undo.GetCurrentGroup();
					Undo.RegisterFullObjectHierarchyUndo(target.gameObject,
						"Remove battle grid from " + target.name);

					target.RemoveGrid();

					Undo.CollapseUndoOperations(undo);
				}
				if(!target.connectionsInitialized)
				{
					target.InitConnections();
				}
			}

			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();

		this.ShowGridSettings(null);

		this.EndSetup();
	}
}
