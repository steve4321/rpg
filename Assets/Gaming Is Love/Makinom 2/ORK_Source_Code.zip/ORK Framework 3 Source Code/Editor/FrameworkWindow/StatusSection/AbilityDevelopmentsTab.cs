﻿
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class AbilityDevelopmentsTab : ORKGenericAssetListTab<AbilityDevelopmentAsset, AbilityDevelopment>
	{
		public AbilityDevelopmentsTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Ability Developments"; }
		}

		public override string HelpText
		{
			get
			{
				return "Ability developments are used as templates by combatants and classes to learn abilities at defined levels.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/abilities/"; }
		}
	}
}
