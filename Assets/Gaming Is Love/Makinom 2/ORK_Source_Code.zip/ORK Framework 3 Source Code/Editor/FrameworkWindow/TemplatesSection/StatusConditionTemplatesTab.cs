
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class StatusConditionTemplatesTab : ORKGenericAssetListTab<StatusConditionTemplateAsset, StatusConditionTemplate>
	{
		public StatusConditionTemplatesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Status Condition Templates"; }
		}

		public override string HelpText
		{
			get
			{
				return "Status condition tempates are used to set up often needed combatant status conditions and can be used by status condition checks throughout the framework.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/status/status-conditions/"; }
		}
	}
}

