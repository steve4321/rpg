﻿
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class TargetSelectionTemplatesTab : ORKGenericAssetListTab<TargetSelectionTemplateAsset, TargetSelectionTemplate>
	{
		public TargetSelectionTemplatesTab(MakinomEditorWindow parent) : base(parent)
		{

		}

		public override void DefaultSetup()
		{
			if(this.assetList.Assets.Count == 0)
			{
				this.assetList.Add(TargetSelectionTemplatesTab.CreateAsset("Enemy Single", TargetType.Enemy, TargetRange.Single));
				this.assetList.Add(TargetSelectionTemplatesTab.CreateAsset("Enemy Group", TargetType.Enemy, TargetRange.Group));
				this.assetList.Add(TargetSelectionTemplatesTab.CreateAsset("Enemy None", TargetType.Enemy, TargetRange.None));
				this.assetList.Add(TargetSelectionTemplatesTab.CreateAsset("Ally Single", TargetType.Ally, TargetRange.Single));
				this.assetList.Add(TargetSelectionTemplatesTab.CreateAsset("Ally Group", TargetType.Ally, TargetRange.Group));
				this.assetList.Add(TargetSelectionTemplatesTab.CreateAsset("Ally None", TargetType.Ally, TargetRange.None));
				this.assetList.Add(TargetSelectionTemplatesTab.CreateAsset("All Single", TargetType.All, TargetRange.Single));
				this.assetList.Add(TargetSelectionTemplatesTab.CreateAsset("All Group", TargetType.All, TargetRange.Group));
				this.assetList.Add(TargetSelectionTemplatesTab.CreateAsset("All None", TargetType.All, TargetRange.None));
				this.assetList.Add(TargetSelectionTemplatesTab.CreateAsset("Self", TargetType.Self, TargetRange.Single));
			}
		}

		private static TargetSelectionTemplateAsset CreateAsset(string name, TargetType targetType, TargetRange targetRange)
		{
			TargetSelectionTemplateAsset asset = ScriptableObject.CreateInstance<TargetSelectionTemplateAsset>();
			asset.Settings = new TargetSelectionTemplate(name, targetType, targetRange);
			return asset;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Target Selection Templates"; }
		}

		public override string HelpText
		{
			get
			{
				return "Target selection templates are used by abilities and items to define which targets are available.\n" +
					"You can define default target selections in 'Battles > Target Settings', " +
					"each ability type and item type can override them with their own default target selections.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/battles/target-selection/"; }
		}
	}
}
