
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class AreasTab : ORKGenericAssetListTab<AreaAsset, Area>
	{
		public AreasTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.Areas.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.Areas.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Areas"; }
		}

		public override string HelpText
		{
			get
			{
				return "Areas can be used to add content information to your game world using 'Area' components.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/areas-teleports/"; }
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<AreaTypeAsset, AreaType>(
							new string[] { "Area Type", "Filter the area list by area type.", "" }));
				}
				return this.filter;
			}
		}

		protected override bool CheckFilterCondition(int index)
		{
			return this.Filter.assetFilterSelection[0].Check(
				this.assetList.Assets[index].Settings.type.Source.EditorAsset);
		}
	}
}
