
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class QuestsTab : ORKGenericAssetListTab<QuestAsset, QuestSetting>
	{
		public QuestsTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.Quests.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.Quests.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Quests"; }
		}

		public override string HelpText
		{
			get
			{
				return "Quests are used to track progress and give rewards.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/quests/"; }
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<QuestTypeAsset, QuestType>(
							new string[] { "Quest Type", "Filter the quest list by quest type.", "" }));
				}
				return this.filter;
			}
		}

		protected override bool CheckFilterCondition(int index)
		{
			if(this.Filter.assetFilterSelection[0].UseFilter)
			{
				QuestType type = this.Filter.assetFilterSelection[0].Selection as QuestType;
				return this.assetList.Assets[index].Settings.IsType(type, false);
			}
			return true;
		}
	}
}
