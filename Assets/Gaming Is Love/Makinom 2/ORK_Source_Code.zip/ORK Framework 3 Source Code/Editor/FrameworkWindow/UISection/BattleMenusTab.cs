
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class BattleMenusTab : ORKGenericAssetListTab<BattleMenuAsset, BattleMenu>
	{
		public BattleMenusTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Battle Menus"; }
		}

		public override string HelpText
		{
			get
			{
				return "Battle menus are used by the player to select actions to perform in battle (e.g. abilities, items, defending, etc.).";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/battles/battle-menus/"; }
		}
	}
}

