﻿
using GamingIsLove.ORKFramework;
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class NotificationSettingsTab : ORKBaseEditorTab
	{
		public NotificationSettingsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;

			this.DefaultSetup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Notifications"; }
		}

		public override string HelpText
		{
			get { return "Set up notifications."; }
		}

		public override string HelpInfo
		{
			get { return ""; }
		}

		protected override BaseSettings Settings
		{
			get { return ORK.NotificationSettings; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return ORK.NotificationSettings; }
		}


		/*
		============================================================================
		Settings functions
		============================================================================
		*/
		public override void ShowSettings()
		{
			base.ShowSettings();

			// area
			if(this.BeginFoldout("Area Notifications", "Show notifications when entering an area.", "", true))
			{
				EditorAutomation.Automate(ORK.AreaSettings.notifications, this);
			}
			this.EndFoldout();

			// logs
			if(this.BeginFoldout("Log Notifications", "Log notifications can be displayed when a log changes.", "", true))
			{
				EditorAutomation.Automate(ORK.LogSettings.queueNotifications, this);
				EditorAutomation.Automate(ORK.LogSettings.notifications, this);
			}
			this.EndFoldout();

			// quests
			if(this.BeginFoldout("Quest Notifications", "Show notifications for quest, quest task or quest task requirement changes.", "", true))
			{
				EditorAutomation.Automate(ORK.QuestSettings.queueQuestNotifications, this);
				EditorAutomation.Automate(ORK.QuestSettings.notifications, this);
			}
			this.EndFoldout();

			// bestiary
			if(this.BeginFoldout("Bestiary Notifications", "Adding, updating or completing a bestiary entry can display notifications.", "", true))
			{
				EditorAutomation.Automate(ORK.GameSettings.bestiary.notifications, this);
			}
			this.EndFoldout();

			// player group
			if(this.BeginFoldout("Player Group Notifications", "Notifications can be displayed when combatants join or leave the player group.", "", true))
			{
				EditorAutomation.Automate(ORK.GameSettings.playerGroup.queueNotifications, this);
				EditorAutomation.Automate(ORK.GameSettings.playerGroup.notifications, this);
			}
			this.EndFoldout();

			// inventory
			if(this.BeginFoldout("Inventory Notifications", "Inventory changes and crafting recipes can display notifications.", "", true))
			{
				EditorAutomation.Automate(ORK.InventorySettings.notifications, this);
			}
			this.EndFoldout();

			// inventory containers
			if(this.BeginFoldout("Inventory Container Notifications", "Optionally display notifications when free inventory container slots are running out.", "", true))
			{
				EditorAutomation.Automate(ORK.InventoryContainers.notifications, this);
			}
			this.EndFoldout();

			// crafting
			if(this.BeginFoldout("Crafting Notifications", "Learning recipes and using them can display notifications.", "", true))
			{
				EditorAutomation.Automate(ORK.CraftingSettings.notifications, this);
			}
			this.EndFoldout();
		}
	}
}
