﻿
using GamingIsLove.ORKFramework;
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class BattleGridSettingsTab : ORKBaseEditorTab
	{
		public BattleGridSettingsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;

			this.DefaultSetup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Battle Grid Settings"; }
		}

		public override string HelpText
		{
			get { return "Set up how grid battles will work."; }
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/battles/grid-battles/"; }
		}

		protected override BaseSettings Settings
		{
			get { return ORK.BattleGridSettings; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return ORK.BattleGridSettings; }
		}
	}
}
