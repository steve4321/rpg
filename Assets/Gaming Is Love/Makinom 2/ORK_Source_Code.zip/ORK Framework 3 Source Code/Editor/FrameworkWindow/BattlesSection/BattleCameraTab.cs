﻿
using GamingIsLove.ORKFramework;
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class BattleCameraTab : ORKBaseEditorTab
	{
		public BattleCameraTab(MakinomEditorWindow parent)
		{
			this.parent = parent;

			this.DefaultSetup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Battle Camera"; }
		}

		public override string HelpText
		{
			get { return "The battle camera can automatically focus on the current action of a battle."; }
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/battles/battle-camera/"; }
		}

		protected override BaseSettings Settings
		{
			get { return ORK.BattleCamera; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return ORK.BattleCamera; }
		}


		/*
		============================================================================
		Automation functions
		============================================================================
		*/
		public override void AutomationCallback(string info)
		{
			if(info == "check:rotations")
			{
				VectorHelper.LimitVector3(ref ORK.BattleCamera.minRotation, -180, 0);
				VectorHelper.LimitVector3(ref ORK.BattleCamera.maxRotation, 0, 180);
			}
			else
			{
				base.AutomationCallback(info);
			}
		}
	}
}
