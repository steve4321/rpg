﻿
using UnityEditor;
using UnityEngine;
using GamingIsLove.ORKFramework;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class ClassSlotsTab : ORKGenericAssetListTab<ClassSlotAsset, ClassSlotSetting>
	{
		public ClassSlotsTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.ClassSlots.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.ClassSlots.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Class Slots"; }
		}

		public override string HelpText
		{
			get
			{
				return "Class slots are used to equip classes.\n" +
					"This is an optional feature and allows a combatant to use/equip multiple classes at the same time.\n" +
					"When not used, the combatant uses only one class (or none at all). Both systems can also be combined.";
			}
		}

		public override string HelpInfo
		{
			get { return ""; }
		}
	}
}

