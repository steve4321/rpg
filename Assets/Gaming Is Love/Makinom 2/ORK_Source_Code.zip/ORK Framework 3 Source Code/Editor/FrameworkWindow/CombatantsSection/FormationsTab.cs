﻿
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class FormationsTab : ORKGenericAssetListTab<FormationAsset, Formation>
	{
		private EditorFormationControl fieldControl;

		private EditorFormationControl battleControl;

		public FormationsTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.Formations.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.Formations.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Formations"; }
		}

		public override string HelpText
		{
			get
			{
				return "Formations are used to define positions of combatants around their group leader.\n" +
					"They can be used by move AIs (follow leader) and to place combatants in battle.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/formations/"; }
		}


		/*
		============================================================================
		Automation functions
		============================================================================
		*/
		public override void AutomationCallback(string info)
		{
			if(info == "editor:FieldFormation")
			{
				Formation formation = this.CurrentSettings;
				if(formation != null)
				{
					if(EditorTool.Button("Clear Formation", "Resets the formation.", ""))
					{
						formation.fieldPosition = new FormationPosition[0];
					}

					if(this.fieldControl == null)
					{
						this.fieldControl = new EditorFormationControl();
					}
					this.fieldControl.Edit(ref formation.fieldPosition, ref formation.editorFieldDistance);
					if(GUI.changed)
					{
						this.parent.Repaint();
					}
				}
			}
			else if(info == "editor:BattleFormation")
			{
				Formation formation = this.CurrentSettings;
				if(formation != null)
				{
					if(EditorTool.Button("Copy Field Positions", "Copies the setup of the field positions to the battle positions.", ""))
					{
						formation.battlePosition = new FormationPosition[formation.fieldPosition.Length];
						for(int i = 0; i < formation.battlePosition.Length; i++)
						{
							formation.battlePosition[i] = new FormationPosition();
							formation.battlePosition[i].SetData(formation.fieldPosition[i].GetData());
						}
					}
					if(EditorTool.Button("Clear Formation", "Resets the formation.", ""))
					{
						formation.battlePosition = new FormationPosition[0];
					}

					if(this.battleControl == null)
					{
						this.battleControl = new EditorFormationControl();
					}
					this.battleControl.Edit(ref formation.battlePosition, ref formation.editorBattleDistance);
					if(GUI.changed)
					{
						this.parent.Repaint();
					}
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}
	}
}

