﻿
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class ResearchTypesTab : ORKGenericAssetListTab<ResearchTypeAsset, ResearchType>
	{
		public ResearchTypesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.ResearchTypes.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.ResearchTypes.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Research Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Research types are used to separate research trees.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/research-trees/"; }
		}
	}
}
