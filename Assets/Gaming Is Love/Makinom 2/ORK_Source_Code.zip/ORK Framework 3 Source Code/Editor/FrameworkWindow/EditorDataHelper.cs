﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Editor
{
	public static class EditorDataHelper
	{
		public static void SetStatusValueType(StatusValueSetting statusValue, StatusValueType type)
		{
			ORK.Difficulties.SetStatusValueType(statusValue, type);
			ORK.StatusValues.SetStatusValueType(statusValue, type);

			GenericAssetList<StatusDevelopmentAsset> statDev = EditorDataHandler.Instance.GetAssets<StatusDevelopmentAsset>();
			for(int i = 0; i < statDev.Assets.Count; i++)
			{
				if(statDev.Assets[i] != null)
				{
					statDev.Assets[i].Settings.SetStatusValueType(statusValue, type);
				}
			}

			ORK.Combatants.SetStatusValueType(statusValue, type);

			GenericAssetList<BattleSystemAsset> battleSystem = EditorDataHandler.Instance.GetAssets<BattleSystemAsset>();
			for(int i = 0; i < battleSystem.Assets.Count; i++)
			{
				if(battleSystem.Assets[i] != null)
				{
					battleSystem.Assets[i].Settings.SetStatusValueType(statusValue, type);
				}
			}
		}

		public static void StatusValueMinMaxChanged(StatusValueSetting statusValue)
		{
			GenericAssetList<StatusDevelopmentAsset> statDev = EditorDataHandler.Instance.GetAssets<StatusDevelopmentAsset>();
			for(int i = 0; i < statDev.Assets.Count; i++)
			{
				if(statDev.Assets[i] != null)
				{
					statDev.Assets[i].Settings.StatusValueMinMaxChanged(statusValue);
				}
			}
		}

		// developments
		public static void StatusDevelopmentLevels(StatusDevelopment development)
		{
			ORK.Combatants.StatusDevelopmentLevels(development);
		}
	}
}
