﻿
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public class EditorFormationControl
	{
		private static int DistanceSize = 40;

		private static int PositionSize = 25;

		private Rect boxRect;

		private int dragIndex = -1;


		// styles
		private static GUIStyle frontLabelStyle;

		private static GUIStyle distanceStyle;

		private static GUIStyle positionStyle;

		public EditorFormationControl()
		{
			if(EditorFormationControl.frontLabelStyle == null)
			{
				System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();

				EditorFormationControl.frontLabelStyle = new GUIStyle(GUI.skin.label);
				EditorFormationControl.frontLabelStyle.alignment = TextAnchor.MiddleCenter;
				EditorFormationControl.frontLabelStyle.fontStyle = FontStyle.Bold;

				EditorFormationControl.distanceStyle = new GUIStyle(GUI.skin.label);
				EditorFormationControl.distanceStyle.alignment = TextAnchor.MiddleCenter;
				EditorFormationControl.distanceStyle.fontSize = 10;
				EditorFormationControl.distanceStyle.normal.textColor = Color.red;

				EditorFormationControl.positionStyle = new GUIStyle();
				EditorFormationControl.positionStyle.normal.background = EditorContent.LoadImage(
					System.AppDomain.CurrentDomain.GetAssemblies(),
					"GamingIsLove.ORKFramework.Editor.Images.Icons.FormationPosition.png",
					EditorFormationControl.PositionSize, EditorFormationControl.PositionSize);
				EditorFormationControl.positionStyle.normal.textColor = Color.black;
				EditorFormationControl.positionStyle.fixedWidth = 25;
				EditorFormationControl.positionStyle.fixedHeight = 25;
				EditorFormationControl.positionStyle.border = new RectOffset(0, 0, 0, 0);
				EditorFormationControl.positionStyle.overflow = new RectOffset(0, 0, 0, 0);
				EditorFormationControl.positionStyle.alignment = TextAnchor.MiddleCenter;
			}
		}

		public void Edit(ref FormationPosition[] position, ref float editorDistance)
		{
			// max distance
			for(int i = 0; i < position.Length; i++)
			{
				float tmp = Mathf.Abs(position[i].position.x);
				if(editorDistance < tmp)
				{
					editorDistance = tmp + 1;
				}
				if(HorizontalPlaneType.XZ == Maki.GameSettings.horizontalPlane)
				{
					tmp = Mathf.Abs(position[i].position.z);
				}
				else if(HorizontalPlaneType.XY == Maki.GameSettings.horizontalPlane)
				{
					tmp = Mathf.Abs(position[i].position.y);
				}
				if(editorDistance < tmp)
				{
					editorDistance = tmp + 1;
				}
			}

			EditorGUILayout.HelpBox("Right-click to place and remove positions.\n" +
				"Left-click drag to move a position (except leader in the center).",
				MessageType.Info);

			float size = editorDistance * EditorFormationControl.DistanceSize * 2;
			GUILayout.Label("Front (3D)", EditorFormationControl.frontLabelStyle, GUILayout.Width(size));
			GUILayout.Box("", EditorContent.Instance.BoxSlimStyle, GUILayout.Width(size), GUILayout.Height(size));
			if(Event.current.type == EventType.Repaint)
			{
				this.boxRect = GUILayoutUtility.GetLastRect();
			}

			size = editorDistance * EditorFormationControl.DistanceSize;
			Color tmpColor = Handles.color;
			Handles.color = Color.red;
			Vector3 center = new Vector3(this.boxRect.x + size, this.boxRect.y + size, 0);
			for(int i = 1; i < editorDistance; i++)
			{
				float radius = i * EditorFormationControl.DistanceSize;
				Handles.DrawWireDisc(center, Vector3.forward, radius);
				GUIContent label = new GUIContent(i.ToString());
				Vector2 labelSize = EditorFormationControl.distanceStyle.CalcSize(label);
				Handles.Label(center + new Vector3(-labelSize.x / 4, -radius + 1, 0), label, EditorFormationControl.distanceStyle);
				Handles.Label(center + new Vector3(-labelSize.x / 4, radius - 1 - labelSize.y, 0), label, EditorFormationControl.distanceStyle);
				Handles.Label(center + new Vector3(-radius + 1 + labelSize.x / 2, -labelSize.y / 2, 0), label, EditorFormationControl.distanceStyle);
				Handles.Label(center + new Vector3(radius - 1 - labelSize.x, -labelSize.y / 2, 0), label, EditorFormationControl.distanceStyle);
			}
			Handles.color = tmpColor;

			this.DrawPosition(ref position, -1, 0, 0, editorDistance, "L");

			for(int i = 0; i < position.Length; i++)
			{
				if(HorizontalPlaneType.XZ == Maki.GameSettings.horizontalPlane)
				{
					this.DrawPosition(ref position, i, position[i].position.x, position[i].position.z, editorDistance, i.ToString());
				}
				else if(HorizontalPlaneType.XY == Maki.GameSettings.horizontalPlane)
				{
					this.DrawPosition(ref position, i, position[i].position.x, position[i].position.y, editorDistance, i.ToString());
				}
			}

			// interaction
			if(Event.current.type == EventType.MouseUp &&
				Event.current.button == 1 &&
				this.boxRect.Contains(Event.current.mousePosition))
			{
				FormationPosition newPosition = new FormationPosition();
				newPosition.position.x = (Event.current.mousePosition.x - center.x) / EditorFormationControl.DistanceSize;
				if(HorizontalPlaneType.XZ == Maki.GameSettings.horizontalPlane)
				{
					newPosition.position.z = -(Event.current.mousePosition.y - center.y) / EditorFormationControl.DistanceSize;
				}
				else if(HorizontalPlaneType.XY == Maki.GameSettings.horizontalPlane)
				{
					newPosition.position.y = -(Event.current.mousePosition.y - center.y) / EditorFormationControl.DistanceSize;
				}
				Event.current.Use();
				ArrayHelper.Add(ref position, newPosition);
				GUI.changed = true;
			}
		}

		private void DrawPosition(ref FormationPosition[] position, int index, float x, float y, float editorDistance, string label)
		{
			Rect rect = new Rect(
				this.boxRect.x + (editorDistance + x) * EditorFormationControl.DistanceSize - EditorFormationControl.PositionSize / 2,
				this.boxRect.y + (editorDistance - y) * EditorFormationControl.DistanceSize - EditorFormationControl.PositionSize / 2,
				EditorFormationControl.PositionSize, EditorFormationControl.PositionSize);
			GUI.Label(rect, label, EditorFormationControl.positionStyle);

			// interaction
			if(index >= 0)
			{
				// drag
				if(this.dragIndex == index)
				{
					if(Event.current.type == EventType.MouseUp &&
						Event.current.button == 0)
					{
						Event.current.Use();
						this.dragIndex = -1;
						GUI.changed = true;
					}
					else if(Event.current.type == EventType.MouseDrag)
					{
						Event.current.Use();
						Vector2 change = Event.current.delta / EditorFormationControl.DistanceSize;
						position[index].position.x += change.x;
						// limit
						if(position[index].position.x < -editorDistance)
						{
							position[index].position.x = -editorDistance;
						}
						else if(position[index].position.x > editorDistance)
						{
							position[index].position.x = editorDistance;
						}
						if(HorizontalPlaneType.XZ == Maki.GameSettings.horizontalPlane)
						{
							position[index].position.z -= change.y;
							// limit
							if(position[index].position.z < -editorDistance)
							{
								position[index].position.z = -editorDistance;
							}
							else if(position[index].position.z > editorDistance)
							{
								position[index].position.z = editorDistance;
							}
						}
						else if(HorizontalPlaneType.XY == Maki.GameSettings.horizontalPlane)
						{
							position[index].position.y -= change.y;
							// limit
							if(position[index].position.y < -editorDistance)
							{
								position[index].position.y = -editorDistance;
							}
							else if(position[index].position.y > editorDistance)
							{
								position[index].position.y = editorDistance;
							}
						}
						GUI.changed = true;
					}
				}
				else if(Event.current.type == EventType.MouseDown &&
					Event.current.button == 0 &&
					rect.Contains(Event.current.mousePosition))
				{
					Event.current.Use();
					this.dragIndex = index;
				}
				// remove
				else if(Event.current.type == EventType.MouseUp &&
					Event.current.button == 1 &&
					rect.Contains(Event.current.mousePosition))
				{
					Event.current.Use();
					ArrayHelper.RemoveAt(ref position, index);
					GUI.changed = true;
				}
			}
		}
	}
}
